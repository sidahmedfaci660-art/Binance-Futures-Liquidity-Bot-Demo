# تحذير المخاطر / Risk Disclaimer

## بالعربية

1. هذا البرنامج **كود مصدري (Source Code)** لأداة تداول آلي، وليس نصيحة
   مالية أو استثمارية.
2. تداول العقود الآجلة (Futures) بالرافعة المالية **عالي المخاطر جداً**
   ويمكن أن يؤدي إلى خسارة كامل رأس المال المستخدم، وربما أكثر منه حسب
   إعدادات الحساب.
3. **لا توجد أي ضمانة ربح، ولا نسبة نجاح (Win Rate) مضمونة.** أي أداء
   سابق (اختبار شخصي، Backtest، Testnet) لا يمثل ولا يضمن نتائج مستقبلية.
4. أنت المسؤول الوحيد عن:
   - مفاتيح Binance API الخاصة بك وأمانها.
   - إعدادات المخاطرة، الرافعة، ورأس المال التي تختارها.
   - مراقبة الحساب والتأكد من عمل البوت كما هو متوقع.
   - أي قرار بالتحويل من TESTNET/DRY_RUN إلى LIVE.
5. يُنصح بشدة:
   - عدم إعطاء مفتاح API لأي شخص آخر.
   - تعطيل صلاحية السحب (Withdrawals) على مفتاح API المستخدم للبوت.
   - تفعيل تقييد IP (IP Restriction) على المفتاح إن أمكن.
   - البدء دائماً بوضع TESTNET أو DRY_RUN لعدة أيام قبل أي تشغيل حقيقي.
   - عدم استخدام رأس مال لا يمكنك تحمل خسارته بالكامل.
6. البائع/المطوّر لا يتحمل مسؤولية أي خسارة مالية، فنية، أو أي ضرر آخر
   ناتج عن استخدام هذا البرنامج، بما في ذلك أخطاء الشبكة، انقطاع
   الاتصال، سلوك غير متوقع من واجهة Binance، أو خطأ في إعدادات المستخدم.
7. النتائج تختلف باختلاف السوق، الإعدادات، رأس المال، وظروف التشغيل.

## English (summary)

This is trading-automation source code, not financial advice. Futures
trading with leverage is high-risk and can result in total loss of the
capital used. No profit or win-rate is guaranteed. You are solely
responsible for your API keys, your risk settings, and your decision to
run in LIVE mode. Always test on TESTNET / DRY_RUN first, disable
withdrawal permission on the trading API key, and never trade with money
you cannot afford to lose.
