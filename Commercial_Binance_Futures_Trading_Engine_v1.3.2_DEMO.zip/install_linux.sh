#!/usr/bin/env bash
set -e
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
[ -f .env ] || cp .env.example .env
echo "تم التثبيت. فعّل البيئة: source venv/bin/activate"
echo "عدّل .env بمفاتيحك وترخيصك، ثم شغّل: python3 main.py"
