# التثبيت — Commercial Binance Futures Trading Engine

## المتطلبات
Python 3.9+ و pip.

## Termux (أندرويد)
```bash
pkg update && pkg install python git -y
pip install -r requirements.txt --break-system-packages
```
أو ببساطة: `bash install_termux.sh`

## Linux
```bash
python3 -m venv venv && source venv/bin/activate
pip install -r requirements.txt
```
أو: `bash install_linux.sh`

## Windows
```powershell
python -m venv venv
venv\Scripts\activate
pip install -r requirements.txt
```

## VPS (Linux)
نفس خطوات Linux. يُنصح بتشغيله داخل `tmux`/`screen` أو كخدمة `systemd`
حتى يستمر بعد إغلاق الجلسة.

## بعد التثبيت
انتقل إلى `CONFIGURATION.md` لإعداد `.env` والترخيص.
