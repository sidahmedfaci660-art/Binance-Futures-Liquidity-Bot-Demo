#!/data/data/com.termux/files/usr/bin/bash
set -e
pkg update -y
pkg install python git -y
pip install -r requirements.txt --break-system-packages
[ -f .env ] || cp .env.example .env
echo "تم التثبيت. عدّل .env بمفاتيحك وترخيصك، ثم شغّل: python3 main.py"
