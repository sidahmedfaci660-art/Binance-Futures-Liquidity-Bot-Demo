# -*- coding: utf-8 -*-
"""
وحدة التحقق من الترخيص - تُشحن مع نسخة المشتري.

مهم: هذا الملف يحتوي فقط على المفتاح العام (PUBLIC_KEY_HEX)، وليس
المفتاح الخاص. وجود هذا الملف عند المشتري - حتى لو قرأه بالكامل - لا
يسمح له بتوليد ترخيص جديد صالح، لأن التوقيع يحتاج المفتاح الخاص الذي
يبقى عند البائع فقط (انظر seller_tools/).

⚠ ملاحظة صادقة: هذا نظام ترخيص "غير متصل" (offline) بسيط ومعقول
لأغراض تجارية عادية - يمنع الاستخدام العرضي بلا ترخيص، ويسمح بربط/تحديد
مدة الاستخدام. لكنه **ليس حماية غير قابلة للكسر**: أي شخص لديه خبرة
كافية ويملك نسخة من main.py يمكنه نظرياً حذف استدعاء التحقق نفسه من
الكود (لأن بايثون كود مصدري قابل للقراءة). للحماية الأقوى، فكّر بتشغيل
PyArmor أو تجميع الملف عبر PyInstaller قبل التسليم النهائي للمشترين -
هذا يصعّب التعديل لكنه لا يجعله مستحيلاً بشكل مطلق. لا تَعِد المشترين
أو نفسك بأكثر من هذا.
"""
import base64
import json
import os
import platform
import uuid
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Optional

from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
from cryptography.exceptions import InvalidSignature

# ضع هنا القيمة الناتجة من seller_tools/generate_keypair.py (license_public_key.txt)
# قبل تسليم هذا الملف لأي مشترٍ. القيمة الحالية أدناه قيمة توضيحية فقط
# ولن تتحقق من أي ترخيص حقيقي حتى تستبدلها بمفتاحك العام الفعلي.
PUBLIC_KEY_HEX = "e153ac8a2cd2373b045ea18f027cd16c5e55ae6e098ff88fe3876db45429058f"

PRODUCT_ID = "cbfte-v1"


class LicenseError(RuntimeError):
    pass


@dataclass
class LicenseInfo:
    licensee: str
    issued: str
    expires: Optional[str]
    hwid: Optional[str]


def compute_hwid() -> str:
    """
    معرّف جهاز تقريبي (ليس مثالياً 100% على كل الأجهزة، خصوصاً على
    Termux/الأندرويد حيث قد يتغيّر عنوان MAC أو معرّف الجهاز بين إصدارات
    النظام) - يُستخدم فقط عند طلب البائع ربط الترخيص بجهاز معيّن.
    """
    raw = f"{uuid.getnode()}|{platform.machine()}|{platform.system()}"
    import hashlib
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()[:16].upper()


def _b64u_decode(s: str) -> bytes:
    pad = "=" * (-len(s) % 4)
    return base64.urlsafe_b64decode(s + pad)


def verify_license_key(license_key: str) -> LicenseInfo:
    """
    يرفع LicenseError برسالة عربية واضحة إن كان الترخيص غير صالح.
    يعيد LicenseInfo إن كان صالحاً.
    """
    if not license_key or "." not in license_key:
        raise LicenseError("مفتاح الترخيص (LICENSE_KEY) مفقود أو بصيغة غير صحيحة.")

    try:
        payload_b64, sig_b64 = license_key.strip().split(".", 1)
        payload_bytes = _b64u_decode(payload_b64)
        signature = _b64u_decode(sig_b64)
    except Exception:
        raise LicenseError("تعذّر قراءة مفتاح الترخيص (تنسيق غير صالح).")

    try:
        pub = Ed25519PublicKey.from_public_bytes(bytes.fromhex(PUBLIC_KEY_HEX))
        pub.verify(signature, payload_bytes)
    except InvalidSignature:
        raise LicenseError("توقيع الترخيص غير صحيح - هذا الترخيص مزوَّر أو تالف.")
    except Exception as e:
        raise LicenseError(f"تعذّر التحقق من الترخيص: {e}")

    try:
        payload = json.loads(payload_bytes.decode("utf-8"))
    except Exception:
        raise LicenseError("محتوى الترخيص تالف (JSON غير صالح).")

    if payload.get("product") != PRODUCT_ID:
        raise LicenseError("هذا الترخيص صادر لمنتج مختلف.")

    expires = payload.get("expires")
    if expires:
        try:
            exp_date = datetime.strptime(expires, "%Y-%m-%d").replace(tzinfo=timezone.utc)
        except Exception:
            raise LicenseError("تاريخ انتهاء الترخيص غير صالح.")
        if datetime.now(timezone.utc) > exp_date:
            raise LicenseError(f"انتهت صلاحية الترخيص بتاريخ {expires}. تواصل مع البائع للتجديد.")

    bound_hwid = payload.get("hwid")
    if bound_hwid:
        current = compute_hwid()
        if current.upper() != str(bound_hwid).upper():
            raise LicenseError(
                "هذا الترخيص مربوط بجهاز آخر. إن كنت غيّرت جهازك، تواصل مع "
                f"البائع وأرسل له معرّف جهازك الحالي: {current}"
            )

    return LicenseInfo(
        licensee=payload.get("licensee", "?"),
        issued=payload.get("issued", "?"),
        expires=expires,
        hwid=bound_hwid,
    )


def check_license_or_exit(logger=None) -> LicenseInfo:
    """
    تُستدعى من main.py عند الإقلاع. تقرأ LICENSE_KEY من متغيرات البيئة
    (يُحمَّل عادة من .env عبر python-dotenv قبل استدعاء هذه الدالة)،
    وتوقف البرنامج فوراً برسالة واضحة إن لم يكن صالحاً.
    """
    key = os.getenv("LICENSE_KEY", "").strip()
    try:
        info = verify_license_key(key)
    except LicenseError as e:
        msg = f"[FATAL] فشل التحقق من الترخيص: {e}"
        print(msg)
        if logger:
            try:
                logger.critical(msg)
            except Exception:
                pass
        raise SystemExit(1)

    ok_msg = f"[LICENSE] ترخيص صالح - المرخَّص له: {info.licensee}" + (
        f" - ينتهي: {info.expires}" if info.expires else " - بلا تاريخ انتهاء"
    )
    print(ok_msg)
    if logger:
        try:
            logger.info(ok_msg)
        except Exception:
            pass
    return info


if __name__ == "__main__":
    # تشغيل هذا الملف مباشرة يطبع معرّف الجهاز الحالي فقط (مفيد للمشتري
    # ليرسله للبائع عند طلب ترخيص مربوط بجهاز).
    print("HWID:", compute_hwid())
