# Commercial Binance Futures Trading Engine — v1.3.2

بوت تداول آلي لعقود Binance Futures (ملف Python مصدري واحد: `main.py`).

## ابدأ من هنا
1. **`INSTALLATION.md`** — تثبيت (Termux / Linux / Windows / VPS).
2. **`CONFIGURATION.md`** — إعداد `.env` (مفاتيح Binance، Telegram،
   الترخيص)، ووضع التشغيل (TESTNET/DRY_RUN/LIVE).
3. **`TRADING_AND_RISK.md`** — مرجع كامل لإعدادات المخاطرة والتداول
   بالقيم الفعلية الحالية (رافعة، رأس مال، SL/TP، القاطع الدائري).
4. **`RISK_DISCLAIMER.md`** — اقرأه قبل أي استخدام حقيقي.
5. **`LICENSE.md`** — شروط الترخيص (استخدام شخصي، لا إعادة بيع).

## التشغيل
```bash
python3 main.py
```
يتحقق من `LICENSE_KEY` أولاً، يطبع حالته، ثم يبدأ. للإيقاف: `Ctrl+C`،
أو أرسل `/stop` عبر Telegram.

## أين تجد البيانات
- `bot_log.jsonl` — سجل كامل لكل قرار (JSON سطراً بسطر)، بحقل `reason`
  واضح للرفض (`REJECT_DUPLICATE_POSITION`, `REJECT_INSUFFICIENT_MARGIN`,
  إلخ). `grep '"reason"' bot_log.jsonl | tail -50`
- `bot_state.db` — قاعدة بيانات الصفقات والحالة (SQLite).
- `bot.lock` — يمنع تشغيل نسختين في آن واحد.

لا تشارك هذه الملفات مع أحد — تحتوي على سجل تداولك الفعلي.

## أوامر Telegram
`/help` للقائمة الكاملة. من أهمها: `/status`, `/balance`, `/positions`,
`/stats`, `/pause`, `/resume`, `/close SYMBOL`, `/closeall`, `/stop`,
`/breaker` (تحكّم بالقاطع الدائري).

## تشغيل الاختبارات الآلية (pytest)
```bash
pip install -r requirements.txt
pytest
```
29 اختباراً تغطي: حجم الصفقة، تقريب الكمية/السعر، منع الصفقات المكررة
(بما فيها الحارس المركزي لـ DRY_RUN)، وسيناريوهات الترخيص الكاملة. لا
تحتاج اتصال إنترنت ولا مفاتيح Binance حقيقية.

## للبائع فقط: إصدار تراخيص للمشترين
راجع `seller_tools/` (حزمة منفصلة، **لا تُشحن مع المشتري أبداً**):
1. مرة واحدة: `python3 generate_keypair.py` (ينتج المفتاح الخاص —
   احتفظ به سرياً — والمفتاح العام الذي يوضع في `license.py`).
2. لكل عملية بيع: `python3 generate_license.py --licensee "اسم" --days 365`.
3. لربط بجهاز: اطلب من المشتري `python3 main.py --print-hwid`.

دليل تعتيم الكود (اختياري، للحماية الإضافية): `PYARMOR_GUIDE.md`.
