#!/usr/bin/env bash
# يذكّرك بالتحقق من أن DRY_RUN=True أو USE_TESTNET=True قبل التشغيل.
# هذا السكربت لا يعدّل main.py تلقائياً - تحقق يدوياً من قسم USER CONFIGURATION.
echo "تحقق أن USE_TESTNET=True أو DRY_RUN=True في main.py قبل المتابعة."
read -p "اضغط Enter للمتابعة أو Ctrl+C للإلغاء..."
python3 main.py
