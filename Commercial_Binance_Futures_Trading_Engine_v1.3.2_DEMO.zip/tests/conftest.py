# -*- coding: utf-8 -*-
"""
conftest.py - يجهّز نسخة معزولة قابلة للاستيراد من main.py لكل اختبار.

main.py مصمَّم كملف تنفيذي واحد (بطلب صريح من مواصفات المشروع: "ONE FILE،
بدون تقسيم src/") ويُنفّذ كوداً حقيقياً عند الاستيراد (تحميل .env، تحقق
ترخيص، إنشاء StateStore على قرص). لذلك هذا الملف:

1. ينسخ main.py و license.py إلى مجلد مؤقت معزول لكل اختبار.
2. يولّد زوج مفاتيح Ed25519 اختباري ويوقّع به ترخيصاً صالحاً، ويضع المفتاح
   العام داخل نسخة license.py المؤقتة (بدل القيمة الصفرية الافتراضية).
3. يكتب .env صالحاً (مفاتيح Binance وهمية - لا يوجد اتصال شبكة حقيقي).
4. يضيف حزمة binance وهمية (fake_pkgs/) إلى sys.path لأن python-binance
   غير مثبَّت في بيئة الاختبار هذه (بلا اتصال إنترنت).
5. يستورد main.py المنسوخ كوحدة اسمها "bot" ويعيدها لكل اختبار.

⚠ لأن كل اختبار يستورد نسخة جديدة من main.py في مجلد مختلف، StateStore
(قاعدة بيانات SQLite) تبدأ فارغة في كل مرة - وهذا مقصود ومفيد للعزل بين
الاختبارات.
"""
import base64
import importlib.util
import json
import re
import os
import shutil
import sys
from pathlib import Path

import pytest

REPO_ROOT = Path(__file__).resolve().parent.parent
FAKE_PKGS = REPO_ROOT.parent / "fake_pkgs"

if str(FAKE_PKGS) not in sys.path:
    sys.path.insert(0, str(FAKE_PKGS))


def _b64u(data: bytes) -> str:
    return base64.urlsafe_b64encode(data).rstrip(b"=").decode("ascii")


def _make_test_keypair_and_license():
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
    from cryptography.hazmat.primitives.serialization import Encoding, PublicFormat
    priv = Ed25519PrivateKey.generate()
    pub = priv.public_key().public_bytes(encoding=Encoding.Raw, format=PublicFormat.Raw)
    payload = {"product": "cbfte-v1", "licensee": "pytest", "issued": "2026-01-01",
               "expires": None, "hwid": None}
    payload_bytes = json.dumps(payload, separators=(",", ":"), sort_keys=True).encode("utf-8")
    sig = priv.sign(payload_bytes)
    license_key = _b64u(payload_bytes) + "." + _b64u(sig)
    return priv, pub.hex(), license_key


def sign_license_payload(priv, payload: dict) -> str:
    """يُستخدم من ملفات الاختبار لتوقيع تراخيص إضافية (منتهية، مربوطة
    بجهاز، إلخ) بنفس المفتاح الخاص الذي يطابق PUBLIC_KEY_HEX في نسخة
    license.py المعزولة الخاصة بهذا الاختبار."""
    pb = json.dumps(payload, separators=(",", ":"), sort_keys=True).encode("utf-8")
    sig = priv.sign(pb)
    return _b64u(pb) + "." + _b64u(sig)


@pytest.fixture()
def bot(tmp_path, monkeypatch):
    """يستورد نسخة معزولة من main.py صالحة للاختبار، ويعيدها كوحدة.

    المفتاح الخاص للاختبار متاح كـ bot._TEST_LICENSE_PRIVATE_KEY لمن
    يحتاج توقيع تراخيص إضافية (انظر test_license.py)."""
    dst_main = tmp_path / "main.py"
    dst_license = tmp_path / "license.py"
    shutil.copy(REPO_ROOT / "main.py", dst_main)
    shutil.copy(REPO_ROOT / "license.py", dst_license)

    priv, pub_hex, license_key = _make_test_keypair_and_license()
    lic_src = dst_license.read_text(encoding="utf-8")
    lic_src = re.sub(
        r'PUBLIC_KEY_HEX = "[0-9a-fA-F]{64}"',
        f'PUBLIC_KEY_HEX = "{pub_hex}"',
        lic_src,
    )
    dst_license.write_text(lic_src, encoding="utf-8")

    env_content = (
        "BINANCE_API_KEY=test_key_not_real\n"
        "BINANCE_API_SECRET=test_secret_not_real\n"
        "TELEGRAM_TOKEN=\n"
        "TELEGRAM_CHAT_ID=\n"
        f"LICENSE_KEY={license_key}\n"
    )
    (tmp_path / ".env").write_text(env_content, encoding="utf-8")

    monkeypatch.chdir(tmp_path)
    monkeypatch.setattr(sys, "argv", ["main.py"])
    monkeypatch.syspath_prepend(str(tmp_path))

    mod_name = f"bot_under_test_{id(tmp_path)}"
    # "license" هو اسم وحدة عام في sys.modules (عبر كل العملية)، وليس محلياً
    # لكل bot معزول - بدون هذا التنظيف، الاختبار الثاني والثالث وما بعدهما
    # سيعيدان استخدام وحدة license.py من أول bot تم تحميله في هذه العملية
    # (بمفتاحه العام هو، وليس المفتاح الخاص بهذا الاختبار) بدل نسختهما
    # المعزولة الفعلية.
    sys.modules.pop("license", None)
    spec = importlib.util.spec_from_file_location(mod_name, dst_main)
    module = importlib.util.module_from_spec(spec)
    sys.modules[mod_name] = module
    spec.loader.exec_module(module)
    module._TEST_LICENSE_PRIVATE_KEY = priv
    yield module
    sys.modules.pop(mod_name, None)


class _FakeClientForFilters:
    """عميل وهمي يُرجع فلاتر رمز TESTUSDT ثابتة (step/tick/min_notional)
    - يُستخدم لاختبار SymbolFilters وcalculate_position_size بلا شبكة."""
    def futures_exchange_info(self):
        return {"symbols": [{
            "symbol": "TESTUSDT",
            "filters": [
                {"filterType": "LOT_SIZE", "stepSize": "0.001", "minQty": "0.001", "maxQty": "1000"},
                {"filterType": "PRICE_FILTER", "tickSize": "0.01"},
                {"filterType": "MIN_NOTIONAL", "notional": "5.0"},
                {"filterType": "MAX_NUM_ORDERS", "limit": "200"},
            ],
        }]}


@pytest.fixture()
def symbol_filters(bot):
    """SymbolFilters جاهز لرمز TESTUSDT وهمي (step=0.001, tick=0.01, min_notional=5.0)."""
    return bot.SymbolFilters(_FakeClientForFilters(), "TESTUSDT")
