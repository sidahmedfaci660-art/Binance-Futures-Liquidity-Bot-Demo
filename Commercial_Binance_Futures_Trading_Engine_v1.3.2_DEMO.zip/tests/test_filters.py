"""اختبارات فلاتر الرمز: تقريب step size / tick size / min notional."""


def test_filters_parse_correctly(symbol_filters):
    assert symbol_filters.step_size == 0.001
    assert symbol_filters.tick_size == 0.01
    assert symbol_filters.min_notional == 5.0


def test_clamp_qty_rounds_to_step_size(symbol_filters):
    q = symbol_filters.clamp_qty(1.2347, price=10.0, respect_min_notional=False)
    assert abs(q - 1.234) < 1e-9


def test_clamp_qty_enforces_min_notional(symbol_filters):
    # 0.01 * 10.0 = 0.10 notional, well below min_notional=5.0
    q = symbol_filters.clamp_qty(0.01, price=10.0, respect_min_notional=True)
    assert q * 10.0 >= symbol_filters.min_notional


def test_clamp_qty_rejects_zero_or_negative_inputs(symbol_filters):
    assert symbol_filters.clamp_qty(0, 10.0) == 0.0
    assert symbol_filters.clamp_qty(1.0, 0) == 0.0
    assert symbol_filters.clamp_qty(-5, 10.0) == 0.0
