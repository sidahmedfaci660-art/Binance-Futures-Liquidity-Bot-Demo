"""اختبارات StateStore (SQLite) الأساسية على قاعدة بيانات فارغة جديدة."""


def test_fresh_store_has_zero_trades(bot):
    wins, n = bot.STORE.get_strategy_win_stats()
    assert n == 0
    assert isinstance(wins, int)
    assert isinstance(n, int)


def test_fresh_store_last_trade_was_loss_is_false(bot):
    assert bot.STORE.last_trade_was_loss() is False
