"""اختبارات حجم الصفقة: calculate_position_size() - المصدر الوحيد لحساب
الحجم والمخاطرة في المشروع."""


def test_valid_sizing_produces_positive_quantity(bot, symbol_filters):
    res = bot.calculate_position_size(
        symbol_filters, equity=100.0, available_balance=100.0,
        entry_price=10.0, effective_stop_loss_pct=0.01,
    )
    assert res["valid"] is True
    assert res["qty"] > 0


def test_sizing_respects_margin_cap(bot, symbol_filters):
    res = bot.calculate_position_size(
        symbol_filters, equity=100.0, available_balance=100.0,
        entry_price=10.0, effective_stop_loss_pct=0.01,
    )
    if res["valid"]:
        cap = 100.0 * bot.CFG.MAX_MARGIN_PCT
        assert res["margin_used"] <= cap * 1.001


def test_sizing_respects_max_stop_loss_cap(bot, symbol_filters):
    res = bot.calculate_position_size(
        symbol_filters, equity=100.0, available_balance=100.0,
        entry_price=10.0, effective_stop_loss_pct=0.01,
    )
    if res["valid"]:
        assert res["sl_pct"] <= bot.CFG.MAX_STOP_LOSS_PCT + 1e-9


def test_invalid_entry_price_is_rejected_not_crashed(bot, symbol_filters):
    res = bot.calculate_position_size(
        symbol_filters, equity=100.0, available_balance=100.0,
        entry_price=0.0, effective_stop_loss_pct=0.01,
    )
    assert res["valid"] is False
    assert res["qty"] == 0.0


def test_invalid_stop_loss_pct_is_rejected(bot, symbol_filters):
    res = bot.calculate_position_size(
        symbol_filters, equity=100.0, available_balance=100.0,
        entry_price=10.0, effective_stop_loss_pct=0.0,
    )
    assert res["valid"] is False


def test_extremely_tiny_equity_is_rejected_not_crashed(bot, symbol_filters):
    res = bot.calculate_position_size(
        symbol_filters, equity=0.01, available_balance=0.01,
        entry_price=10.0, effective_stop_loss_pct=0.01,
    )
    assert res["valid"] is False
    assert res["qty"] == 0.0
