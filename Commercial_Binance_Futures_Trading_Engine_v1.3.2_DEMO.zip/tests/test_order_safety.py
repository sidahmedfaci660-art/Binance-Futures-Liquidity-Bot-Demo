"""أهم اختبار أمان في المشروع: create_order_idempotent() يجب ألا يُرسل
أمراً مكرراً حتى لو ظهر خطأ عابر بعد أن يكون الأمر قد نُفّذ فعلياً على
منصة Binance (رد فقدته الشبكة، مهلة انتهت، إلخ)."""


class _FakeClientIdempotent:
    """يحاكي: المحاولة الأولى تنفّذ الأمر فعلاً على "المنصة" لكن ترفع خطأ
    عابر (كأن الرد ضاع)؛ يجب أن تبحث المحاولة الثانية عن الأمر بنفس
    newClientOrderId وتجده، بدل إرسال أمر جديد مكرر."""

    def __init__(self, bot):
        self.bot = bot
        self.create_calls = 0
        self.orders = {}

    def futures_create_order(self, **kwargs):
        self.create_calls += 1
        cid = kwargs["newClientOrderId"]
        if self.create_calls == 1:
            self.orders[cid] = {
                "orderId": 12345, "status": "NEW", "executedQty": "0",
                "symbol": kwargs.get("symbol"),
            }
            raise self.bot.BinanceAPIException(
                "simulated lost response", code=-1001, status_code=500
            )
        # لو وصلنا هنا فهذا يعني أن الحماية فشلت وأُرسل أمر ثانٍ فعلياً
        self.orders[cid] = {
            "orderId": 99999, "status": "NEW", "executedQty": "0",
            "symbol": kwargs.get("symbol"),
        }
        return self.orders[cid]

    def futures_get_order(self, symbol, origClientOrderId):
        existing = self.orders.get(origClientOrderId)
        if not existing:
            raise Exception("order not found")
        return existing


def test_no_duplicate_order_after_transient_error(bot):
    fc = _FakeClientIdempotent(bot)
    order = bot.create_order_idempotent(
        fc, "test_order", symbol="TESTUSDT", side="BUY", type="MARKET",
        quantity=1.0, newClientOrderId="fixed-test-cid-001",
    )
    # يجب أن يُعاد الأمر الأصلي (orderId=12345) الذي نُفّذ فعلاً في المحاولة
    # الأولى، وليس أمراً جديداً (orderId=99999) من محاولة ثانية.
    assert order["orderId"] == 12345
    # والأهم: futures_create_order يجب ألا يُستدعى إلا مرة واحدة فقط.
    assert fc.create_calls == 1


class _ExplodingClient:
    """أي استدعاء حقيقي على هذا العميل يفشل الاختبار فوراً - يثبت أن
    create_order_idempotent لا يلمس الشبكة إطلاقاً في DRY_RUN، من أي
    مسار استدعاء (ليس فقط open_trade، بل أيضاً Trailing/إعادة بناء
    الحماية اليتيمة/الإغلاق الطارئ - كل ما يمر عبر هذه الدالة)."""

    def futures_create_order(self, **kwargs):
        raise AssertionError("BUG: real futures_create_order was called during DRY_RUN!")

    def futures_get_order(self, **kwargs):
        raise AssertionError("BUG: real futures_get_order was called during DRY_RUN!")


def test_dry_run_never_touches_the_real_client_from_any_call_site(bot):
    """اختبار الحارس المركزي: حتى لو استُدعيت create_order_idempotent من
    مسار غير open_trade (مثل تحديث Trailing Stop على مركز حقيقي موجود
    مسبقاً في الحساب)، يجب ألا يصل أي استدعاء حقيقي لعميل Binance."""
    bot.CFG.DRY_RUN = True
    order = bot.create_order_idempotent(
        _ExplodingClient(), "trailing_stop_update_simulated",
        symbol="TESTUSDT", side="SELL", type="STOP_MARKET",
        stopPrice="123.45", closePosition=True,
        newClientOrderId="dryrun-guard-cid-001",
    )
    assert order["_simulated_dry_run"] is True
    assert order["clientOrderId"] == "dryrun-guard-cid-001"
    assert order["status"] in ("NEW", "FILLED")
