"""اختبارات نظام الترخيص (license.py) عبر bot._license_mod - نفس الوحدة
التي يستخدمها main.py فعلياً عند الإقلاع."""
import os

import pytest
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey

from tests.conftest import sign_license_payload


def test_valid_license_is_accepted(bot):
    info = bot._license_mod.verify_license_key(os.environ["LICENSE_KEY"])
    assert info.licensee == "pytest"


def test_garbage_key_is_rejected(bot):
    with pytest.raises(bot._license_mod.LicenseError):
        bot._license_mod.verify_license_key("not-a-real-key")


def test_empty_key_is_rejected(bot):
    with pytest.raises(bot._license_mod.LicenseError):
        bot._license_mod.verify_license_key("")


def test_license_signed_by_different_keypair_is_rejected(bot):
    other_priv = Ed25519PrivateKey.generate()
    key = sign_license_payload(other_priv, {
        "product": "cbfte-v1", "licensee": "attacker",
        "issued": "2026-01-01", "expires": None, "hwid": None,
    })
    with pytest.raises(bot._license_mod.LicenseError):
        bot._license_mod.verify_license_key(key)


def test_tampered_license_signature_is_rejected(bot):
    key = os.environ["LICENSE_KEY"]
    tampered = key[:-1] + ("A" if key[-1] != "A" else "B")
    with pytest.raises(bot._license_mod.LicenseError):
        bot._license_mod.verify_license_key(tampered)


def test_expired_license_is_rejected(bot):
    key = sign_license_payload(bot._TEST_LICENSE_PRIVATE_KEY, {
        "product": "cbfte-v1", "licensee": "pytest",
        "issued": "2020-01-01", "expires": "2020-01-02", "hwid": None,
    })
    with pytest.raises(bot._license_mod.LicenseError, match="انتهت"):
        bot._license_mod.verify_license_key(key)


def test_future_expiry_license_is_accepted(bot):
    key = sign_license_payload(bot._TEST_LICENSE_PRIVATE_KEY, {
        "product": "cbfte-v1", "licensee": "pytest",
        "issued": "2026-01-01", "expires": "2099-01-01", "hwid": None,
    })
    info = bot._license_mod.verify_license_key(key)
    assert info.expires == "2099-01-01"


def test_wrong_hwid_binding_is_rejected(bot):
    key = sign_license_payload(bot._TEST_LICENSE_PRIVATE_KEY, {
        "product": "cbfte-v1", "licensee": "pytest",
        "issued": "2026-01-01", "expires": None, "hwid": "DEADBEEF00000000",
    })
    with pytest.raises(bot._license_mod.LicenseError, match="جهاز"):
        bot._license_mod.verify_license_key(key)


def test_correct_hwid_binding_is_accepted(bot):
    current_hwid = bot._license_mod.compute_hwid()
    key = sign_license_payload(bot._TEST_LICENSE_PRIVATE_KEY, {
        "product": "cbfte-v1", "licensee": "pytest",
        "issued": "2026-01-01", "expires": None, "hwid": current_hwid,
    })
    info = bot._license_mod.verify_license_key(key)
    assert info.hwid == current_hwid


def test_wrong_product_id_is_rejected(bot):
    key = sign_license_payload(bot._TEST_LICENSE_PRIVATE_KEY, {
        "product": "some-other-product", "licensee": "pytest",
        "issued": "2026-01-01", "expires": None, "hwid": None,
    })
    with pytest.raises(bot._license_mod.LicenseError):
        bot._license_mod.verify_license_key(key)


def test_missing_license_key_blocks_startup_via_check_license_or_exit(bot, monkeypatch):
    monkeypatch.delenv("LICENSE_KEY", raising=False)
    with pytest.raises(SystemExit) as exc_info:
        bot._license_mod.check_license_or_exit()
    assert exc_info.value.code == 1
