# -*- coding: utf-8 -*-
"""
================================================================================
 Commercial Binance Futures Trading Engine — v1.0.0
================================================================================
محرك تداول آلي لعقود Binance Futures، ملف Python واحد (source-available)،
مبني على محرك إشارة متعدد الطبقات (سعر/هيكل + إحصاء) مع إدارة مخاطرة
وحماية أوامر مخصصة لبيئات اتصال غير مستقرة (مثل التشغيل على هاتف عبر Termux).

المميزات التقنية:
  - كشف إشارة متعدد المصادر: BOS/retest، sweep/liquidity، exhaustion/
    reversal، sr_touch، trend_riding.
  - مرشح كالمان (خط سعر عادل + حارس انهيار) و Wick Z-Score لندرة الفتيل.
  - مؤشر هيرست لتصنيف نظام السوق (trending/mean-reverting).
  - حجم مركز بمعادلة كيلي الجزئية (Fractional Kelly) مع نمو مركّب حي.
  - SL/TP ديناميكيان (structure/ATR) + حماية أرباح متدرجة حسب R + Trailing.
  - قاطع دائري (circuit breaker) وحماية تراجع يومي وخسائر متتالية.
  - استرجاع كامل للحالة بعد إعادة التشغيل/انقطاع الإنترنت، مع مطابقة
    مباشرة مع حالة Binance الحقيقية (Binance = مصدر الحقيقة).
  - أوامر إنشاء idempotent عبر newClientOrderId لمنع تكرار الصفقات.
  - تحكم وتنبيهات عبر Telegram، وإحصاءات أداء حقيقية من سجل التداول.

⚠ هذا برنامج، وليس نصيحة مالية. لا توجد أرباح أو نسبة نجاح مضمونة.
تداول العقود الآجلة عالي المخاطر. اختبر دائماً على TESTNET أو DRY_RUN
قبل أي تشغيل حقيقي، وراجع RISK_DISCLAIMER.md قبل الاستخدام.

كل الإعدادات القابلة للتعديل (العملات، الرافعة، رأس المال، المخاطرة،
SL/TP، Telegram، إلخ) موجودة في قسم USER CONFIGURATION أدناه — وهي
المرجع الوحيد الفعلي لأي رقم تشغيل، وليس هذا الملخص.

المتطلبات:
    pip install --upgrade python-binance pandas numpy requests python-dotenv
الإعداد:
    ملف .env بجانب هذا الملف يحتوي على المفاتيح (انظر .env.example).
================================================================================
"""

import os
import sys
import json
import time
import sqlite3
import logging
import threading
import uuid
import atexit
from collections import deque
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from decimal import Decimal, ROUND_DOWN, ROUND_UP, InvalidOperation
from typing import Optional, Callable, Any

import numpy as np
import pandas as pd
import requests
from binance.client import Client
# WebSocket معطّل - نستخدم REST فقط للاستقرار على Termux
ThreadedWebsocketManager = None
try:
    from binance import ThreadedWebsocketManager as _TWM
    ThreadedWebsocketManager = _TWM
except ImportError:
    try:
        from binance.streams import ThreadedWebsocketManager as _TWM
        ThreadedWebsocketManager = _TWM
    except ImportError:
        pass
from binance.exceptions import BinanceAPIException, BinanceOrderException

# تحميل الإعدادات من .env عبر python-dotenv
try:
    from dotenv import load_dotenv
except ImportError:
    print("[FATAL] الحزمة python-dotenv غير مثبتة. شغّل: pip install -r requirements.txt")
    sys.exit(1)

_ENV_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), ".env")
if not os.path.isfile(_ENV_PATH):
    print(f"[FATAL] ملف .env غير موجود ({_ENV_PATH}). انسخ .env.example إلى .env وعدّله أولاً.")
    sys.exit(1)
load_dotenv(_ENV_PATH, override=True)  # .env هو مصدر الحقيقة دائماً - يطغى على أي متغير بيئة سابق بنفس الاسم

if len(sys.argv) > 1 and sys.argv[1] == "--print-hwid":
    # طباعة معرّف الجهاز فقط (بلا تحقق ترخيص) - للمشتري ليرسله للبائع
    # عند طلب ترخيص مربوط بجهاز معيّن.
    import license as _license_mod
    print("HWID:", _license_mod.compute_hwid())
    sys.exit(0)

os.environ["TELEGRAM_BOT_TOKEN"] = os.getenv("TELEGRAM_TOKEN", "")

import license as _license_mod
_license_mod.check_license_or_exit()

class FatalBotError(RuntimeError):
    """أخطاء لا يجوز أبداً إعادة تشغيل البوت تلقائياً بعدها - تعني حالة
    قد يكون فيها قرار تلقائي إضافي خطراً (تعارض مركز، فشل استرجاع حماية،
    إلخ). run_forever() يتوقف نهائياً عند هذا النوع بدل إعادة المحاولة،
    ويتطلب مراجعة يدوية صريحة قبل أي تشغيل لاحق."""
    pass
from binance.enums import SIDE_BUY, SIDE_SELL, TIME_IN_FORCE_GTC

# توافق مع إصدارات python-binance المختلفة (أسماء ثوابت تغيّرت)
try:
    from binance.enums import (
        ORDER_TYPE_MARKET,
        ORDER_TYPE_LIMIT,
        ORDER_TYPE_STOP_MARKET,
        ORDER_TYPE_TAKE_PROFIT_MARKET,
    )
except ImportError:
    try:
        from binance.enums import (
            FUTURE_ORDER_TYPE_MARKET as ORDER_TYPE_MARKET,
            FUTURE_ORDER_TYPE_LIMIT as ORDER_TYPE_LIMIT,
            FUTURE_ORDER_TYPE_STOP_MARKET as ORDER_TYPE_STOP_MARKET,
            FUTURE_ORDER_TYPE_TAKE_PROFIT_MARKET as ORDER_TYPE_TAKE_PROFIT_MARKET,
        )
    except ImportError:
        # قيم نصية مباشرة متوافقة مع REST API لـ Binance Futures
        ORDER_TYPE_MARKET = "MARKET"
        ORDER_TYPE_LIMIT = "LIMIT"
        ORDER_TYPE_STOP_MARKET = "STOP_MARKET"
        ORDER_TYPE_TAKE_PROFIT_MARKET = "TAKE_PROFIT_MARKET"

# ==============================================================================
# 1) الإعدادات
# ==============================================================================

@dataclass
class Config:
    # ================================================================
    # ================ USER CONFIGURATION (ابدأ هنا) ================
    # ================================================================
    # هذا القسم هو ما يحتاج المشتري تعديله عادة: وضع التشغيل، العملات،
    # الرافعة، رأس المال، المخاطرة، SL/TP، الفلاتر. القيم التالية هي
    # الإعدادات الفعلية التي يعتمد عليها المحرك الحالي - لم تُغيَّر هنا.
    # (مفاتيح Binance/Telegram توضع في .env الخارجي، وليس هنا،
    # حفاظاً على الأسرار خارج ملف المصدر - راجع .env.example)
    USE_TESTNET: bool = False
    DRY_RUN: bool = False

    # === اختيار العملة: 1000SATSUSDT/ZECUSDT/XRPUSDT، صفقة واحدة فقط في نفس الوقت
    # (بطلب صريح من المستخدم - محدَّث لتطابق الإعدادات الفعلية الحالية، كانت SOL/WIF قديماً) ===
    SYMBOL_SELECTION_MODE: str = "FIXED_LIST"
    PREFERRED_SYMBOL: str = "1000SATSUSDT"
    CANDIDATE_SYMBOLS: tuple = (
        "1000SATSUSDT",
        "ZECUSDT",
        "XRPUSDT",
    )
    # صفقة واحدة فقط بسبب صغر رأس المال (5$) - لا تقسيم لرأس المال، كل
    # صفقة تستخدم equity كاملاً (بطلب صريح: CAPITAL_SPLIT_COUNT=1)
    CAPITAL_SPLIT_COUNT: int = 1  # بطلب صريح: "راس مال كله في صفقة واحدة مع النمو المركب"
    SYMBOL_SWITCH_MIN_SCORE_IMPROVEMENT: float = 0.10
    SYMBOL_RESCAN_INTERVAL_MIN: int = 15
    # === وضع تشخيص - مفعّل بطلب صريح لضمان أن البوت يبدأ بالتنفيذ فعلياً ===
    DIAGNOSTIC_MODE: bool = True
    DIAGNOSTIC_MIN_QUALITY: float = 0.38
    # للتوافق مع الكود القديم فقط (يُحدَّث ديناميكياً عند اختيار الرمز الفعلي)
    SYMBOL: str = "1000SATSUSDT"
    SYMBOLS: tuple = CANDIDATE_SYMBOLS  # الفحص الفعلي: حلقة for على هاتين العملتين بالضبط، بلا أي اختيار/تبديل تلقائي

    CAPITAL_USDT: float = 5.0  # [Glama 5] رأس المال الفعلي الحالي للمستخدم (كان 7.0) - مرجع تحجيم الأهداف بالنمو المركب

    # === [Glama 2] نظام الأهداف الصافية بالدولار ===
    # الربح الصافي = بعد عمولة الدخول+الخروج والانزلاق. الوقف = أقصى خسارة كاملة (تشمل العمولة).
    # [Glama 4 - بند 4/8 من تقرير التطوير] b = NET_TARGET_USDT/MAX_LOSS_USDT
    # يحدد نسبة RR الأساسية المستهدفة في calculate_position_size. رُفعت
    # من 0.60/0.40=1.5R إلى 0.72/0.40=1.8R (منتصف مدى 1.8R-2.2R المطلوب) -
    # صفقة رابحة يجب أن تحصل على مساحة كافية بدل هدف قريب جداً.
    NET_TARGET_USDT: float = 0.72       # [Glama 4] كان 0.60 → b=1.8 (غيّرها لهدف أكبر عند نمو رأس المال)
    MAX_LOSS_USDT: float = 0.40        # وقف خسارة صارم
    COMPOUND_DOLLAR_TARGETS: bool = True   # تُضرب الأهداف بـ equity/CAPITAL_USDT (نمو مركب حي؛ ونزولاً عند الخسارة)
    TARGET_SCALE_MIN: float = 0.30
    TARGET_SCALE_MAX: float = 4.00

    # === معادلة كيلي الجزئية (Fractional Kelly) ===
    KELLY_FRACTION: float = 0.5            # نصف كيلي
    KELLY_PRIOR_WIN_RATE: float = 0.50     # نسبة فوز افتراضية تُمزج مع الإحصاء الحي
    KELLY_PRIOR_WEIGHT: int = 10           # وزن الافتراض بعدد صفقات وهمية
    KELLY_MIN_RISK_PCT_EQUITY: float = 0.02   # حد أدنى للمخاطرة لو كيلي <= 0 (لا نوقف البوت، نصغّر الحجم)

    # === وضع التعافي بعد صفقة خاسرة ===
    # [Glama 4 - بند 4 من تقرير التطوير الهجومي] Recovery = Defensive Risk
    # Mode وليس Revenge Mode: لا يجوز أبداً تخفيض هدف الربح (TP) أو نسبة
    # RR بعد خسارة - ذلك يجعل الصفقة التالية أسوأ جودة فعلياً بدل أن تكون
    # أكثر حذراً. التعافي الوحيد المسموح هو تخفيض الحجم (انظر
    # REDUCED_RISK_AFTER_LOSSES وREDUCED_RISK_PCT وتدرّج open_trade).
    RECOVERY_TP_REDUCTION_PCT: float = 0.0    # [Glama 4] كان 0.25 - أُلغي كلياً بطلب التقرير (بند 4)
    RECOVERY_QUALITY_BOOST: float = 0.05      # رفع عتبة الجودة (يبقى - جودة أعلى بعد خسارة أمر جيد)
    RECOVERY_MIN_RR: float = 1.8              # [Glama 4] كان 1.10 - لا يجوز أن ينزل RR أثناء التعافي أبداً تحت الأساس

    # === مرشح كالمان + Z-Score للفتيل ===
    KALMAN_Q_OVER_R: float = 0.10
    KALMAN_CRASH_GUARD: bool = True
    KALMAN_CRASH_ATR_MULT: float = 3.0        # السعر بعيد عن الخط العادل > 3 ATR ...
    KALMAN_CRASH_SLOPE_ATR_MULT: float = 1.0  # ... والخط نفسه يهبط/يصعد > 1 ATR خلال 5 شموع = انهيار حقيقي
    # [Glama 4 - بند 2/6 من تقرير التطوير الهجومي] Wick Z-Score لم يعد
    # بوابة رفض صارمة عند أي قيمة تحت 2.0 - ذلك كان يقتل إشارات "متوسطة
    # الجودة" بالكامل رغم أن بقية أدلة الإشارة (حجم/دلتا/هيكل) قد تكون
    # قوية. الرفض الحقيقي الآن فقط عند فتيل شبه معدوم إحصائياً
    # (WICK_Z_HARD_FLOOR) - وما بينهما مكافأة/عقوبة نقاط متدرّجة في
    # detect_signal (انظر _wick_z_score_bonus أدناه)، وليس رفضاً قاطعاً.
    WICK_Z_REQUIRED: bool = True
    WICK_Z_MIN: float = 2.0             # يبقى مرجع "فتيل قوي/نادر" لمكافأة النقاط القصوى
    WICK_Z_HARD_FLOOR: float = 0.6      # [Glama 4] جديد - الرفض القاطع الوحيد يبقى تحت هذي القيمة (فتيل شبه معدوم)
    WICK_Z_LOOKBACK: int = 30
    WICK_Z_EXEMPT_SOURCES: tuple = ("trend_riding",)   # ركوب الاتجاه لا يعتمد على فتيل، فلا يخضع لشرط Z

    # --- [INTELLIGENT INJECTIONS 2026] ---
    ENABLE_DYNAMIC_SCANNER: bool = True       # ماسح ديناميكي لأكثر العملات حركة
    MAX_SCANNER_SYMBOLS: int = 15             # أعلى 15 عملة حركةً ونشاطاً، تُحدَّث كل ساعة
    SCANNER_ALWAYS_INCLUDE_CANDIDATES: bool = True   # تبقى عملاتك المختارة (1000SATS/ZEC/XRP) ضمن الفحص دائماً
    HURST_LOOKBACK: int = 100                 # فترة ذاكرة السعر لحساب هيرست
    ENABLE_TREND_RIDING: bool = True          # ركوب الاتجاه العنيف
    TREND_RIDING_MOMENTUM_MIN: float = 0.012  # حد أدنى 1.2% خلال آخر 5 شموع
    TREND_RIDING_MIN_VOLUME_RATIO: float = 1.0   # لا ركوب اتجاه بحجم أضعف من متوسط آخر 20 شمعة
    # [Glama 5] لا ركوب اتجاه لو السعر أصلاً بعيد أكثر من هذا القدر (بوحدات
    # ATR) عن EMA20 بنفس الاتجاه - يمنع "شراء قمة/بيع قاع" حركة ناضجة فعلاً
    TREND_RIDING_MAX_EXTENSION_ATR: float = 2.0

    # ترحيل لمرة واحدة عند أول تشغيل: يفرض إعدادات القواطع/الرموز الجديدة فوق قاعدة البيانات القديمة
    FORCE_CONFIG_ON_FIRST_RUN: bool = True
    # (calculate_position_size هي الدالة الوحيدة التي تحسب الحجم - لا يوجد
    # أي مسار بديل. القاعدة القديمة "نسبة ثابتة من الهامش" أُزيلت نهائياً
    # لأنها كانت تسمح بخسارة صفقة واحدة تبتلع جزءاً كبيراً من الحساب
    # بصرف النظر عن الرافعة.)
    MAX_RISK_PER_TRADE_EQUITY_PCT: float = 0.25  # سقف مطلق: 25% من Equity (بطلب صريح)
    MAX_MARGIN_PCT: float = 0.90  # بطلب صريح
    MIN_MARGIN_PCT: float = 0.08
    LEVERAGE: int = 7              # افتراضي محافظ
    MAX_ALLOWED_LEVERAGE: int = 7  # بطلب صريح - سقف 7x بدل 10x
    # [معطّلة] لم تعد مستخدَمة في أي مسار تداول - أُبقيت فقط تفادياً لكسر
    # أي مرجع خارجي محتمل. المصدر الوحيد الفعلي: calculate_position_size().
    MARGIN_SAFETY_RATIO: float = 0.92
    FREE_MARGIN_PCT_PER_TRADE: float = 0.0  # [مُعطَّل نهائياً] راجع calculate_position_size - لا يُستخدم في أي حساب حجم فعلي بعد الآن

    # عمولة Binance Futures (Taker) + هامش انزلاق سعري تحوطي
    TAKER_FEE_RATE: float = 0.0004      # 0.04%
    SLIPPAGE_BUFFER_PCT: float = 0.0006 # بطلب صريح

    USE_TRAILING_STOP: bool = True
    TRAILING_ACTIVATION_PROFIT_PCT: float = 0.014
    TRAILING_DISTANCE_PCT: float = 0.006
    TRAIL_UPDATE_MIN_INTERVAL_SEC: int = 5

    # === محرك حماية الأرباح المتدرّج حسب R (بطلب صريح) ===
    # R = مسافة السعر المقطوعة لصالح الصفقة ÷ مسافة SL الفعلية بالسعر.
    # لا يتحرك SL للخلف أبداً - كل مستوى أعلى فقط.
    PROFIT_PROTECT_R1: float = 1.0    # عند +1R: القفل الأدنى = التعادل (+تغطية العمولة/الانزلاق)
    PROFIT_PROTECT_R1_5: float = 1.5  # عند +1.5R: قفل لا يقل عن 0.5R
    PROFIT_PROTECT_R2: float = 2.0    # عند +2R: قفل لا يقل عن 1R + مسافة تتبع أوسع
    PROFIT_PROTECT_R3: float = 3.0    # عند +3R: قفل لا يقل عن 1.5R + مساحة أكبر للاتجاه
    PROFIT_PROTECT_LOCK_AT_R1_5: float = 0.5
    PROFIT_PROTECT_LOCK_AT_R2: float = 1.0
    PROFIT_PROTECT_LOCK_AT_R3: float = 1.5
    PROFIT_PROTECT_TRAIL_MULT_R2: float = 1.6
    PROFIT_PROTECT_TRAIL_MULT_R3: float = 2.4
    LARGE_GIVEBACK_WARN_RATIO: float = 0.40
    MIN_PEAK_USDT_FOR_GIVEBACK_WARNING: float = 0.15

    # === الخروج الذكي من الصفقات الراكدة ===
    MAX_HOLDING_HOURS: float = 6.0
    STALE_EXIT_HARD_CAP_HOURS: float = 12.0
    STALE_EXIT_STAGNANT_R_THRESHOLD: float = 0.3
    STALE_EXIT_TIME_SINCE_PEAK_HOURS: float = 3.0

    TIMEFRAME: str = "3m"           # بطلب صريح - استجابة أسرع بكثير (كان 15m)
    HTF_TIMEFRAME: str = "30m"      # فريم تأكيد الاتجاه الأعلى - نُسِّب مع 3m (كان 1h)
    HTF_4H_TIMEFRAME: str = "4h"    # تأكيد اختياري إضافي
    LOOKBACK_CANDLES: int = 120
    SWING_LOOKBACK: int = 5
    MAX_SR_DISTANCE_PCT: float = 0.05
    MIN_VOLUME_RATIO: float = 1.10
    MIN_ATR_TO_FEE_RATIO: float = 1.25

    # --- إدارة عدد المراكز والإشارات: صفقة واحدة فقط بكامل رأس المال
    # (بطلب صريح - Last chance). التبديل بين SOLUSDT وWIFUSDT يحدث تلقائياً:
    # بما أن مركزاً واحداً فقط مسموح، كل مرة يُغلق المركز، الدورة التالية
    # تفحص العملتين من جديد وتفتح على أيهما أعطى إشارة أقوى - قد تكون نفس
    # العملة أو الأخرى، حسب الأنسب لحظتها، بلا أي كود إضافي مطلوب.
    MAX_OPEN_POSITIONS: int = 1
    MAX_SIGNALS_PER_SCAN: int = 1
    # لا هدف عدد صفقات يومي يُجبر البوت على خفض الجودة - بطلب صريح: "تداول
    # فقط عندما توجد فرصة مؤهلة". أُبقي المتغير للتوافق مع نصوص Telegram
    # القديمة لكنه معطَّل فعلياً (0 = بلا هدف).
    TARGET_TRADES_PER_DAY: int = 0
    QUALITY_ADAPT: bool = True   # بطلب صريح
    MIN_QUALITY_FLOOR: float = 0.40   # بطلب صريح
    ALLOW_SR_TOUCH_SIGNAL: bool = True

    AMB_BASE_LEN: int = 8
    AMB_ATR_LEN: int = 7
    AMB_BAND_SMOOTH: int = 8
    AMB_UPPER_MULT: float = 1.5
    AMB_LOWER_MULT: float = 1.5
    AMB_ADAPT_LEN: int = 14
    AMB_FAST_SMOOTH: int = 2
    AMB_SLOW_SMOOTH: int = 10
    REQUIRE_AMB_CONFIRMATION: bool = True

    BB_LENGTH: int = 20
    BB_MULT: float = 2.0
    BB_MIN_PCT: float = 0.25
    BB_MAX_PCT: float = 0.75
    # عتبة جودة دنيا واحدة - أي إشارة تحتها تُرفض كلياً. لا تنزل أبداً تحت
    # MIN_QUALITY_FLOOR (بطلب صريح - بند 6 و25 من ملف المواصفات).
    MIN_QUALITY_SCORE_THRESHOLD: float = 0.47
    # SL/TP لم يعودا نسبة ثابتة صرفة - يُحسبان من structure/ATR (راجع
    # calculate_protection_prices) بحد أقصى MAX_STOP_LOSS_PCT ونسبة
    # مخاطرة:عائد لا تقل عن MIN_RISK_REWARD_RATIO. القيم أدناه تبقى كسقف
    # احتياطي فقط لو تعذّر حساب SL هيكلي.
    FIXED_TAKE_PROFIT_PCT: float = 0.020
    FIXED_STOP_LOSS_PCT: float = 0.012
    MAX_STOP_LOSS_PCT: float = 0.022     # بطلب صريح - سقف مطلق أضيق (كان 0.03)
    # [Glama 4 - بند 4/8/18] رُفع الحد الأدنى التطويري لـRR من 1.5 إلى 1.8
    # (مدى مستهدف 1.8R-2.2R من التقرير)؛ الاستثناء الوحيد كان "أثناء
    # التعافي" وهذا أُلغي (RECOVERY_MIN_RR أصبح = نفس القيمة، لا ينزل عنها).
    MIN_RISK_REWARD_RATIO: float = 1.8   # [Glama 4] كان 1.5
    TARGET_RISK_REWARD_RATIO: float = 2.0  # [Glama 4] كان 1.9 - تقريبي فقط لمنطق التتبع/الركود
    MAX_ENTRY_DRIFT_PCT: float = 0.003   # لو تحرك السعر أكثر من هذا بين الإشارة والتنفيذ، أعد التقييم
    # نسبة الهامش الحر - [مُعطَّلة، أُبقيت فقط للتوافق مع مراجع نصية قديمة]
    # === Risk Gate (نسخة قديمة - حل مكانها الآن MAX_RISK_PER_TRADE_EQUITY_PCT أعلاه) ===
    MAX_RISK_PCT_OF_EQUITY: float = 0.25  # قديم/غير مستخدم - مطابق للسقف أعلاه
    MAX_DAILY_DRAWDOWN_PCT: float = 0.20  # [تنبيه تسمية - بند 5 من تقرير مراجعة ثالث] هذا "الخسارة اليومية المحققة"
    # الفعلية (soft) وليس تراجعاً من القمة رغم الاسم - راجع DAILY_MAX_LOSS_PCT أدناه لتراجع القمة (hard)

    # --- فلتر السبريد والسيولة (بطلب صريح) ---
    MIN_24H_QUOTE_VOLUME_USDT: float = 10_000_000.0

    # --- RSI(14): عامل تأكيد فقط، ليس trigger وحيد (بطلب صريح) ---
    RSI_LENGTH: int = 14
    RSI_OVERBOUGHT: float = 70.0
    RSI_OVERSOLD: float = 30.0

    # --- فلتر Pump/Dump: يمنع الدخول فوراً بعد شمعة انفجارية (بطلب صريح) ---
    PUMP_DUMP_RANGE_ATR_MULT: float = 2.5
    PUMP_DUMP_VOLUME_SPIKE_RATIO: float = 2.5

    # --- تصنيف التذبذب (ATR percentile) ---
    ATR_PERCENTILE_LOOKBACK: int = 150
    ATR_REGIME_QUIET_PCTL: float = 25.0
    ATR_REGIME_HIGH_PCTL: float = 75.0
    ATR_REGIME_EXTREME_PCTL: float = 92.0

    # --- حماية من churn/revenge بعد خسائر متتالية (بطلب صريح، بند 20) ---
    # الطبقة "الناعمة": بعد خسارتين متتاليتين، خفض المخاطرة لثلاث صفقات
    # قادمة بدل إيقاف البوت بالكامل. الطبقة "المتوسطة" (إيقاف 60 دقيقة بعد
    # 3 خسائر متتالية) تُدار عبر قاطع التيار الموجود أدناه مباشرة
    # (MAX_CONSECUTIVE_LOSSES/CIRCUIT_BREAKER_PAUSE_HOURS) - بلا نظام موازٍ
    # منفصل، تفادياً لتكرار مصدر الإعدادات (بند 31 من ملف المواصفات).
    REDUCED_RISK_AFTER_LOSSES: int = 2       # بعد خسارتين متتاليتين
    REDUCED_RISK_PCT: float = 0.03  # بعد خسارتين متتاليتين: مخاطرة 3% من Equity
    REDUCED_RISK_TRADE_COUNT: int = 3



    # --- معايير جودة Liquidity Sweep (V6.1) - كلها قابلة للضبط، لا شيء Hard-coded ---
    SWEEP_VOLUME_MULTIPLIER: float = 1.15       # رُفع بطلب صريح
    SWEEP_REJECTION_STRONG_PCT: float = 0.65    # رُفع بطلب صريح - عتبة الرفض "القوي"
    SWEEP_REJECTION_ACCEPTABLE_PCT: float = 0.48  # رُفع بطلب صريح - فتيل مقبول أعلى
    SWEEP_ATR_PENETRATION_STRONG: float = 0.30  # اختراق >= 0.30×ATR → مكافأة قوية
    SWEEP_ATR_PENETRATION_WEAK: float = 0.15    # اختراق >= 0.15×ATR → مكافأة ضعيفة
    SWEEP_ATR_BONUS_STRONG: float = 0.08
    SWEEP_ATR_BONUS_WEAK: float = 0.03
    REQUIRE_BB_CONFIRMATION: bool = True  # [مُعدَّل] لم يعد رفضاً قاطعاً - يُفعِّل تأثير BB على درجة الجودة فقط (بطلب صريح لزيادة النشاط)

    # --- فلتر زخم ضد السيولة الكاذبة (متوازن) - بطلب صريح (ملف الإصلاحات
    # المتوازنة) - رفض قاطع، ليس خصم نقاط: يمنع SELL أثناء صعود واضح وBUY
    # أثناء هبوط واضح، بدل الاعتماد فقط على شمعة الكسر نفسها.
    ENABLE_MOMENTUM_FILTER: bool = True  # أُعيد تفعيله - المواصفات الجديدة تمنع تعطيل فلاتر الحماية لزيادة عدد الصفقات (بند 44)
    MOMENTUM_LOOKBACK_CANDLES: int = 3
    MOMENTUM_MIN_DIRECTION_RATIO: float = 0.67   # 2 من 3 شموع
    MOMENTUM_MIN_MOVE_PCT: float = 0.004         # 0.4% — ليس ضيقاً جداً

    # --- تأكيد بعد Sweep (منع الدخول على الفتيل وحده) - بطلب صريح - يُطبَّق
    # فقط على مسار signal_source == "sweep"
    REQUIRE_SWEEP_CONFIRMATION: bool = False   # بطلب صريح - عُطِّل (وDIAGNOSTIC_MODE يتجاوزه أصلاً أيضاً)

    # --- منع إعادة الدخول السريع على نفس الرمز بعد إغلاق صفقة عليه
    COOLDOWN_AFTER_CLOSE_MINUTES: int = 0  # صُفِّر بطلب صريح - عملة واحدة فقط، يفتح فوراً بعد الإغلاق

    # --- رادار السيولة الكاذبة/السوق الميت (Structure Break Volume Profile) - بطلب صريح
    RADAR_DEAD_MARKET_VOLUME_RATIO: float = 0.75   # إذا حجم الشمعة الحالية < 75% من متوسط آخر 20 شمعة → سوق ميت
    RADAR_FAKE_WICK_RATIO: float = 0.50            # فتيل يتجاوز 50% من مدى الشمعة
    RADAR_LOW_VOLUME_NODE_RATIO: float = 0.85      # + حجم ضعيف (أقل من 85% من المتوسط) = سيولة كاذبة/فخ حيتان

    # --- تأكيد إضافي اختياري: موجة تصفيات إجبارية (Liquidations) بنفس اتجاه
    # الإشارة - مرتبط مباشرة بفكرة "مصائد السيولة" الأساسية للاستراتيجية.
    # افتراضياً معطّل عمداً: إضافة جديدة غير مُختبرة بعد على بيانات حقيقية،
    # فعّلها بنفسك بعد ما تراقب سلوكها أولاً (Testnet أو DRY_RUN)
    USE_LIQUIDATION_CONFIRMATION: bool = False
    MIN_LIQUIDATION_CONFIRMATION_COUNT: int = 2  # حد أدنى لعدد التصفيات بنفس الاتجاه

    # قاطع التيار (Circuit Breaker) — يُدار بالكامل من تيليجرام:
    # /breaker on|off|reset|pause|losses|drawdown|hours|hard
    CIRCUIT_BREAKER_ENABLED: bool = True
    HARD_LOSS_PROTECTION: bool = True   # حماية 20% تبقى حتى لو عُطّل القاطع العادي — إلا بـ /breaker hard off
    MAX_CONSECUTIVE_LOSSES: int = 2     # [Glama 6] كان 3 - بطلب صريح "قلل الخسائر لصالح الأرباح" بعد 5 أيام خسارة متتالية موثّقة، يوقف أبكر
    CIRCUIT_BREAKER_PAUSE_HOURS: int = 4   # [Glama 6] كان 1 - إيقاف ساعة واحدة كان يسمح بالعودة والخسارة عدة مرات في نفس اليوم
    DAILY_MAX_LOSS_PCT: float = 0.15  # [Glama 6] كان 0.35 (35%!) - متأخر جداً لحساب مجهري؛ 15% تراجع من القمة يوقف البوت لبقية اليوم
    # [تنبيه تسمية - بند 5] هذا هو حقل "التراجع من القمة" (hard_protection) رغم اسمه "loss" -
    # الاسمان معاكسان لما يوحي به ظاهرياً؛ القيم/المنطق صحيحان فعلياً، فقط التسمية مربكة. لم تُغيَّر
    # الأسماء نفسها تفادياً لمخاطرة إعادة تسمية تمس عشرات المواضع بلا فائدة وظيفية حقيقية.

    # إعادة المحاولة
    # ================================================================
    # ============ نهاية USER CONFIGURATION الأساسي ==================
    # ما يلي إعدادات متقدمة/داخلية (إعادة محاولة، مسارات، وسم النسخة،
    # حدود API) - يمكن تعديلها أيضاً، لكنها ليست ما يحتاجه أغلب المشترين
    # عند أول تشغيل. ================================================
    MAX_RETRIES: int = 5
    RETRY_BASE_DELAY_SEC: float = 2.0

    DB_PATH: str = "bot_state.db"
    LOG_FILE: str = "bot_log.jsonl"
    # مُعرّف نصي مميّز لهذه النسخة من البوت - يُستخدم كبادئة لكل newClientOrderId
    # يُنشئه البوت، عشان نقدر نفرّق أوامر هذا البوت عن صفقات يدوية أو نسخة
    # ثانية عند فحص الأوامر المفتوحة على المنصة (بدل الاعتماد فقط على orderId
    # المحفوظ محلياً، اللي يفشل لو ضاعت الحالة المحلية بالكامل)
    BOT_NAME: str = "Commercial Binance Futures Trading Engine"
    SOFTWARE_VERSION: str = "1.3.2"
    BOT_INSTANCE_TAG: str = "cbfte"
    # للتوافق فقط: أي أوامر/مراكز حقيقية مفتوحة على Binance من إصدارات
    # سابقة (Violet Phoenix Fire، Cosmic Phoenix The Supernatural، Ultra
    # Phoenix، Tmax Ultra Phoenix، Phoenix Warrior، Hell's Phoenix، Radiant
    # Grey Phoenix، The Phoenix Message، Fallen Phoenix) تبقى مُتعرَّفاً عليها
    # عند الاسترجاع - لا تُحذف هذي القائمة إلا لو تأكدت أنه لا توجد أي
    # مراكز قديمة مفتوحة من أي إصدار سابق.
    LEGACY_BOT_TAGS: tuple = ("violetphoenixfire", "cosmicphoenixsupernatural", "ultraphoenix",
                              "tmaxultraphoenix", "phoenixwarrior", "hellsphoenix", "radiantgreyphoenix",
                              "thephoenixmessage", "fallenphoenix", "fallenphoenix2", "glama", "glama2",
                              "glama3", "glama4", "glama5", "glama6")
    POSITION_MONITOR_INTERVAL_SEC: int = 4  # بطلب صريح

    # --- Funding Rate ---
    CHECK_FUNDING_RATE: bool = True
    MIN_ACCEPTABLE_FUNDING_RATE: float = -0.0005
    MAX_ACCEPTABLE_FUNDING_RATE: float = 0.0005

    # --- خطر التصفية ---
    LIQUIDATION_DISTANCE_ALERT_PCT: float = 0.03

    # --- Rate Limiting ---
    MAX_REQUESTS_PER_WINDOW: int = 900
    RATE_LIMIT_WINDOW_SEC: int = 60

    # --- حدود المخاطرة والتداول ---
    MAX_TRADES_PER_DAY: int = 999999  # ملغى - يعمل بشكل متواصل
    # [أُزيلت الحقول القديمة غير المستخدمة] RISK_PER_TRADE_PCT وMAX_RISK_OVERAGE_MULTIPLIER
    # كانا يخصان مسار حجم الصفقة القديم (نسبة ثابتة من الهامش) الذي أُزيل
    # بالكامل - المصدر الوحيد الآن هو calculate_position_size() أعلاه
    # (MAX_RISK_PER_TRADE_EQUITY_PCT/MAX_MARGIN_PCT/MIN_MARGIN_PCT/LEVERAGE).
    # أُبقي هذا الحقل وحده لأنه ما زال يُستخدم فعلياً كسقف أمان حساب:
    MIN_FREE_MARGIN_USDT: float = 1.5
    MAX_ALLOWED_SLIPPAGE_PCT: float = 0.008    # أقصى بعد مسموح بين السعر المرجعي ومنتصف دفتر الأوامر
    # لو فشل فحص جودة دفتر الأوامر (شبكة، خطأ API) نفسه، هل نمنع الدخول
    # احتياطاً (الأسلم) أم نسمح به؟ True = الأسلم دائماً (Fail-Closed) -
    # عدم القدرة على التأكد من جودة السوق سبب كافٍ لعدم الدخول، مو للسماح به.
    FAIL_CLOSED_MARKET_CHECKS: bool = True
    MAX_SPREAD_PCT: float = 0.004  # بطلب صريح - سبريد أوسع مسموح (كان مُعرَّفاً مرتين بقيمتين مختلفتين، صُحِّح لتعريف واحد فقط)
    MAX_PRICE_JUMP_PCT: float = 0.035           # قفزة سعر حادة بين شمعتين = إلغاء الإشارة
    MAX_WS_SILENCE_SEC: int = 120
    REQUIRE_IP_RESTRICTION: bool = False  # False عمداً: لا نوقف البوت على الهاتف؛ قيّد المفتاح يدوياً من Binance
    REQUIRE_TESTNET_FIRST: bool = False        # True = يرفض التشغيل الحقيقي كلياً (أمان إضافي أثناء الاختبار)
    LOCK_FILE: str = "bot.lock"

    # --- تقرير أداء دوري ---
    METRICS_REPORT_INTERVAL_HOURS: int = 2
    DUPLICATE_ORDER_CLEANUP_INTERVAL_SEC: int = 90  # زيدت من 300 (5 دقائق) إلى 90 ثانية بطلب صريح

    # --- دخول بأمر LIMIT بدل MARKET ---
    USE_LIMIT_ENTRY: bool = False
    LIMIT_ENTRY_SLIPPAGE_BUFFER_PCT: float = 0.001
    LIMIT_ENTRY_TIMEOUT_SEC: int = 15


CFG = Config()

# ================================================================
# ==================  DEMO BUILD - قفل أمان ثابت  =================
# ================================================================
# هذه نسخة Demo. DRY_RUN و USE_TESTNET مقفولان True هنا بشكل غير
# قابل للتعديل من USER CONFIGURATION أعلاه - أي تعديل هناك لن يُغيّر
# هذا القفل. لا يوجد أمر Telegram لتفعيل LIVE في هذا المشروع أصلاً
# (لا "/live")، لذا هذا القفل عند الإقلاع كافٍ ونهائي لهذه النسخة.
DEMO_BUILD = True
if DEMO_BUILD:
    CFG.DRY_RUN = True
    CFG.USE_TESTNET = True
    print("=" * 60)
    print("  DEMO BUILD - وضع عرض فقط - بلا أي تداول حقيقي")
    print("  DRY_RUN و USE_TESTNET مقفولان True في هذه النسخة")
    print("  للنسخة الكاملة (Pro) تواصل مع البائع")
    print("=" * 60)
# ================================================================

# [إصلاح تدقيق حاسم - "أرضية 20 دولار الوهمية"]: أرضية دنيا رمزية فقط
# (لتفادي قسمة على صفر) لتتبّع "أعلى رصيد شُوهد" - ليست CFG.CAPITAL_USDT
# أبداً. لو استُخدم CAPITAL_USDT=20 كأرضية، فأي حساب حقيقي رصيده أقل من 20
# (كـ14.18 مثلاً) سيُعامَل وكأن قمته التاريخية كانت 20 فوراً، ما يُشغّل
# الحماية الحاسمة (80% من القمة) زوراً حتى بلا أي خسارة تداول حقيقية.
_PEAK_BALANCE_FLOOR = 0.01

# مسارات مطلقة نسبةً لمجلد السكربت (أفضل لتيرمكس عندما يختلف مجلد العمل)
_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
CFG.DB_PATH = os.path.join(_SCRIPT_DIR, os.path.basename(CFG.DB_PATH))
CFG.LOG_FILE = os.path.join(_SCRIPT_DIR, os.path.basename(CFG.LOG_FILE))
CFG.LOCK_FILE = os.path.join(_SCRIPT_DIR, os.path.basename(CFG.LOCK_FILE))

# آخر وقت تحديث للوقف المتحرك (ثواني monotonic) - يمنع إغراق API
_LAST_TRAIL_UPDATE_TS = 0.0
# [Glama 4 - إصلاح خلل حلقة السجل اللانهائية] عدّاد فشل متتالٍ لكل رمز عند
# فشل استبدال SL المتحرك بنفس السبب - يُستخدم لتخفيف السجل (لا نطبع نفس
# ERROR+WARNING كل 5-8 ثوانٍ للأبد) ولتنبيه المستخدم عبر Telegram مرة واحدة
# فقط لو استمر الفشل، بدل بقائه صامتاً في اللوج المحلي فقط.
_TRAIL_FAIL_STREAK: dict = {}
_TRAIL_FAIL_ALERT_THRESHOLD = 6      # ~بعد 6 محاولات فاشلة متتالية (~30-50 ثانية) نُنبّه مرة واحدة


def utc_now() -> datetime:
    """وقت UTC واعٍ بالمنطقة الزمنية - يتجنب مشاكل datetime.utcnow() المهملة."""
    return datetime.now(timezone.utc)


def utc_iso() -> str:
    return utc_now().isoformat()


def utc_today_str() -> str:
    return utc_now().strftime("%Y-%m-%d")


# ==============================================================================
# منع تشغيل أكثر من نسخة واحدة من البوت بنفس الوقت (نفس رأس المال، نفس الرمز)
# تشغيل نسختين بالخطأ يعني حسابين لحجم الصفقة بشكل مستقل قد يفتحان صفقتين!
# ==============================================================================

# fcntl متاح على POSIX فقط (Linux/macOS/Termux). على Windows نستخدم قفل ملفات بديل.
try:
    import fcntl as _fcntl
    _HAS_FCNTL = True
except ImportError:
    _fcntl = None
    _HAS_FCNTL = False


class SingleInstance:
    """قفل نسخة واحدة: على POSIX يستخدم fcntl.flock (قفل kernel يتحرر تلقائياً
    عند انتهاء العملية). على Windows (وأي بيئة بلا fcntl) يستخدم قفل ملف
    بسيط عبر O_EXCL + محتوى PID للتشخيص، مع تنظيف stale lock إن كان PID ميتاً.

    هذا يحل مشكلتين حقيقيتين وقعتا مع القفل النصي القديم:
    1) نفس العملية تُعيد استدعاء acquire() بعد فشل عابر (retry داخل
       run_forever) فتجد ملف قفلها هي نفسها موجوداً، وتظن خطأً أن نسخة
       أخرى تعمل (PID حي = هي نفسها) فتحظر نفسها للأبد.
    2) عملية قديمة تموت بشكل غير نظيف (kill -9) فيبقى ملف القفل يحمل
       PID قديم؛ لو أعاد النظام استخدام نفس رقم الـPID لعملية جديدة
       لاحقاً، القفل يحظر تشغيلاً شرعياً جديداً ظناً أنه "نفس" العملية القديمة.

    مع flock: لا حاجة لقراءة/مقارنة PID إطلاقاً - fcntl.LOCK_EX|LOCK_NB
    يفشل فوراً (BlockingIOError) فقط لو كانت هناك عملية أخرى تُمسك
    بالقفل فعلياً الآن، بغض النظر عمّا كتبته في محتوى الملف."""

    def __init__(self, path: str):
        self.path = path
        self.fd = None
        self._use_fcntl = _HAS_FCNTL

    def acquire(self):
        if self.fd is not None:
            return  # هذه العملية تملك القفل فعلاً - لا داعٍ لإعادة المحاولة
        if self._use_fcntl:
            self._acquire_fcntl()
        else:
            self._acquire_fallback()

    def _read_other_pid(self) -> str:
        try:
            with open(self.path, "r", encoding="utf-8") as f:
                return f.read().strip() or "غير معروف"
        except OSError:
            return "غير معروف"

    @staticmethod
    def _pid_alive(pid: int) -> bool:
        if pid <= 0:
            return False
        try:
            os.kill(pid, 0)
            return True
        except (OSError, AttributeError):
            return False

    def _acquire_fcntl(self):
        self.fd = os.open(self.path, os.O_CREAT | os.O_RDWR, 0o600)
        try:
            _fcntl.flock(self.fd, _fcntl.LOCK_EX | _fcntl.LOCK_NB)
        except BlockingIOError:
            other_pid = self._read_other_pid()
            os.close(self.fd)
            self.fd = None
            raise FatalBotError(
                f"[BLOCKED] البوت يعمل مسبقاً (قفل ملف نشط، آخر PID مسجَّل={other_pid}) - "
                f"نفّذ: ps aux | grep python  ثم  kill {other_pid}  لو كانت هذه عملية زائدة، "
                f"ثم أعد التشغيل يدوياً. لا تشغّل نسخة ثانية على نفس الحساب/الرمز"
            )
        os.ftruncate(self.fd, 0)
        os.write(self.fd, str(os.getpid()).encode("utf-8"))
        os.fsync(self.fd)

    def _acquire_fallback(self):
        """قفل بديل لأنظمة بلا fcntl (مثل Windows): إنشاء ملف حصري؛
        لو وُجد مسبقاً يتحقق هل PID المسجّل لا يزال حياً ثم يستولي عند الحاجة."""
        try:
            self.fd = os.open(self.path, os.O_CREAT | os.O_EXCL | os.O_RDWR, 0o600)
            os.write(self.fd, str(os.getpid()).encode("utf-8"))
            os.fsync(self.fd)
            return
        except FileExistsError:
            other_pid = self._read_other_pid()
            if other_pid.isdigit() and not self._pid_alive(int(other_pid)):
                try:
                    os.unlink(self.path)
                    self.fd = os.open(self.path, os.O_CREAT | os.O_EXCL | os.O_RDWR, 0o600)
                    os.write(self.fd, str(os.getpid()).encode("utf-8"))
                    os.fsync(self.fd)
                    return
                except (FileExistsError, OSError):
                    pass
            raise FatalBotError(
                f"[BLOCKED] البوت يعمل مسبقاً (قفل ملف نشط، آخر PID مسجَّل={other_pid}) - "
                f"أنه العملية الزائدة يدوياً ثم أعد التشغيل. لا تشغّل نسخة ثانية على نفس الحساب/الرمز"
            )

    def release(self):
        try:
            if self.fd is not None:
                if self._use_fcntl and _fcntl is not None:
                    try:
                        _fcntl.flock(self.fd, _fcntl.LOCK_UN)
                    except OSError:
                        pass
                os.close(self.fd)
                self.fd = None
            if not self._use_fcntl:
                try:
                    os.unlink(self.path)
                except OSError:
                    pass
        except OSError:
            pass



LOCK = SingleInstance(CFG.LOCK_FILE)
atexit.register(LOCK.release)


# ==============================================================================
# 2) تسجيل JSON هيكلي (Structured Logging)
# ==============================================================================

class JsonFormatter(logging.Formatter):
    def format(self, record: logging.LogRecord) -> str:
        payload = {
            "ts": utc_iso(),
            "level": record.levelname,
            "event": record.getMessage(),
        }
        if hasattr(record, "extra_data"):
            payload["data"] = record.extra_data
        return json.dumps(payload, ensure_ascii=False, default=str)


def _secure_file_permissions(path: str):
    """يقيّد صلاحيات ملف حسّاس (سجل التداول، قاعدة الحالة، ملف القفل) إلى
    0600 (قراءة/كتابة للمالك فقط) - يمنع أي مستخدم محلي آخر على نفس الجهاز
    من قراءة سجل الصفقات أو حالة الحساب. لا يفعل شيئاً على أنظمة لا تدعم
    صلاحيات يونكس (مثل Windows) بدل رمي خطأ غير ضروري."""
    try:
        os.chmod(path, 0o600)
    except OSError:
        pass  # غير حرج - النظام لا يدعم هذا النوع من الصلاحيات أو مشكلة أذونات


class ConsoleFormatter(logging.Formatter):
    """[Glama 5 - إصلاح ثغرة] الطرفية (Termux) كانت تعرض فقط الرسالة
    العامة الثابتة (مثلاً \"خطأ API غير قابل لإعادة المحاولة تلقائياً\")
    بينما التفاصيل الفعلية الحاسمة للتشخيص (كود خطأ Binance الحقيقي،
    اسم العملية، الرسالة الأصلية من المنصة) كانت تُكتب فقط في ملف JSON
    ولا تظهر مطلقاً على الشاشة - يجعل تشخيص أي مشكلة من الطرفية وحدها
    مستحيلاً عملياً (بالضبط ما حدث في محادثات سابقة: المستخدم رأى نفس
    سطرين يتكرران بلا أي فكرة عن السبب الحقيقي). الآن نُلحق ملخصاً
    مختصراً لأهم حقول extra_data (خصوصاً msg/code/op) مباشرة بعد الرسالة."""
    KEY_FIELDS = ("op", "code", "status", "msg", "reason", "reason_detail", "symbol")

    def format(self, record: logging.LogRecord) -> str:
        base = super().format(record)
        data = getattr(record, "extra_data", None)
        if not data:
            return base
        parts = [f"{k}={data[k]}" for k in self.KEY_FIELDS if k in data and data[k] not in (None, "")]
        # أي حقول إضافية غير في القائمة أعلاه لا زالت مفيدة أحياناً لكن أقل أولوية
        extra_keys = [k for k in data if k not in self.KEY_FIELDS]
        if not parts and not extra_keys:
            return base
        if extra_keys and len(parts) < 4:  # لا نُغرق السطر - نكتفي ببضعة حقول إضافية لو الأساسية قليلة
            parts += [f"{k}={data[k]}" for k in extra_keys[:3] if data[k] not in (None, "")]
        return f"{base}  ›› {' | '.join(parts)}" if parts else base


def build_logger() -> logging.Logger:
    logger = logging.getLogger("strong_bbp")
    logger.setLevel(logging.INFO)

    # يمنع إضافة handlers مكررة لو استُدعيت الدالة أكثر من مرة (مثلاً بعد
    # إعادة تشغيل داخلي عبر run_forever) - تكرار الـ handlers يعني كل سطر
    # لوج يُكتب عدة مرات في نفس الملف/الطرفية.
    if logger.handlers:
        return logger

    file_handler = logging.FileHandler(CFG.LOG_FILE, encoding="utf-8")
    file_handler.setFormatter(JsonFormatter())
    _secure_file_permissions(CFG.LOG_FILE)

    console_handler = logging.StreamHandler()
    console_handler.setFormatter(ConsoleFormatter("%(asctime)s | %(levelname)s | %(message)s"))

    logger.addHandler(file_handler)
    logger.addHandler(console_handler)
    return logger


log = build_logger()


import re as _re

_SENSITIVE_PATTERNS = [
    _re.compile(r'(signature=)[A-Za-z0-9]+', _re.IGNORECASE),
    _re.compile(r'((?:api[_-]?key)["\']?\s*[:=]\s*["\']?)[A-Za-z0-9]{10,}', _re.IGNORECASE),
    _re.compile(r'((?:api[_-]?secret|secret)["\']?\s*[:=]\s*["\']?)[A-Za-z0-9]{10,}', _re.IGNORECASE),
    _re.compile(r'((?:listen[_-]?key)["\']?\s*[:=]\s*["\']?)[A-Za-z0-9]{10,}', _re.IGNORECASE),
    _re.compile(r'\d{6,12}:[A-Za-z0-9_-]{30,}'),  # شكل توكن Telegram bot (chat_id:token) - بدون \b
    # لأن التوكن غالباً يظهر ملاصقاً لكلمة "bot" داخل رابط API فلا يوجد حد كلمة حقيقي قبله
    _re.compile(r'(X-MBX-APIKEY["\']?\s*[:=]\s*["\']?)[A-Za-z0-9]{10,}', _re.IGNORECASE),
]


def _redact_known_secrets(text: str) -> str:
    """يستبدل أي ظهور حرفي فعلي لمفاتيح API/توكن Telegram المُحمَّلة فعلياً
    من البيئة - أدق طريقة ممكنة لأننا نعرف القيم الحقيقية وقت التشغيل،
    بدل الاعتماد على تخمين الشكل العام فقط."""
    for env_var in ("BINANCE_API_KEY", "BINANCE_API_SECRET", "TELEGRAM_BOT_TOKEN"):
        val = os.getenv(env_var)
        if val and len(val) >= 8 and val in text:
            text = text.replace(val, f"[REDACTED_{env_var}]")
    return text


def sanitize_text(value):
    """يُطهّر أي نص من مفاتيح/أسرار/توكنات محتملة قبل تسجيله أو إرساله -
    سواء كانت القيمة الحرفية المعروفة (من متغيرات البيئة) أو نمط عام يشبه
    مفتاحاً أو توقيعاً (signature=, api_key=, listenKey=, توكن Telegram)."""
    if not isinstance(value, str):
        return value
    text = _redact_known_secrets(value)
    for pat in _SENSITIVE_PATTERNS:
        if pat.groups:
            text = pat.sub(lambda m: m.group(1) + "[REDACTED]", text)
        else:
            text = pat.sub("[REDACTED]", text)
    return text


_DAILY_REJECT_COUNTS: dict = {}  # {date_str: {reason: count}} - في الذاكرة فقط (يُصفَّر عند إعادة التشغيل)

# [إصلاح - بند 30 من المواصفة، بطلب صريح: "سجل إحصائيات BUY مقابل SELL"]
# عداد إشارات خام (قبل أي رفض) حسب الاتجاه فقط - غرضه اكتشاف انحياز
# منطقي بالكود (مثل انحياز sweep اللي أصلحناه) لو BUY=95%/SELL=5% مثلاً،
# وليس تغيير أي قرار مخاطرة تلقائياً (كما نصّت المواصفة صراحة).
_DAILY_SIGNAL_SIDE_COUNTS: dict = {}  # {date_str: {"BUY": n, "SELL": n}}
_SIDE_BIAS_WARNED_DATE: Optional[str] = None
SIDE_BIAS_MIN_SAMPLE = 20     # لا نحكم على انحياز قبل عدد إشارات كافٍ يومياً
SIDE_BIAS_WARN_RATIO = 0.90   # ≥90% لجهة واحدة من العينة الكافية = تحذير


def _record_signal_side(side: str):
    """يُسجَّل مرة واحدة لكل إشارة خام تصل detect_signal (بغض النظر هل
    قُبلت لاحقاً أو رُفضت بفلتر بعدها) - هذا فرق مهم عن _DAILY_REJECT_COUNTS
    الذي يسجّل فقط ما رُفض. مقارنة الاثنين تكشف: هل المشكلة عدم وجود
    فرص من الأساس، أم فلتر يرفض جهة واحدة بشكل ممنهج."""
    global _SIDE_BIAS_WARNED_DATE
    if side not in ("BUY", "SELL"):
        return
    today = utc_today_str()
    bucket = _DAILY_SIGNAL_SIDE_COUNTS.setdefault(today, {"BUY": 0, "SELL": 0})
    bucket[side] = bucket.get(side, 0) + 1
    total = bucket["BUY"] + bucket["SELL"]
    if total < SIDE_BIAS_MIN_SAMPLE or _SIDE_BIAS_WARNED_DATE == today:
        return
    dominant_side, dominant_n = max(bucket.items(), key=lambda kv: kv[1])
    if dominant_n / total >= SIDE_BIAS_WARN_RATIO:
        _SIDE_BIAS_WARNED_DATE = today  # تحذير واحد فقط باليوم - ليس إغراقاً
        log_event("warning", "[BIAS] انحياز واضح باتجاه الإشارات الخام اليوم - راجع منطق الكشف",
                  buy=bucket["BUY"], sell=bucket["SELL"], dominant=dominant_side)
        notify_telegram(
            f"[BIAS] انحياز ملحوظ في اتجاه الإشارات المكتشفة اليوم: "
            f"BUY={bucket['BUY']} SELL={bucket['SELL']} (لا علاقة بالربح/الخسارة، "
            "فقط أي جهة يكتشفها منطق الإشارة أكثر) - قد يدل على انحياز بالكود "
            "وليس بالسوق فعلاً. هذا تشخيصي فقط ولا يغيّر أي قرار تداول تلقائياً."
        )


def log_event(level: str, message: str, **data):
    record_fn = {"info": log.info, "warning": log.warning, "error": log.error}.get(level, log.info)
    clean_message = sanitize_text(message)
    clean_data = {k: sanitize_text(v) for k, v in data.items()} if data else {}
    extra = {"extra_data": clean_data} if clean_data else {}
    record_fn(clean_message, extra=extra)
    # [بطلب صريح - القسم 10] عدّاد تراكمي يومي لأسباب الرفض - يغذّي /rejectstats
    if message == "signal_rejected":
        reason = clean_data.get("reason")
        if reason:
            today = utc_today_str()
            day_bucket = _DAILY_REJECT_COUNTS.setdefault(today, {})
            day_bucket[reason] = day_bucket.get(reason, 0) + 1


# ==============================================================================
# 3) قاعدة بيانات محلية لحفظ الحالة (State Persistence & Recovery)
# ==============================================================================

_UNSET = object()  # مُميّز خاص: يفرّق بين "لا تغيّر القيمة" و"امسحها فعلياً إلى None"


class StateStore:
    """يحفظ الصفقة المفتوحة، أوامر SL/TP المرتبطة بها، وسجل نتائج الصفقات
    (للـ Circuit Breaker) في SQLite - يُقرأ فور إعادة تشغيل البوت."""

    def __init__(self, path: str):
        self.path = path
        self._lock = threading.RLock()
        self._init_db()
        _secure_file_permissions(self.path)

    def _conn(self):
        return sqlite3.connect(self.path, timeout=10)

    def _init_db(self):
        with self._lock, self._conn() as c:
            c.execute("""
                CREATE TABLE IF NOT EXISTS open_position (
                    symbol TEXT PRIMARY KEY,
                    side TEXT, qty REAL, entry_price REAL,
                    sl_order_id INTEGER, tp_order_id INTEGER, tp_price REAL,
                    trailing_active INTEGER DEFAULT 0,
                    extreme_price REAL,
                    last_sl_price REAL,
                    opened_at TEXT
                )
            """)
            c.execute("""
                CREATE TABLE IF NOT EXISTS trade_history (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    symbol TEXT, side TEXT, pnl REAL, pnl_usdt REAL, closed_at TEXT
                )
            """)
            c.execute("""
                CREATE TABLE IF NOT EXISTS daily_open_count (
                    day TEXT PRIMARY KEY,
                    opened_count INTEGER NOT NULL DEFAULT 0
                )
            """)
            c.execute("""
                CREATE TABLE IF NOT EXISTS bot_state (
                    id INTEGER PRIMARY KEY CHECK (id = 1),
                    halt_until TEXT,
                    day_start_balance REAL,
                    day_start_date TEXT,
                    day_start_equity REAL,
                    peak_balance REAL
                )
            """)
            c.execute("INSERT OR IGNORE INTO bot_state (id, halt_until, day_start_balance, day_start_date, day_start_equity) VALUES (1, NULL, NULL, NULL, NULL)")

            # ترحيل خفيف لقواعد بيانات سابقة أُنشئت قبل إضافة هذا العمود (Equity الشامل للخسارة غير المحققة)
            try:
                c.execute("ALTER TABLE bot_state ADD COLUMN day_start_equity REAL")
            except sqlite3.OperationalError:
                pass  # العمود موجود مسبقاً

            # ترحيل خفيف: peak_balance (أعلى رصيد فعلي شُوهد على الإطلاق) -
            # يُستخدم كمرجع متحرك لقاطع الخسارة الحاسم بدل تجميده على
            # CAPITAL_USDT الثابت للأبد حتى لو نما رأس المال لاحقاً بفعل
            # التركيب (compounding).
            try:
                c.execute("ALTER TABLE bot_state ADD COLUMN peak_balance REAL")
            except sqlite3.OperationalError:
                pass  # العمود موجود مسبقاً

            # تتبّع رصيد التسوية (القسم 1 من مواصفات الإنتاج): يُستخدم للتفريق
            # بين ربح/خسارة البوت الفعلية وأي تغيير خارجي/يدوي على الرصيد
            # (إيداع/سحب/صفقة يدوية) حتى لا يُحتسب تغيير خارجي كخسارة بوت.
            try:
                c.execute("ALTER TABLE bot_state ADD COLUMN pnl_baseline_balance REAL")
            except sqlite3.OperationalError:
                pass
            try:
                c.execute("ALTER TABLE bot_state ADD COLUMN bot_pnl_since_baseline REAL DEFAULT 0")
            except sqlite3.OperationalError:
                pass

            # القسم 17: نقطة أساس اختبار الـ3 أيام المباشر - تُسجَّل مرة واحدة
            # فقط (أول تشغيل)، ولا تُستخدم أبداً كأساس لحجم الصفقات (ذاك 50%
            # من availableBalance الطازجة دائماً) - فقط لغرض التقرير النهائي.
            try:
                c.execute("ALTER TABLE bot_state ADD COLUMN test_start_balance REAL")
            except sqlite3.OperationalError:
                pass
            try:
                c.execute("ALTER TABLE bot_state ADD COLUMN test_start_time TEXT")
            except sqlite3.OperationalError:
                pass

            # إعدادات قاطع التيار القابلة للتحكم من تيليجرام
            for col, typedef in (
                ("breaker_enabled", "INTEGER DEFAULT 1"),
                ("hard_protection", "INTEGER DEFAULT 1"),
                ("max_consecutive_losses", "INTEGER"),
                ("pause_hours", "INTEGER"),
                ("daily_drawdown_pct", "REAL"),
                ("daily_max_loss_pct", "REAL"),
                ("loss_baseline_id", "INTEGER DEFAULT 0"),
                ("active_symbols", "TEXT"),
            ):
                try:
                    c.execute(f"ALTER TABLE bot_state ADD COLUMN {col} {typedef}")
                except sqlite3.OperationalError:
                    pass

            # ترحيل خفيف لقواعد بيانات سابقة أُنشئت قبل إضافة هذا العمود
            try:
                c.execute("ALTER TABLE trade_history ADD COLUMN pnl_usdt REAL")
            except sqlite3.OperationalError:
                pass  # العمود موجود مسبقاً

            # [بطلب صريح - القسم 15] تصنيف نوع الإغلاق: bot_sl / bot_tp /
            # bot_trailing / bot_timeout / manual / emergency - يمنع خلط
            # الإغلاقات اليدوية بأداء استراتيجية البوت في مقاييس الأداء.
            try:
                c.execute("ALTER TABLE trade_history ADD COLUMN exit_type TEXT")
            except sqlite3.OperationalError:
                pass  # العمود موجود مسبقاً

            # [بطلب صريح - القسم 15] علامة "إغلاق يدوي بانتظار التأكيد" - تُضبط
            # قبل إرسال أمر إغلاق يدوي (من /close، /closeall، أو أزرار
            # اللوحة) كي تعرف حلقة كشف الإغلاق الرئيسية أن هذا الإغلاق
            # يدوي وليس SL/TP/Trailing عادياً، دون تخمين من حالة الأوامر.
            try:
                c.execute("ALTER TABLE open_position ADD COLUMN manual_close_pending INTEGER DEFAULT 0")
            except sqlite3.OperationalError:
                pass  # العمود موجود مسبقاً

            # [بطلب صريح - محرك حماية الأرباح والخروج الذكي] تتبّع MAE
            # (أسوأ سعر أثناء الصفقة) وذروة الربح وR وزمن الذروة، لكل مركز
            # مفتوح - يبقى محفوظاً في SQLite وينجو من إعادة التشغيل/انقطاع
            # WebSocket. extreme_price الموجود مسبقاً يبقى هو MFE (أفضل سعر).
            for col, typedef in (
                ("mae_price", "REAL"),
                ("peak_pnl_usdt", "REAL DEFAULT 0"),
                ("peak_r", "REAL DEFAULT 0"),
                ("peak_time", "TEXT"),
            ):
                try:
                    c.execute(f"ALTER TABLE open_position ADD COLUMN {col} {typedef}")
                except sqlite3.OperationalError:
                    pass  # العمود موجود مسبقاً

            # نفس الحقول تُنسخ إلى trade_history عند إغلاق كل صفقة، بالإضافة
            # إلى مقدار التراجع (giveback) عن الذروة ومدة الاحتفاظ - لتشخيص
            # تيليجرام والإحصاء لكل رمز (القسمان 11 و13 من ملف الإصلاح).
            for col, typedef in (
                ("mfe_pct", "REAL"),
                ("mae_pct", "REAL"),
                ("peak_pnl_usdt", "REAL"),
                ("peak_r", "REAL"),
                ("giveback_usdt", "REAL"),
                ("giveback_ratio", "REAL"),
                ("held_minutes", "REAL"),
            ):
                try:
                    c.execute(f"ALTER TABLE trade_history ADD COLUMN {col} {typedef}")
                except sqlite3.OperationalError:
                    pass  # العمود موجود مسبقاً

            # [Glama 4 - بند 15/16 من تقرير التطوير الهجومي] يُحفَظ مصدر
            # الإشارة ودرجة الجودة مع كل صفقة (مفتوحة ثم مُغلَقة) - يغذّي
            # /expectancy لاحقاً: Expectancy حسب symbol/side/signal_source/
            # الساعة/نطاق الجودة، بدل الاكتفاء بـWin Rate منفرداً (بند 16).
            for col, typedef in (("signal_source", "TEXT"), ("quality_score", "REAL")):
                try:
                    c.execute(f"ALTER TABLE open_position ADD COLUMN {col} {typedef}")
                except sqlite3.OperationalError:
                    pass
                try:
                    c.execute(f"ALTER TABLE trade_history ADD COLUMN {col} {typedef}")
                except sqlite3.OperationalError:
                    pass

            # [بطلب صريح - ملف الإصلاحات المتوازنة] Cooldown بعد إغلاق كل
            # صفقة على نفس الرمز - يمنع إعادة الدخول السريع (REJECT_SYMBOL_COOLDOWN)
            c.execute("""
                CREATE TABLE IF NOT EXISTS symbol_cooldown (
                    symbol TEXT PRIMARY KEY,
                    cooldown_until TEXT NOT NULL
                )
            """)

    def set_symbol_cooldown(self, symbol: str, minutes: int = None):
        minutes = minutes if minutes is not None else CFG.COOLDOWN_AFTER_CLOSE_MINUTES
        until = utc_now() + timedelta(minutes=minutes)
        with self._lock, self._conn() as c:
            c.execute("""
                INSERT INTO symbol_cooldown (symbol, cooldown_until)
                VALUES (?, ?)
                ON CONFLICT(symbol) DO UPDATE SET cooldown_until = excluded.cooldown_until
            """, (symbol, until.isoformat()))

    def is_symbol_in_cooldown(self, symbol: str):
        with self._lock, self._conn() as c:
            row = c.execute(
                "SELECT cooldown_until FROM symbol_cooldown WHERE symbol = ?",
                (symbol,)
            ).fetchone()
        if not row:
            return False, None
        try:
            until = datetime.fromisoformat(row[0])
            if until.tzinfo is None:
                until = until.replace(tzinfo=timezone.utc)
        except (ValueError, TypeError):
            return False, None
        if utc_now() < until:
            return True, until
        return False, until

    def mark_manual_close_pending(self, symbol: str):
        with self._lock, self._conn() as c:
            c.execute("UPDATE open_position SET manual_close_pending = 1 WHERE symbol = ?", (symbol,))

    def clear_manual_close_pending(self, symbol: str):
        """يُستدعى فقط عندما نعرف بيقين أن أمر الإغلاق لم يصل فعلياً إلى
        Binance (فشل الإرسال نفسه) - وليس عند فشل التحقق من flat بعد
        الإرسال (تلك الحالة يبقى فيها manual_close_pending=1 عمداً، لأن
        المركز قد يكون أُغلق فعلياً ولا نملك تأكيداً - القسم 5 من تقرير
        التشخيص، مع تصحيح: الفشل بعد timeout لا يُنظَّف، فقط فشل الإرسال)."""
        with self._lock, self._conn() as c:
            c.execute("UPDATE open_position SET manual_close_pending = 0 WHERE symbol = ?", (symbol,))

    def save_open_position(self, symbol, side, qty, entry_price, sl_order_id, tp_order_id, tp_price,
                            signal_source: str = None, quality_score: float = None):
        with self._lock, self._conn() as c:
            # [Glama 4] signal_source/quality_score يُحافَظ عليهما لو كانا
            # محفوظين مسبقاً لنفس الرمز ولم يُمرَّرا هذي المرة (مثلاً الحفظ
            # المؤقت الفوري بعد تأكيد الدخول في open_trade يُستدعى قبل أن
            # تُعرف هذي القيم فعلياً بذاك الموضع تحديداً في التدفق الحالي).
            existing = c.execute("SELECT signal_source, quality_score FROM open_position WHERE symbol = ?",
                                  (symbol,)).fetchone()
            if signal_source is None and existing:
                signal_source = existing[0]
            if quality_score is None and existing:
                quality_score = existing[1]
            c.execute("DELETE FROM open_position WHERE symbol = ?", (symbol,))
            c.execute(
                """INSERT INTO open_position
                   (symbol, side, qty, entry_price, sl_order_id, tp_order_id, tp_price, trailing_active,
                    extreme_price, last_sl_price, opened_at, mae_price, peak_pnl_usdt, peak_r, peak_time,
                    signal_source, quality_score)
                   VALUES (?, ?, ?, ?, ?, ?, ?, 0, ?, ?, ?, ?, 0, 0, ?, ?, ?)""",
                (symbol, side, qty, entry_price, sl_order_id, tp_order_id, tp_price, entry_price, None, utc_iso(),
                 entry_price, utc_iso(), signal_source, quality_score),
            )

    def update_position_extremes(self, symbol: str, mae_price: float = None, peak_pnl_usdt: float = None,
                                  peak_r: float = None, peak_time: str = None):
        """[بطلب صريح - محرك حماية الأرباح] يحدّث MAE/ذروة الربح/ذروة R/وقت
        الذروة لمركز مفتوح. يُستدعى كل دورة مراقبة بغض النظر عن تفعيل
        الوقف المتحرك، حتى تبقى الإحصاءات دقيقة حتى لو لم يُفتَّح trailing بعد."""
        fields, params = [], []
        if mae_price is not None:
            fields.append("mae_price = ?"); params.append(mae_price)
        if peak_pnl_usdt is not None:
            fields.append("peak_pnl_usdt = ?"); params.append(peak_pnl_usdt)
        if peak_r is not None:
            fields.append("peak_r = ?"); params.append(peak_r)
        if peak_time is not None:
            fields.append("peak_time = ?"); params.append(peak_time)
        if not fields:
            return
        params.append(symbol)
        with self._lock, self._conn() as c:
            c.execute(f"UPDATE open_position SET {', '.join(fields)} WHERE symbol = ?", params)

    def get_symbol_stats(self, symbol: str = None) -> list:
        """[بطلب صريح - القسم 11] إحصاءات لكل رمز (أو لكل الرموز إن لم يُحدَّد
        واحد)، مجمَّعة من trade_history الفعلي - بلا أي حذف/حظر تلقائي لأي
        رمز، فقط بيانات خام للتشخيص."""
        with self._lock, self._conn() as c:
            c.row_factory = sqlite3.Row
            base_sql = """
                SELECT symbol, side,
                       COUNT(*) AS trades,
                       SUM(CASE WHEN pnl_usdt > 0 THEN 1 ELSE 0 END) AS wins,
                       SUM(CASE WHEN pnl_usdt <= 0 THEN 1 ELSE 0 END) AS losses,
                       AVG(pnl_usdt) AS avg_pnl_usdt,
                       AVG(mfe_pct) AS avg_mfe_pct,
                       AVG(mae_pct) AS avg_mae_pct,
                       AVG(held_minutes) AS avg_held_minutes
                FROM trade_history
                WHERE pnl_usdt IS NOT NULL {sym_filter}
                GROUP BY symbol, side
                ORDER BY symbol, side
            """
            if symbol:
                rows = c.execute(base_sql.format(sym_filter="AND symbol = ?"), (symbol,)).fetchall()
            else:
                rows = c.execute(base_sql.format(sym_filter="")).fetchall()
            return [dict(r) for r in rows]

    def get_expectancy_stats(self) -> dict:
        """[Glama 4 - بند 15/16 من تقرير التطوير الهجومي] Expectancy =
        (Win Rate × متوسط الربح) − (Loss Rate × متوسط الخسارة)، محسوبة
        منفصلة حسب: الرمز، الاتجاه (BUY/SELL)، مصدر الإشارة (sweep/
        bos_retest/sr_touch/trend_riding)، ساعة UTC، ونطاق درجة الجودة
        (A>=0.75 / B<0.75) - بدل الاعتماد على Win Rate منفرداً (بند 16).
        يستخدم حد أدنى للعينة (min_sample) قبل اعتماد أي تجميع كدليل
        كافٍ - لا يُحذف أو يُعطَّل أي رمز/مصدر تلقائياً، بيانات خام فقط."""
        min_sample = 5

        def _agg(rows: list) -> dict:
            n = len(rows)
            if n == 0:
                return {"trades": 0}
            wins = [r for r in rows if r > 0]
            losses = [r for r in rows if r <= 0]
            win_rate = len(wins) / n
            avg_win = (sum(wins) / len(wins)) if wins else 0.0
            avg_loss = (abs(sum(losses)) / len(losses)) if losses else 0.0
            expectancy = win_rate * avg_win - (1 - win_rate) * avg_loss
            return {
                "trades": n, "win_rate_pct": round(win_rate * 100, 1),
                "avg_win_usdt": round(avg_win, 4), "avg_loss_usdt": round(avg_loss, 4),
                "expectancy_usdt": round(expectancy, 4),
                "reliable": n >= min_sample,
            }

        with self._lock, self._conn() as c:
            rows = c.execute(
                "SELECT symbol, side, exit_type, pnl_usdt, closed_at, signal_source, quality_score "
                "FROM trade_history WHERE pnl_usdt IS NOT NULL AND exit_type LIKE 'bot_%'"
            ).fetchall()

        by_symbol, by_side, by_source, by_hour, by_quality_band = {}, {}, {}, {}, {}
        for symbol, side, exit_type, pnl_usdt, closed_at, signal_source, quality_score in rows:
            by_symbol.setdefault(symbol, []).append(pnl_usdt)
            by_side.setdefault(side, []).append(pnl_usdt)
            by_source.setdefault(signal_source or "unknown", []).append(pnl_usdt)
            try:
                hour = datetime.fromisoformat(closed_at).hour
            except (ValueError, TypeError):
                hour = None
            if hour is not None:
                by_hour.setdefault(hour, []).append(pnl_usdt)
            band = "A" if (quality_score or 0) >= 0.75 else ("B" if quality_score is not None else "unknown")
            by_quality_band.setdefault(band, []).append(pnl_usdt)

        return {
            "by_symbol": {k: _agg(v) for k, v in by_symbol.items()},
            "by_side": {k: _agg(v) for k, v in by_side.items()},
            "by_signal_source": {k: _agg(v) for k, v in by_source.items()},
            "by_hour_utc": {k: _agg(v) for k, v in sorted(by_hour.items())},
            "by_quality_band": {k: _agg(v) for k, v in by_quality_band.items()},
            "min_sample": min_sample,
        }

    def get_open_position(self, symbol: str = None) -> Optional[dict]:
        with self._lock, self._conn() as c:
            c.row_factory = sqlite3.Row
            if symbol:
                row = c.execute("SELECT * FROM open_position WHERE symbol = ?", (symbol,)).fetchone()
            else:
                # للتوافق: يرجع أول صفقة إن وجدت
                row = c.execute("SELECT * FROM open_position LIMIT 1").fetchone()
            return dict(row) if row else None

    def get_all_open_positions(self) -> list:
        with self._lock, self._conn() as c:
            c.row_factory = sqlite3.Row
            rows = c.execute("SELECT * FROM open_position").fetchall()
            return [dict(r) for r in rows]

    def update_trailing_state(self, symbol: str, sl_order_id: int, extreme_price: float, new_sl_price: float,
                               tp_order_id=_UNSET, tp_price=_UNSET):
        """يحدّث حالة الوقف المتحرك لرمز معين."""
        with self._lock, self._conn() as c:
            fields = ["sl_order_id = ?", "trailing_active = 1", "extreme_price = ?", "last_sl_price = ?"]
            params = [sl_order_id, extreme_price, new_sl_price]
            if tp_order_id is not _UNSET:
                fields.append("tp_order_id = ?")
                params.append(tp_order_id)
            if tp_price is not _UNSET:
                fields.append("tp_price = ?")
                params.append(tp_price)
            params.append(symbol)
            c.execute(f"UPDATE open_position SET {', '.join(fields)} WHERE symbol = ?", params)

    def clear_open_position(self, symbol: str = None):
        with self._lock, self._conn() as c:
            if symbol:
                c.execute("DELETE FROM open_position WHERE symbol = ?", (symbol,))
            else:
                c.execute("DELETE FROM open_position")

    def record_trade_result(self, symbol: str, side: str, pnl: float, pnl_usdt: Optional[float] = None,
                             exit_type: str = "unknown", mfe_pct: Optional[float] = None,
                             mae_pct: Optional[float] = None, peak_pnl_usdt: Optional[float] = None,
                             peak_r: Optional[float] = None, giveback_usdt: Optional[float] = None,
                             giveback_ratio: Optional[float] = None, held_minutes: Optional[float] = None,
                             signal_source: Optional[str] = None, quality_score: Optional[float] = None):
        with self._lock, self._conn() as c:
            c.execute(
                """INSERT INTO trade_history
                   (symbol, side, pnl, pnl_usdt, closed_at, exit_type,
                    mfe_pct, mae_pct, peak_pnl_usdt, peak_r, giveback_usdt, giveback_ratio, held_minutes,
                    signal_source, quality_score)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (symbol, side, pnl, pnl_usdt, utc_iso(), exit_type,
                 mfe_pct, mae_pct, peak_pnl_usdt, peak_r, giveback_usdt, giveback_ratio, held_minutes,
                 signal_source, quality_score),
            )
            if pnl_usdt is not None:
                # القسم 1: كل ربح/خسارة يُحققها البوت فعلياً (وليس أي تغيير
                # آخر بالرصيد) يُضاف هنا - هذا هو الأساس الذي يُقارَن به
                # لاحقاً رصيد المحفظة الفعلي لاكتشاف أي تغيير خارجي/يدوي.
                c.execute("UPDATE bot_state SET bot_pnl_since_baseline = COALESCE(bot_pnl_since_baseline, 0) + ? WHERE id = 1",
                          (pnl_usdt,))

    def get_bot_realized_pnl_today(self) -> float:
        """مجموع pnl_usdt الحقيقي الذي حقّقه البوت اليوم فقط (UTC) - من
        trade_history، وهو الجدول الذي لا يُكتب فيه إلا عبر record_trade_result
        (أي صفقات البوت الفعلية)، ولا يتأثر بأي تغيير خارجي على الرصيد."""
        today = utc_today_str()
        with self._lock, self._conn() as c:
            row = c.execute(
                "SELECT COALESCE(SUM(pnl_usdt), 0) FROM trade_history WHERE closed_at LIKE ?",
                (f"{today}%",),
            ).fetchone()
        return float(row[0]) if row else 0.0

    def get_pnl_reconciliation_state(self) -> tuple:
        """يُرجع (baseline_balance, bot_pnl_since_baseline) - None للـbaseline
        يعني لم تُهيَّأ بعد (أول تشغيل)."""
        with self._lock, self._conn() as c:
            row = c.execute("SELECT pnl_baseline_balance, bot_pnl_since_baseline FROM bot_state WHERE id = 1").fetchone()
        if not row:
            return None, 0.0
        baseline = row[0]
        bot_pnl = float(row[1]) if row[1] is not None else 0.0
        return baseline, bot_pnl

    def resync_pnl_baseline(self, actual_balance: float):
        """يُعاد ضبط رصيد الأساس على الرصيد الفعلي الحالي ويُصفَّر عدّاد ربح/خسارة
        البوت منذ آخر مطابقة - يُستدعى بعد كل فحص مطابقة (نجح أو اكتشف تغييراً
        خارجياً) حتى لا يتراكم الفارق بلا نهاية."""
        with self._lock, self._conn() as c:
            c.execute("UPDATE bot_state SET pnl_baseline_balance = ?, bot_pnl_since_baseline = 0 WHERE id = 1",
                      (actual_balance,))

    def get_or_init_test_baseline(self, current_balance: float) -> tuple:
        """القسم 17: يُسجَّل رصيد/وقت بداية اختبار الـ3 أيام مرة واحدة فقط
        (أول استدعاء على الإطلاق) - الاستدعاءات اللاحقة تُرجع نفس القيمة
        الأصلية دائماً بغض النظر عن نمو الرصيد لاحقاً."""
        with self._lock, self._conn() as c:
            row = c.execute("SELECT test_start_balance, test_start_time FROM bot_state WHERE id = 1").fetchone()
            if row and row[0] is not None:
                return row[0], row[1]
            now = utc_iso()
            c.execute("UPDATE bot_state SET test_start_balance = ?, test_start_time = ? WHERE id = 1",
                      (current_balance, now))
            return current_balance, now

    def recent_consecutive_losses(self) -> int:
        settings = self.get_breaker_settings()
        limit = int(settings.get("max_consecutive_losses") or CFG.MAX_CONSECUTIVE_LOSSES)
        baseline = int(settings.get("loss_baseline_id") or 0)
        with self._lock, self._conn() as c:
            rows = c.execute(
                "SELECT pnl FROM trade_history WHERE id > ? ORDER BY id DESC LIMIT ?",
                (baseline, limit),
            ).fetchall()
        count = 0
        for (pnl,) in rows:
            if pnl < 0:
                count += 1
            else:
                break
        return count

    def get_today_trade_count(self) -> int:
        """عدد الصفقات المُغلقة اليوم (لتقارير الأداء) - لاحظ: هذا لا يصلح
        وحده كحد أقصى للتداول اليومي لأنه لا يحسب صفقة فُتحت اليوم ولم
        تُغلق بعد؛ لهذا الغرض استخدم get_today_opened_count بدلاً منه."""
        today = utc_today_str()
        with self._lock, self._conn() as c:
            row = c.execute(
                "SELECT COUNT(*) FROM trade_history WHERE substr(closed_at, 1, 10) = ?", (today,)
            ).fetchone()
        return row[0] if row else 0

    def increment_today_opened_count(self):
        """يُستدعى لحظة فتح صفقة فعلياً (وليس عند إغلاقها) - هذا يضمن أن حد
        الصفقات اليومي يعكس كل محاولة فتح حقيقية، حتى لو الصفقة لا تزال
        مفتوحة أو حدث خلل قبل تسجيل إغلاقها في trade_history."""
        day = utc_today_str()
        with self._lock, self._conn() as c:
            c.execute("""
                INSERT INTO daily_open_count (day, opened_count) VALUES (?, 1)
                ON CONFLICT(day) DO UPDATE SET opened_count = opened_count + 1
            """, (day,))

    def get_today_opened_count(self) -> int:
        day = utc_today_str()
        with self._lock, self._conn() as c:
            row = c.execute("SELECT opened_count FROM daily_open_count WHERE day = ?", (day,)).fetchone()
        return int(row[0]) if row else 0

    def get_strategy_win_stats(self) -> tuple:
        """(عدد الصفقات الرابحة, إجمالي صفقات الاستراتيجية) - صفقات البوت فقط (bot_*)."""
        with self._lock, self._conn() as c:
            rows = c.execute("SELECT pnl_usdt, pnl FROM trade_history WHERE exit_type LIKE 'bot_%'").fetchall()
        wins = 0
        for usdt, pct in rows:
            v = usdt if usdt is not None else pct
            if v is not None and v > 0:
                wins += 1
        return wins, len(rows)

    def last_trade_was_loss(self) -> bool:
        """هل آخر صفقة مُسجَّلة (بعد آخر /breaker reset) خاسرة؟"""
        baseline = int(self.get_breaker_settings().get("loss_baseline_id") or 0)
        with self._lock, self._conn() as c:
            row = c.execute("SELECT pnl, pnl_usdt FROM trade_history WHERE id > ? ORDER BY id DESC LIMIT 1",
                            (baseline,)).fetchone()
        if not row:
            return False
        v = row[1] if row[1] is not None else row[0]
        return v is not None and v < 0

    def get_performance_metrics(self) -> dict:
        """يحسب المقاييس من pnl_pct (نسبي) وpnl_usdt (فعلي بالدولار) معاً.
        [بطلب صريح - القسم 15] معدل الفوز/Profit Factor يُحسبان من صفقات
        البوت الاستراتيجية فقط (bot_sl/bot_tp/bot_trailing/bot_timeout) -
        لا تُخلط الإغلاقات اليدوية بأداء الاستراتيجية، رغم أن total_pnl_usdt
        يبقى المجموع الحقيقي الكامل (يشمل اليدوي أيضاً، فهو مال حقيقي فعلاً)."""
        with self._lock, self._conn() as c:
            rows = c.execute("SELECT pnl, pnl_usdt, symbol, exit_type FROM trade_history ORDER BY id ASC").fetchall()
        if not rows:
            return {}
        pnls_pct = [r[0] for r in rows]
        pnls_usdt = [r[1] if r[1] is not None else 0.0 for r in rows]
        exit_types = [r[3] or "unclear" for r in rows]
        exit_type_counts: dict = {}
        for et in exit_types:
            exit_type_counts[et] = exit_type_counts.get(et, 0) + 1

        # صفقات الاستراتيجية فقط (بدون يدوي/طارئ) لحساب winrate/PF بنزاهة
        strategy_pnls = [pnls_usdt[i] for i, et in enumerate(exit_types) if et.startswith("bot_")]
        wins = [p for p in strategy_pnls if p > 0]
        losses = [p for p in strategy_pnls if p < 0]
        total_profit = sum(wins)
        total_loss = abs(sum(losses))
        profit_factor = round(total_profit / total_loss, 2) if total_loss > 0 else None
        cum = np.cumsum(pnls_usdt)
        running_max = np.maximum.accumulate(cum)
        max_drawdown_usdt = float(np.min(cum - running_max)) if len(cum) else 0.0
        # أفضل/أسوأ رمز حسب إجمالي pnl_usdt المتراكم له (للأمر /stats)
        by_symbol: dict = {}
        for r in rows:
            sym_name = r[2] or "?"
            by_symbol[sym_name] = by_symbol.get(sym_name, 0.0) + (r[1] if r[1] is not None else 0.0)
        best_symbol = max(by_symbol.items(), key=lambda kv: kv[1]) if by_symbol else None
        worst_symbol = min(by_symbol.items(), key=lambda kv: kv[1]) if by_symbol else None
        return {
            "total_trades": len(pnls_pct),
            "strategy_trades": len(strategy_pnls),
            "manual_trades": exit_type_counts.get("manual", 0),
            "wins": len(wins),
            "losses": len(losses),
            "win_rate_pct": round(len(wins) / len(strategy_pnls) * 100, 2) if strategy_pnls else 0,
            "profit_factor": profit_factor,
            "total_pnl_usdt": round(sum(pnls_usdt), 4),
            "strategy_pnl_usdt": round(sum(strategy_pnls), 4),
            "max_drawdown_usdt": round(max_drawdown_usdt, 4),
            "exit_type_counts": exit_type_counts,
            "best_symbol": best_symbol,
            "worst_symbol": worst_symbol,
        }

    def set_halt_until(self, until_dt: Optional[datetime]):
        with self._lock, self._conn() as c:
            c.execute("UPDATE bot_state SET halt_until = ? WHERE id = 1",
                      (until_dt.isoformat() if until_dt else None,))

    def get_halt_until(self) -> Optional[datetime]:
        with self._lock, self._conn() as c:
            row = c.execute("SELECT halt_until FROM bot_state WHERE id = 1").fetchone()
        if row and row[0]:
            return datetime.fromisoformat(row[0])
        return None

    def get_or_init_day_start_balance(self, current_balance: float) -> float:
        today = utc_today_str()
        with self._lock, self._conn() as c:
            row = c.execute("SELECT day_start_balance, day_start_date FROM bot_state WHERE id = 1").fetchone()
            if row and row[1] == today and row[0] is not None:
                return row[0]
            c.execute(
                "UPDATE bot_state SET day_start_balance = ?, day_start_date = ?, day_start_equity = NULL WHERE id = 1",
                (current_balance, today),
            )
            return current_balance

    def get_or_init_day_start_equity(self, current_equity: float) -> float:
        """نفس منطق get_or_init_day_start_balance لكن لقيمة Equity الشاملة
        (الرصيد + الربح/الخسارة غير المحقق) - تُستخدم كطبقة حماية إضافية
        تكتشف خسارة كبيرة على مركز مفتوح حتى قبل ما يُغلق فعلياً، بينما
        day_start_balance وحدها لا تتحرك إلا بعد إغلاق الصفقة."""
        today = utc_today_str()
        with self._lock, self._conn() as c:
            row = c.execute("SELECT day_start_equity, day_start_date FROM bot_state WHERE id = 1").fetchone()
            if row and row[1] == today and row[0] is not None:
                return row[0]
            c.execute("UPDATE bot_state SET day_start_equity = ?, day_start_date = ? WHERE id = 1",
                      (current_equity, today))
            return current_equity

    def get_or_update_peak_balance(self, current_balance: float, floor_value: float) -> float:
        """يعيد أعلى رصيد فعلي شُوهد على الإطلاق (على الأقل floor_value) -
        يتحدّث لأعلى تلقائياً مع نمو الحساب عبر compounding، ولا يتحرك
        للأسفل أبداً. يُستخدم كمرجع متحرك لقاطع الخسارة الحاسم بدل رقم
        رأس المال الأصلي الثابت للأبد."""
        with self._lock, self._conn() as c:
            row = c.execute("SELECT peak_balance FROM bot_state WHERE id = 1").fetchone()
            stored_peak = row[0] if row and row[0] is not None else 0.0
            new_peak = max(stored_peak, current_balance, floor_value)
            if new_peak != stored_peak:
                c.execute("UPDATE bot_state SET peak_balance = ? WHERE id = 1", (new_peak,))
            return new_peak

    def adjust_peak_balance_for_external_change(self, external_diff: float, floor_value: float):
        """[إصلاح تدقيق قاطع التيار - حاسم]: عند اكتشاف تغيير خارجي حقيقي
        (سحب/إيداع/صفقة يدوية)، يُعدَّل أعلى رصيد شُوهد (peak_balance) بنفس
        مقدار التغيير الخارجي - وإلا فإن أي سحب حقيقي (لا علاقة له بأداء
        البوت إطلاقاً) يبقى يُحسب أبدياً كـ"تراجع من القمة" ضد رصيد لم يعد
        موجوداً فعلياً، فيوقف البوت للأبد ولو لم يخسر شيئاً بنفسه. السحب
        يُخفِّض peak بنفس القدر (تبقى نسبة التراجع الحقيقية كما كانت قبل
        السحب)؛ الإيداع يرفعه فوراً كذلك."""
        with self._lock, self._conn() as c:
            row = c.execute("SELECT peak_balance FROM bot_state WHERE id = 1").fetchone()
            stored_peak = row[0] if row and row[0] is not None else floor_value
            new_peak = max(stored_peak + external_diff, floor_value)
            c.execute("UPDATE bot_state SET peak_balance = ? WHERE id = 1", (new_peak,))
            log_event("info", "تعديل أعلى رصيد شُوهد بسبب تغيير خارجي مكتشَف",
                      reason="peak_balance_adjusted_external", old_peak=round(stored_peak, 4),
                      new_peak=round(new_peak, 4), external_diff=round(external_diff, 4))

    def get_active_symbols(self) -> tuple:
        """العملات الفعلية التي يتداول عليها البوت الآن - قابلة للتغيير حياً
        من تيليجرام (/setsymbol) بلا حاجة لإعادة تشغيل أو تعديل كود. تعود
        لقيمة CFG.CANDIDATE_SYMBOLS الافتراضية لو لم يُضبط شيء من قبل."""
        with self._lock, self._conn() as c:
            c.row_factory = sqlite3.Row
            row = c.execute("SELECT active_symbols FROM bot_state WHERE id = 1").fetchone()
        raw = row["active_symbols"] if row else None
        if not raw:
            return tuple(CFG.CANDIDATE_SYMBOLS)
        syms = tuple(s.strip().upper() for s in raw.split(",") if s.strip())
        return syms if syms else tuple(CFG.CANDIDATE_SYMBOLS)

    def set_active_symbols(self, symbols: tuple):
        with self._lock, self._conn() as c:
            c.execute("UPDATE bot_state SET active_symbols = ? WHERE id = 1", (",".join(symbols),))

    def get_breaker_settings(self) -> dict:
        """إعدادات قاطع التيار المحفوظة (مع قيم CFG كافتراضي إن لم تُضبط من تيليجرام)."""
        with self._lock, self._conn() as c:
            c.row_factory = sqlite3.Row
            row = c.execute("SELECT * FROM bot_state WHERE id = 1").fetchone()
        if not row:
            return {
                "breaker_enabled": 1 if CFG.CIRCUIT_BREAKER_ENABLED else 0,
                "hard_protection": 1 if CFG.HARD_LOSS_PROTECTION else 0,
                "max_consecutive_losses": CFG.MAX_CONSECUTIVE_LOSSES,
                "pause_hours": CFG.CIRCUIT_BREAKER_PAUSE_HOURS,
                "daily_drawdown_pct": CFG.MAX_DAILY_DRAWDOWN_PCT,
                "daily_max_loss_pct": CFG.DAILY_MAX_LOSS_PCT,
                "loss_baseline_id": 0,
                "halt_until": None,
            }
        data = dict(row)
        if data.get("breaker_enabled") is None:
            data["breaker_enabled"] = 1 if CFG.CIRCUIT_BREAKER_ENABLED else 0
        if data.get("hard_protection") is None:
            data["hard_protection"] = 1 if CFG.HARD_LOSS_PROTECTION else 0
        if data.get("max_consecutive_losses") is None:
            data["max_consecutive_losses"] = CFG.MAX_CONSECUTIVE_LOSSES
        if data.get("pause_hours") is None:
            data["pause_hours"] = CFG.CIRCUIT_BREAKER_PAUSE_HOURS
        if data.get("daily_drawdown_pct") is None:
            data["daily_drawdown_pct"] = CFG.MAX_DAILY_DRAWDOWN_PCT
        if data.get("daily_max_loss_pct") is None:
            data["daily_max_loss_pct"] = CFG.DAILY_MAX_LOSS_PCT
        if data.get("loss_baseline_id") is None:
            data["loss_baseline_id"] = 0
        return data

    def set_breaker_fields(self, **fields):
        allowed = {
            "breaker_enabled", "hard_protection", "max_consecutive_losses",
            "pause_hours", "daily_drawdown_pct", "daily_max_loss_pct",
            "loss_baseline_id", "halt_until",
        }
        sets, params = [], []
        for k, v in fields.items():
            if k not in allowed:
                continue
            sets.append(f"{k} = ?")
            params.append(v)
        if not sets:
            return
        params.append(1)
        with self._lock, self._conn() as c:
            c.execute(f"UPDATE bot_state SET {', '.join(sets)} WHERE id = ?", params)

    def reset_circuit_breaker(self):
        """يلغي الإيقاف الحالي ويتجاهل سلسلة الخسائر الحالية (لا يمسح السجل)."""
        with self._lock, self._conn() as c:
            row = c.execute("SELECT MAX(id) FROM trade_history").fetchone()
            last_id = int(row[0] or 0) if row else 0
            c.execute(
                "UPDATE bot_state SET halt_until = NULL, loss_baseline_id = ? WHERE id = 1",
                (last_id,),
            )

    def force_reset_peak_balance(self, new_peak: float):
        """[إصلاح تدقيق قاطع التيار - حاسم]: يعيد ضبط 'أعلى رصيد شُوهد' يدوياً
        إلى القيمة المُمرَّرة (عادة الرصيد الفعلي الحالي المُتحقَّق منه) - يُستخدم
        فقط عبر /breaker reset الصريح من المستخدم، وليس تلقائياً أبداً. بدون
        هذا، إعادة التعيين العادية (halt_until فقط) لا تصلح شيئاً لأن الحماية
        الحاسمة تُعيد تقييم peak_balance القديم في كل استدعاء بعدها مباشرة."""
        with self._lock, self._conn() as c:
            c.execute("UPDATE bot_state SET peak_balance = ? WHERE id = 1", (max(new_peak, 0.0),))

    def last_trade_id(self) -> int:
        with self._lock, self._conn() as c:
            row = c.execute("SELECT MAX(id) FROM trade_history").fetchone()
        return int(row[0] or 0) if row else 0


STORE = StateStore(CFG.DB_PATH)


# ==============================================================================
# 4) إعادة المحاولة التلقائية (Exponential Backoff / Retry Logic) + Rate Limiter
# ==============================================================================

class RateLimiter:
    """يحمي من تجاوز حد طلبات Binance (~1200/دقيقة) - ضروري لبوت يعمل بلا توقف."""

    def __init__(self, max_requests: int, window_sec: int):
        self.max_requests = max_requests
        self.window_sec = window_sec
        self.events: deque = deque()
        self.lock = threading.Lock()

    def wait(self):
        while True:
            with self.lock:
                now = time.monotonic()
                while self.events and now - self.events[0] >= self.window_sec:
                    self.events.popleft()
                if len(self.events) < self.max_requests:
                    self.events.append(now)
                    return
                delay = self.window_sec - (now - self.events[0]) + 0.1
            log_event("warning", "قريب من حد Rate Limit - انتظار استباقي", delay=round(delay, 2))
            time.sleep(max(delay, 0.1))


RATE_LIMITER = RateLimiter(CFG.MAX_REQUESTS_PER_WINDOW, CFG.RATE_LIMIT_WINDOW_SEC)


def with_retry(fn: Callable, *args, description: str = "", **kwargs) -> Any:
    """إعادة المحاولة فقط للأخطاء الشبكية/المنصة المؤقتة.
    أخطاء البرمجة مثل KeyError/TypeError لا تُخفى داخل retry loop.
    أوامر التداول الفعلية تُمرَّر عبر create_order_idempotent عند الحاجة."""
    import requests as _requests
    NON_RETRYABLE_CODES = {-2019, -1013, -4164, -2021}

    last_err = None
    for attempt in range(1, CFG.MAX_RETRIES + 1):
        RATE_LIMITER.wait()
        try:
            return fn(*args, **kwargs)
        except BinanceAPIException as e:
            last_err = e
            # Retry only likely transient server/rate-limit conditions.
            status = getattr(e, "status_code", None)
            # [إصلاح - تدقيق C7] 429/418 = تجاوز حد المعدل (وارد حقيقياً مع
            # فحص 38 رمزاً عبر REST كل دورة) - كان يُعامَل كخطأ نهائي غير
            # قابل لإعادة المحاولة، رغم أنه بالضبط الحالة التي يجب الانتظار
            # والمحاولة من جديد فيها (وليس الاستسلام فوراً). -1003 هو كود
            # Binance المكافئ لتجاوز حد المعدل.
            is_rate_limit = status in (429, 418) or getattr(e, "code", None) == -1003
            retryable = is_rate_limit or (status is not None and status >= 500) or getattr(e, "code", None) in (-1001, -1007, -1015)
            if e.code in NON_RETRYABLE_CODES or not retryable:
                log_event("error", "خطأ API غير قابل لإعادة المحاولة تلقائياً",
                          op=description, code=e.code, status=status, msg=str(e))
                raise
            if is_rate_limit:
                # حظر IP (418) أخطر من تجاوز مؤقت (429) - ننتظر أطول بكثير
                extra_wait = 30.0 if status == 418 else 0.0
                log_event("warning", "[ALERT] تجاوز حد المعدل من Binance - انتظار إضافي قبل إعادة المحاولة",
                          op=description, code=e.code, status=status, attempt=attempt, extra_wait_sec=extra_wait)
                if extra_wait:
                    time.sleep(extra_wait)
            else:
                log_event("warning", "خطأ API مؤقت - إعادة محاولة", op=description, code=e.code,
                          status=status, attempt=attempt, msg=str(e))
        except (_requests.exceptions.Timeout, _requests.exceptions.ConnectionError,
                _requests.exceptions.RequestException, OSError) as e:
            last_err = e
            log_event("warning", "خطأ شبكة/DNS/اتصال - إعادة محاولة",
                      op=description, attempt=attempt, msg=str(e))
        except BinanceOrderException:
            # Order exceptions are not assumed retry-safe here; idempotent order
            # creation handles ambiguous submission separately.
            raise

        delay = CFG.RETRY_BASE_DELAY_SEC * (2 ** (attempt - 1))
        time.sleep(min(delay, 60))

    log_event("error", "فشل نهائي بعد كل المحاولات", op=description, msg=str(last_err))
    raise last_err


# ==============================================================================
# 4ب) إنشاء أوامر آمن (Idempotent) عبر newClientOrderId
# لا يعيد إرسال أمر إنشاء تلقائياً بعد Timeout بدون تحقق أولاً - لأن الأمر
# الأصلي قد يكون نُفّذ فعلاً على المنصة رغم ضياع الرد بسبب انقطاع الشبكة،
# وإعادة الإرسال العمياء تعني فتح صفقة ثانية غير مقصودة بالخطأ.
# ==============================================================================

def _get_safe_bot_tag() -> str:
    """ينظّف BOT_INSTANCE_TAG بطريقة موحّدة (تُستخدم عند الإنشاء والفحص
    معاً) - سابقاً كان generate_client_order_id ينظّف القيمة قبل بناء
    البادئة، بينما is_own_order يقارن بالقيمة الخام غير المنظّفة. لو
    احتوى BOT_INSTANCE_TAG على رمز غير أبجدي رقمي (شرطة مثلاً) أو تجاوز
    8 أحرف، البادئتان ما كانتا تتطابقان أبداً و is_own_order كانت ترجع
    False دائماً حتى لأوامر البوت نفسه - تُبطل الغرض منها كلياً."""
    import re
    return re.sub(r"[^A-Za-z0-9]", "", CFG.BOT_INSTANCE_TAG)[:8] or "bot"


def generate_client_order_id(tag: str) -> str:
    """يبني معرّف عميل فريد يحمل بادئة اسم نسخة البوت (BOT_INSTANCE_TAG) -
    هذا يسمح لاحقاً بالتفريق بين أوامر هذا البوت وأي أمر يدوي أو من نسخة
    أخرى عند فحص الأوامر المفتوحة على المنصة، بدل الاعتماد حصرياً على
    orderId المحفوظ محلياً (الذي يفشل لو ضاعت الحالة المحلية بالكامل)."""
    import re
    bot_tag = _get_safe_bot_tag()
    safe_tag = re.sub(r"[^A-Za-z0-9]", "", tag)[:10]
    suffix = f"{int(time.time() * 1000) % 10**8}{uuid.uuid4().hex[:4]}"
    return f"{bot_tag}_{safe_tag}_{suffix}"[:36]


def is_own_order(order: dict) -> bool:
    """يتحقق هل أمر معيّن (من قائمة الأوامر المفتوحة على المنصة) يخص هذه
    النسخة من البوت تحديداً، بالاعتماد على بادئة clientOrderId - يُستخدم
    للتفريق بين أوامرنا وأي أمر يدوي/بوت آخر أثناء الاسترجاع أو التشخيص.
    للتوافق: يتعرّف أيضاً على أي مراكز/أوامر سابقة أُنشئت قبل تغيير
    BOT_INSTANCE_TAG (كان "violetphoenixfire") حتى لا يُعامَل مركز حقيقي
    مفتوح بالفعل على أنه "غير معروف" فقط بسبب إعادة تسمية البوت."""
    cid = order.get("clientOrderId", "") or ""
    import re
    recognized_prefixes = [_get_safe_bot_tag()] + [
        re.sub(r"[^A-Za-z0-9]", "", t)[:8] or "bot" for t in CFG.LEGACY_BOT_TAGS
    ]
    return any(cid.startswith(f"{p}_") for p in recognized_prefixes)


def create_order_idempotent(client: Client, description: str, **kwargs) -> dict:
    """يُنشئ أمراً بمعرّف عميل ثابت (newClientOrderId). قبل أي محاولة ثانية
    (بعد الأولى)، يتحقق أولاً هل الأمر بهذا المعرّف موجود فعلاً على المنصة
    قبل إرسال طلب إنشاء جديد - وليس فقط بعد ظهور استثناء، لأن بعض حالات
    الفشل الصامت (رد ضائع لكن الأمر نُفّذ) لا ترفع استثناءً واضحاً دائماً.

    [حارس DRY_RUN مركزي - إصلاح تدقيق] هذه الدالة هي المسار الوحيد الذي
    يمر منه إنشاء أي أمر حقيقي في المشروع كله (فتح/إغلاق/SL/TP/Trailing/
    إعادة بناء الحماية اليتيمة/إغلاق طارئ). قبل هذا الإصلاح، كان
    open_trade() فقط يتحقق من CFG.DRY_RUN (بعودة مبكرة قبل أي أمر)، بينما
    مسارات أخرى (تحديث Trailing Stop، مطابقة الحالة بعد إعادة التشغيل
    وإعادة بناء SL/TP اليتيمة، الإغلاق الطارئ) كانت تستدعي هذه الدالة
    مباشرة بلا أي تحقق من DRY_RUN - ما يعني أنه لو كان في حساب المستخدم
    مركز حقيقي موجود مسبقاً (من تشغيل LIVE سابق لم يُغلَق، أو فُتح يدوياً)
    فهذه المسارات كانت سترسل أوامر حقيقية فعلاً حتى مع DRY_RUN=True. الآن
    هذا الحارس المركزي يمنع ذلك قطعياً من أي مسار حالي أو مستقبلي.
    """
    cid = kwargs.get("newClientOrderId") or generate_client_order_id(description)
    kwargs["newClientOrderId"] = cid
    symbol = kwargs.get("symbol", CFG.SYMBOL)

    if CFG.DRY_RUN:
        qty = kwargs.get("quantity", "0")
        price = kwargs.get("price") or kwargs.get("stopPrice") or "0"
        simulated = {
            "orderId": -1,
            "clientOrderId": cid,
            "symbol": symbol,
            "status": "FILLED" if kwargs.get("type") in ("MARKET",) else "NEW",
            "executedQty": str(qty),
            "origQty": str(qty),
            "avgPrice": str(price),
            "price": str(price),
            "side": kwargs.get("side"),
            "type": kwargs.get("type"),
            "reduceOnly": kwargs.get("reduceOnly", False),
            "closePosition": kwargs.get("closePosition", False),
            "_simulated_dry_run": True,
        }
        log_event("info", "[DRY_RUN] محاكاة أمر - لم يُرسل أي شيء فعلياً لـ Binance",
                  description=description, client_order_id=cid, symbol=symbol,
                  side=kwargs.get("side"), type=kwargs.get("type"), qty=qty)
        return simulated

    attempt_count = {"n": 0}

    def _lookup_existing() -> Optional[dict]:
        try:
            existing = client.futures_get_order(symbol=symbol, origClientOrderId=cid)
            if existing and existing.get("orderId"):
                return existing
        except Exception:
            pass
        return None

    def attempt():
        attempt_count["n"] += 1
        if attempt_count["n"] > 1:
            # ليست المحاولة الأولى - تحقق أولاً هل الأمر بنفس المعرّف موجود
            # فعلاً قبل إرسال طلب إنشاء جديد بنفس المعرّف
            existing = _lookup_existing()
            if existing:
                log_event("warning", "الأمر موجود فعلاً من محاولة سابقة - استُخدم بدل إعادة الإرسال",
                          client_order_id=cid, description=description, status=existing.get("status"),
                          executed_qty=existing.get("executedQty"))
                return existing
        try:
            return client.futures_create_order(**kwargs)
        except Exception:
            existing = _lookup_existing()
            if existing:
                log_event("warning", "الأمر نُفّذ فعلاً رغم ظهور خطأ بالاستجابة - استُخدم الأمر الموجود بدل تكراره",
                          client_order_id=cid, description=description, status=existing.get("status"),
                          executed_qty=existing.get("executedQty"))
                return existing
            raise

    return with_retry(attempt, description=description)


# ==============================================================================
# 5) فلاتر دقة الرمز (Lot Size / Tick Size / Min Notional)
# ==============================================================================

class SymbolFilters:
    def __init__(self, client: Client, symbol: str):
        info = with_retry(client.futures_exchange_info, description="fetch_exchange_info")
        sym_info = next((s for s in info["symbols"] if s["symbol"] == symbol), None)
        if not sym_info:
            raise ValueError(f"رمز غير موجود: {symbol}")

        self.step_size = self._get_filter(sym_info, "LOT_SIZE", "stepSize")
        self.min_qty = self._get_filter(sym_info, "LOT_SIZE", "minQty", default=0.0)
        self.max_qty = self._get_filter(sym_info, "LOT_SIZE", "maxQty", default=0.0)

        # حجم العقد قد يخضع أيضاً لـ MARKET_LOT_SIZE (منفصل عن LOT_SIZE في بعض الأزواج،
        # وهو ما يُطبَّق فعلياً على أوامر MARKET تحديداً) - نأخذ القيد الأشد من الاثنين
        market_step = self._get_filter(sym_info, "MARKET_LOT_SIZE", "stepSize", default=0.0)
        if market_step > 0:
            self.step_size = max(self.step_size, market_step)
        market_min_qty = self._get_filter(sym_info, "MARKET_LOT_SIZE", "minQty", default=0.0)
        if market_min_qty > 0:
            self.min_qty = max(self.min_qty, market_min_qty)
        market_max_qty = self._get_filter(sym_info, "MARKET_LOT_SIZE", "maxQty", default=0.0)
        if market_max_qty > 0:
            self.max_qty = market_max_qty if self.max_qty <= 0 else min(self.max_qty, market_max_qty)

        self.tick_size = self._get_filter(sym_info, "PRICE_FILTER", "tickSize")
        # Binance تستخدم مفاتيح مختلفة حسب نوع الفلتر/نسخة بيانات السوق.
        # MIN_NOTIONAL يستخدم عادةً notional/minNotional، بينما NOTIONAL
        # يستخدم minNotional. ندعم الصيغتين بدل افتراض مفتاح واحد.
        self.min_notional = self._get_filter_any(
            sym_info, "MIN_NOTIONAL", ("notional", "minNotional"), default=0.0
        )
        if self.min_notional <= 0:
            self.min_notional = self._get_filter_any(
                sym_info, "NOTIONAL", ("minNotional", "notional"), default=5.0
            )
        self.max_orders = int(self._get_filter(sym_info, "MAX_NUM_ORDERS", "limit", default=200))
        self.qty_precision = self._decimals(self.step_size)
        self.price_precision = self._decimals(self.tick_size)

        # [WARN] نسخ Decimal دقيقة للتقريب الفعلي - float(step_size) نفسه قد يحمل
        # خطأ تمثيل ثنائي بسيط (مثال: 0.1 غير قابل للتمثيل تماماً بالـ binary
        # float)، فنبني Decimal مباشرة من نص الفلتر الأصلي القادم من Binance
        # (وليس من float مرّ فعلاً بخطأ تمثيل) لضمان تطابق صارم مع stepSize/tickSize
        self._step_size_dec = self._get_filter_decimal(sym_info, "LOT_SIZE", "stepSize")
        market_step_dec = self._get_filter_decimal(sym_info, "MARKET_LOT_SIZE", "stepSize")
        if market_step_dec is not None and (self._step_size_dec is None or market_step_dec > self._step_size_dec):
            self._step_size_dec = market_step_dec
        self._tick_size_dec = self._get_filter_decimal(sym_info, "PRICE_FILTER", "tickSize")

    @staticmethod
    def _get_filter(sym_info, filter_type, key, default=0.0):
        for f in sym_info["filters"]:
            if f["filterType"] == filter_type:
                try:
                    return float(f.get(key, default))
                except (TypeError, ValueError):
                    return default
        return default

    @staticmethod
    def _get_filter_any(sym_info, filter_type, keys, default=0.0):
        for f in sym_info["filters"]:
            if f["filterType"] != filter_type:
                continue
            for key in keys:
                value = f.get(key)
                if value not in (None, ""):
                    try:
                        return float(value)
                    except (TypeError, ValueError):
                        continue
        return default

    @staticmethod
    def _get_filter_decimal(sym_info, filter_type, key) -> Optional[Decimal]:
        """يرجع القيمة كـ Decimal مبني مباشرة من النص الأصلي القادم من
        Binance (وليس من float وسيط) - أدق طريقة ممكنة لتفادي أخطاء
        التمثيل الثنائي لأرقام مثل 0.1 أو 0.001."""
        for f in sym_info["filters"]:
            if f["filterType"] == filter_type and key in f:
                try:
                    return Decimal(str(f[key]))
                except Exception:
                    return None
        return None

    @staticmethod
    def _decimals(step: float) -> int:
        s = f"{step:.10f}".rstrip("0")
        return len(s.split(".")[1]) if "." in s else 0

    def round_qty(self, qty: float) -> float:
        """[WARN] يستخدم Decimal مع ROUND_DOWN داخلياً (يقرّب دائماً للأسفل نحو
        أقرب مضاعف صحيح لـ stepSize) - التقريب للأعلى بالخطأ قد يرسل كمية
        أكبر مما تحققه المخاطرة المقصودة، والتقريب العادي (round نصف للأعلى)
        بـ float قد ينتج قيماً مثل 0.009999999 يرفضها Binance في حالات نادرة."""
        step_dec = self._step_size_dec if self._step_size_dec and self._step_size_dec > 0 else None
        if step_dec is None:
            return round(qty, self.qty_precision)
        try:
            qty_dec = Decimal(str(qty))
            steps = (qty_dec / step_dec).to_integral_value(rounding=ROUND_DOWN)
            result = steps * step_dec
            return float(result)
        except (InvalidOperation, ValueError):
            return round(qty, self.qty_precision)  # احتياطي في حالة نادرة لقيمة غير صالحة

    def round_price(self, price: float) -> float:
        """نفس منطق round_qty لكن للسعر - يقرّب للأسفل نحو أقرب مضاعف tickSize."""
        tick_dec = self._tick_size_dec if self._tick_size_dec and self._tick_size_dec > 0 else None
        if tick_dec is None:
            return round(price, self.price_precision)
        try:
            price_dec = Decimal(str(price))
            steps = (price_dec / tick_dec).to_integral_value(rounding=ROUND_DOWN)
            result = steps * tick_dec
            return float(result)
        except (InvalidOperation, ValueError):
            return round(price, self.price_precision)

    def round_price_up(self, price: float) -> float:
        """تقريب السعر للأعلى نحو أقرب مضاعف tickSize باستخدام Decimal.
        يُستخدم عندما نحتاج الحفاظ على مسافة حماية/هدف لا تقل عن المسافة المقصودة."""
        tick_dec = self._tick_size_dec if self._tick_size_dec and self._tick_size_dec > 0 else None
        if tick_dec is None:
            return round(price, self.price_precision)
        try:
            price_dec = Decimal(str(price))
            steps = (price_dec / tick_dec).to_integral_value(rounding=ROUND_UP)
            result = steps * tick_dec
            return float(result)
        except (InvalidOperation, ValueError):
            return round(price, self.price_precision)

    def round_price_directional(self, price: float, direction: str) -> float:
        return self.round_price_up(price) if direction == "up" else self.round_price(price)

    def clamp_qty(self, qty: float, price: float, respect_min_notional: bool = True) -> float:
        """يضبط quantity وفق step/min/max.
        عند respect_min_notional=False لا يرفع الكمية تلقائياً؛ هذا هو الوضع
        المستخدم للحجم المقصود 50% حتى لا يتم تجاوز تخصيص الهامش بصمت."""
        if qty <= 0 or price <= 0:
            return 0.0

        if respect_min_notional and qty * price < self.min_notional:
            qty = (self.min_notional * 1.02) / price

        if self.max_qty > 0 and qty > self.max_qty:
            qty = self.max_qty

        if self.min_qty > 0 and qty < self.min_qty:
            qty = self.min_qty

        qty = self.round_qty(qty)

        if respect_min_notional and qty * price < self.min_notional and self.step_size > 0:
            qty = self.round_qty(qty + self.step_size)

        if qty <= 0 or (self.max_qty > 0 and qty > self.max_qty):
            return 0.0
        return qty

    def ensure_min_notional(self, qty: float, price: float) -> float:
        """محتفظ بها للتوافق الخلفي فقط - استخدم clamp_qty() في أي كود جديد."""
        return self.clamp_qty(qty, price)


# ==============================================================================
# 6) قاطع التيار وأمان الهامش
# ==============================================================================

def check_external_balance_change(client: Client) -> Optional[float]:
    """يقارن الرصيد الفعلي الحالي بالرصيد المتوقَّع (آخر رصيد أساس + ربح/خسارة
    البوت الفعلية منذ ذلك الحين فقط) - أي فارق يتجاوز هامش تسامح بسيط
    (رسوم تمويل صغيرة) يُعتبر تغييراً خارجياً/يدوياً (إيداع، سحب، صفقة يدوية)
    وليس خسارة أو ربحاً من البوت. يُعاد ضبط الأساس دائماً بعد الفحص حتى لا
    يتراكم الفارق. يُرجع مقدار التغيير الخارجي المكتشَف (أو None لو لا شيء)."""
    try:
        actual_balance = get_wallet_balance(client)
    except Exception as e:
        log_event("warning", "تعذر فحص مطابقة الرصيد (تغيير خارجي)", msg=str(e))
        return None

    baseline, bot_pnl_since = STORE.get_pnl_reconciliation_state()
    if baseline is None:
        STORE.resync_pnl_baseline(actual_balance)
        return None

    expected_balance = baseline + bot_pnl_since
    diff = actual_balance - expected_balance
    tolerance = max(0.05, abs(baseline) * 0.003)  # هامش صغير لرسوم التمويل/فروق تقريب
    external_change = None
    if abs(diff) > tolerance:
        external_change = diff
        direction = "إيداع/ربح خارجي" if diff > 0 else "سحب/خسارة خارجية"
        log_event("info", "تغيير خارجي في الرصيد تم اكتشافه - غير محسوب كربح/خسارة للبوت",
                  reason="external_balance_change", diff_usdt=round(diff, 4),
                  expected=round(expected_balance, 4), actual=round(actual_balance, 4))
        # [إصلاح حاسم]: يُعدَّل أعلى رصيد شُوهد بنفس مقدار التغيير الخارجي -
        # وإلا فإن سحباً حقيقياً يُحسب أبدياً كخسارة بوت ضد القاطع الكارثي.
        STORE.adjust_peak_balance_for_external_change(diff, _PEAK_BALANCE_FLOOR)
        notify_telegram(
            f"[EXTERNAL] تغيير خارجي في الرصيد: {diff:+.4f} USDT ({direction})\n"
            f"المتوقَّع من نشاط البوت فقط: {expected_balance:.4f} | الفعلي: {actual_balance:.4f}\n"
            f"لم يُحتسَب كربح/خسارة للبوت. تم تعديل مرجع الحماية الكارثية تلقائياً ليعكس ذلك."
        )

    STORE.resync_pnl_baseline(actual_balance)
    return external_change


def check_circuit_breaker(client: Client) -> Optional[str]:
    """يرجع سبب التوقف إن وجد، أو None للسماح بالتداول.
    يُدار من تيليجرام: /breaker on|off|reset|pause|losses|drawdown|hours|hard
    """
    settings = STORE.get_breaker_settings()
    halt_until = STORE.get_halt_until()
    if halt_until and utc_now() < halt_until:
        return f"البوت متوقف مؤقتاً حتى {halt_until.isoformat()} (قاطع تيار)"
    if halt_until and utc_now() >= halt_until:
        STORE.set_halt_until(None)

    breaker_on = bool(int(settings.get("breaker_enabled", 1)))
    hard_on = bool(int(settings.get("hard_protection", 1)))
    max_losses = int(settings.get("max_consecutive_losses") or CFG.MAX_CONSECUTIVE_LOSSES)
    pause_hours = int(settings.get("pause_hours") or CFG.CIRCUIT_BREAKER_PAUSE_HOURS)
    daily_dd = float(settings.get("daily_drawdown_pct") if settings.get("daily_drawdown_pct") is not None else CFG.MAX_DAILY_DRAWDOWN_PCT)
    hard_pct = float(settings.get("daily_max_loss_pct") if settings.get("daily_max_loss_pct") is not None else CFG.DAILY_MAX_LOSS_PCT)

    if breaker_on:
        consecutive_losses = STORE.recent_consecutive_losses()
        if consecutive_losses >= max_losses:
            until = utc_now() + timedelta(hours=pause_hours)
            STORE.set_halt_until(until)
            return f"خسائر متتالية ({consecutive_losses}/{max_losses}) - توقف حتى {until.isoformat()}"

        try:
            # القسم 1: نستخدم خسارة البوت الفعلية المُحقَّقة اليوم فقط
            # (trade_history، تُكتب حصرياً عبر record_trade_result من صفقات
            # البوت نفسه) - وليس فارق رصيد المحفظة الخام الذي قد يتضمن
            # سحباً/إيداعاً/صفقة يدوية لا علاقة لها بأداء البوت.
            day_start = STORE.get_or_init_day_start_balance(get_wallet_balance(client))
            bot_pnl_today = STORE.get_bot_realized_pnl_today()
            bot_drawdown = max(0.0, -bot_pnl_today) / day_start if day_start > 0 else 0.0
            if bot_drawdown > daily_dd:
                until = utc_now() + timedelta(hours=24)
                STORE.set_halt_until(until)
                return (f"تراجع من خسائر البوت الفعلية {bot_pnl_today:.2f} USDT "
                        f"({bot_drawdown*100:.1f}%, حد {daily_dd*100:.0f}%) - توقف 24 ساعة")
        except Exception as e:
            log_event("warning", "تعذر فحص حد التراجع اليومي", msg=str(e))

    if not hard_on:
        return None

    try:
        balance = get_wallet_balance(client)
        original_capital = STORE.get_or_update_peak_balance(balance, _PEAK_BALANCE_FLOOR)
        if original_capital > 0 and balance <= original_capital * (1.0 - hard_pct):
            try:
                positions = with_retry(client.futures_position_information,
                                        description="circuit_close_all")
                for p in positions:
                    qty = float(p.get("positionAmt", 0))
                    if qty == 0:
                        continue
                    pos_symbol = p.get("symbol", CFG.SYMBOL)
                    # [إصلاح - تحقق مطابق من تقرير مراجعة ثالث] كان try/except
                    # واحد يغلّف حلقة كل المراكز معاً - فشل إغلاق مركز واحد
                    # (مثلاً خطأ شبكة عابر) كان يُسقط الاستثناء فيقفز خارج
                    # الحلقة بالكامل، تاركاً بقية المراكز بلا حماية بالضبط
                    # باللحظة الأخطر (تفعيل قاطع الخسارة الحاسم). الآن كل
                    # مركز مستقل تماماً عن غيره.
                    try:
                        side = SIDE_SELL if qty > 0 else SIDE_BUY
                        mark_price = float(p.get("markPrice", 0) or 0)
                        create_order_idempotent(
                            client, "circuit_emergency_close", symbol=pos_symbol,
                            side=side, type=ORDER_TYPE_MARKET, quantity=abs(qty),
                            reduceOnly=True
                        )
                        # [إصلاح حرِج - بطلب صريح] يُسجَّل بـtrade_history الآن قبل
                        # المسح - كان يُمسح صامتاً بلا تسجيل، فيُصبح
                        # bot_pnl_since_baseline خاطئاً تماماً بعد أول قاطع تيار
                        # حاسم يُفعَّل (انظر تعليق _record_close_before_clear).
                        _record_close_before_clear(client, pos_symbol, exit_price_hint=mark_price,
                                                    exit_type="bot_circuit_breaker")
                        STORE.clear_open_position(pos_symbol)
                    except Exception as e_pos:
                        log_event("error", "[ALERT] فشل إغلاق مركز واحد أثناء قاطع التيار - "
                                  "يُتابَع لباقي المراكز، هذا المركز يبقى مكشوفاً ويحتاج تدخلاً يدوياً فورياً",
                                  symbol=pos_symbol, msg=str(e_pos))
                        notify_telegram(f"[ALERT] فشل إغلاق {pos_symbol} أثناء قاطع التيار الحاسم - "
                                         "تحقق يدوياً من Binance فوراً، المركز قد يبقى مفتوحاً بلا حماية.")
            except Exception as e:
                log_event("error", "فشل إغلاق الصفقات عند قاطع التيار", msg=str(e))
            return (f"قاطع الخسارة الحاسم: الرصيد انخفض إلى {balance:.2f} USDT "
                    f"(أقل من {original_capital * (1-hard_pct):.2f} = {hard_pct*100:.0f}% من رأس المال {original_capital})")
    except Exception as e:
        log_event("warning", "تعذر فحص قاطع التيار", msg=str(e))

    return None


def _base_adaptive_quality_threshold() -> float:
    """يخفض عتبة الجودة تلقائياً لو البوت متأخر عن هدف ~30 صفقة/يوم،
    ويرفعها لو وصل الهدف. لا تنخفض أبداً تحت MIN_QUALITY_FLOOR.
    DIAGNOSTIC_MODE (بطلب صريح - تقرير التشخيص بند 3) يتجاوز كل هذا مؤقتاً
    بعتبة منخفضة ثابتة، فقط للتأكد أن محرك فتح الصفقة يعمل من الأساس -
    إدارة المخاطر (SL/TP/حجم الصفقة/قاطع التيار) لا تتأثر إطلاقاً بهذا الوضع."""
    if CFG.DIAGNOSTIC_MODE:
        return CFG.DIAGNOSTIC_MIN_QUALITY
    base = CFG.MIN_QUALITY_SCORE_THRESHOLD
    floor = CFG.MIN_QUALITY_FLOOR
    if not CFG.QUALITY_ADAPT:
        return base
    opened = STORE.get_today_opened_count()
    target = max(int(CFG.TARGET_TRADES_PER_DAY), 1)
    now = utc_now()
    elapsed_frac = (now.hour * 60 + now.minute) / (24.0 * 60.0)
    expected = target * max(elapsed_frac, 0.04)
    if opened >= target:
        return min(0.70, base + 0.10)
    if opened < expected * 0.40:
        return floor
    if opened < expected * 0.70:
        return max(floor, (base + floor) / 2.0)
    return base


def adaptive_quality_threshold() -> float:
    """العتبة الأساسية + RECOVERY_QUALITY_BOOST (0.05) لو آخر صفقة خاسرة - خروج سريع من التراجع."""
    base = _base_adaptive_quality_threshold()
    try:
        if STORE.last_trade_was_loss():
            return min(base + CFG.RECOVERY_QUALITY_BOOST, 0.95)
    except Exception:
        pass
    return base


def build_halt_diagnostic_message(client, halt_reason: str) -> str:
    """القسم 17 من تدقيق قاطع التيار: عند التوقف، لا تكتفِ بـ'الرصيد منخفض'
    - اعرض كل الأرقام الحقيقية التي بُني عليها القرار حتى يستطيع المستخدم
    الحكم بنفسه هل هو تراجع بوت حقيقي أو تغيير خارجي/مرجع قديم."""
    wallet_txt = available_txt = bot_pnl_txt = baseline_txt = threshold_txt = "غير متاح"
    try:
        wallet = get_wallet_balance(client)
        wallet_txt = f"{wallet:.4f} USDT"
        peak = STORE.get_or_update_peak_balance(wallet, _PEAK_BALANCE_FLOOR)
        baseline_txt = f"{peak:.4f} USDT (أعلى رصيد شُوهد)"
        s = STORE.get_breaker_settings()
        hard_pct = float(s.get("daily_max_loss_pct") if s.get("daily_max_loss_pct") is not None else CFG.DAILY_MAX_LOSS_PCT)
        threshold_txt = f"{peak * (1 - hard_pct):.4f} USDT ({hard_pct*100:.0f}% تحت القمة)"
    except Exception:
        pass
    try:
        available_txt = f"{get_available_balance(client):.4f} USDT"
    except Exception:
        pass
    try:
        bot_pnl_txt = f"{STORE.get_bot_realized_pnl_today():+.4f} USDT (اليوم، محقَّق فقط)"
    except Exception:
        pass
    return (
        f"🛑 <b>TRADING HALTED</b>\n"
        f"السبب: {halt_reason}\n"
        f"رصيد المحفظة: {wallet_txt}\n"
        f"الرصيد المتاح: {available_txt}\n"
        f"PnL البوت: {bot_pnl_txt}\n"
        f"مرجع الحماية (Baseline): {baseline_txt}\n"
        f"عتبة القاطع: {threshold_txt}\n"
        f"(الصفقات المفتوحة حالياً تبقى محمية ومُدارة بالكامل - هذا يمنع صفقات جديدة فقط)\n"
        f"استخدم /breaker reset لو كنت متأكداً أن السبب تغيير خارجي وليس خسارة بوت فعلية."
    )


def format_breaker_status() -> str:
    s = STORE.get_breaker_settings()
    halt = STORE.get_halt_until()
    now = utc_now()
    halted = halt and now < halt
    enabled = bool(int(s.get("breaker_enabled", 1)))
    hard = bool(int(s.get("hard_protection", 1)))
    losses = STORE.recent_consecutive_losses()
    halt_txt = halt.isoformat() if halted else "لا يوجد"
    dd = s.get("daily_drawdown_pct")
    if dd is None:
        dd = CFG.MAX_DAILY_DRAWDOWN_PCT
    hp = s.get("daily_max_loss_pct")
    if hp is None:
        hp = CFG.DAILY_MAX_LOSS_PCT
    bot_pnl_today = STORE.get_bot_realized_pnl_today()
    return (
        f"[BREAKER] قاطع التيار\n"
        f"العادي: {'تشغيل' if enabled else 'إيقاف'}\n"
        f"الحماية الحاسمة (حساب كامل): {'تشغيل' if hard else 'إيقاف'}\n"
        f"متوقف الآن: {'نعم حتى ' + halt_txt if halted else 'لا'}\n"
        f"PnL البوت اليوم (فعلي فقط، لا يشمل تغييرات خارجية): {bot_pnl_today:+.4f} USDT\n"
        f"خسائر متتالية للبوت: {losses}/{int(s.get('max_consecutive_losses') or CFG.MAX_CONSECUTIVE_LOSSES)}\n"
        f"ساعات التوقف: {int(s.get('pause_hours') or CFG.CIRCUIT_BREAKER_PAUSE_HOURS)}\n"
        f"حد تراجع البوت اليومي: {float(dd)*100:.1f}%\n"
        f"حد الحماية الحاسمة (من أعلى رصيد شُوهد): {float(hp)*100:.0f}%\n"
        f"صفقات اليوم: {STORE.get_today_opened_count()}" + (f"/{CFG.TARGET_TRADES_PER_DAY}" if CFG.TARGET_TRADES_PER_DAY > 0 else " (لا هدف عدد محدَّد)") + "\n"
        f"عتبة الجودة الحالية: {adaptive_quality_threshold():.2f}"
    )


def handle_breaker_command(text: str, text_lower: str, client=None) -> Optional[str]:
    """يعالج أوامر قاطع التيار من تيليجرام. يرجع نص الرد أو None لو الأمر ليس للقاطع."""
    raw = text.strip()
    lower = text_lower.strip()
    parts = raw.split()
    if not parts:
        return None

    head = parts[0].lower().lstrip("/")
    is_breaker = head in ("breaker", "circuit", "قاطع")
    if not is_breaker:
        return None

    action = parts[1].lower() if len(parts) >= 2 else "status"
    arg = parts[2] if len(parts) >= 3 else None

    if action in ("status", "حالة", "info") or len(parts) == 1:
        return format_breaker_status()

    if action in ("on", "تشغيل", "enable", "تفعيل"):
        STORE.set_breaker_fields(breaker_enabled=1)
        CFG.CIRCUIT_BREAKER_ENABLED = True
        log_event("info", "circuit_breaker_enabled_via_telegram")
        return "[BREAKER] تم تشغيل قاطع التيار العادي.\n" + format_breaker_status()

    if action in ("off", "إيقاف", "disable", "تعطيل"):
        STORE.set_breaker_fields(breaker_enabled=0)
        CFG.CIRCUIT_BREAKER_ENABLED = False
        log_event("warning", "circuit_breaker_disabled_via_telegram")
        return (
            "[BREAKER] تم إيقاف قاطع التيار العادي (الخسائر المتتالية + التراجع اليومي).\n"
            "الحماية الحاسمة ما زالت تعمل. لتعطيلها: /breaker hard off\n"
            + format_breaker_status()
        )

    if action in ("reset", "إعادة", "clear", "إلغاء"):
        # [إصلاح حاسم]: reset الحقيقي يجب أن يقرأ الرصيد الفعلي ويُعيد ضبط
        # "أعلى رصيد شُوهد" على الواقع الحالي - وإلا فإن الحماية الحاسمة
        # تُعيد تفعيل نفسها فوراً بعد الاستدعاء التالي مباشرة (peak_balance
        # القديم لم يتغيّر) - وهذا بالضبط ما كان يحدث للمستخدم.
        if not client:
            STORE.reset_circuit_breaker()
            return ("[BREAKER] أُلغي halt_until فقط (لا يوجد اتصال Binance للتحقق من الرصيد الفعلي "
                    "وإعادة ضبط مرجع الحماية الحاسمة) - قد يعود القاطع للتفعيل فوراً إن كان الرصيد ما زال دون الحد.\n"
                    + format_breaker_status())
        try:
            actual_balance = get_wallet_balance(client)
        except Exception as e:
            return f"[BREAKER] فشل قراءة الرصيد الفعلي - لم يُنفَّذ أي إعادة ضبط: {e}"
        check_external_balance_change(client)  # مطابقة قبل إعادة الضبط
        STORE.force_reset_peak_balance(max(actual_balance, _PEAK_BALANCE_FLOOR))
        STORE.reset_circuit_breaker()
        log_event("info", "circuit_breaker_reset_via_telegram", actual_balance=actual_balance)
        return (
            f"[BREAKER] تمت إعادة الضبط الحقيقية: الرصيد الفعلي الآن={actual_balance:.4f} USDT.\n"
            f"مرجع الحماية الحاسمة (peak) أصبح={max(actual_balance, _PEAK_BALANCE_FLOOR):.4f} USDT "
            f"(لم يُستعَد أي رقم قديم مخزَّن). أُلغي halt_until وصُفِّرت سلسلة الخسائر.\n"
            + format_breaker_status()
        )

    if action in ("pause", "إيقاف_مؤقت", "sleep"):
        try:
            hours = float(arg) if arg else float(STORE.get_breaker_settings().get("pause_hours") or CFG.CIRCUIT_BREAKER_PAUSE_HOURS)
        except (TypeError, ValueError):
            return "[BREAKER] استخدم: /breaker pause 2   (رقم الساعات)"
        hours = max(0.25, min(hours, 72))
        until = utc_now() + timedelta(hours=hours)
        STORE.set_halt_until(until)
        return f"[BREAKER] إيقاف يدوي لمدة {hours:g} ساعة حتى {until.isoformat()}"

    if action in ("losses", "خسائر"):
        try:
            n = int(arg)
        except (TypeError, ValueError):
            return "[BREAKER] استخدم: /breaker losses 8"
        n = max(2, min(n, 30))
        STORE.set_breaker_fields(max_consecutive_losses=n)
        CFG.MAX_CONSECUTIVE_LOSSES = n
        return f"[BREAKER] حد الخسائر المتتالية = {n}\n" + format_breaker_status()

    if action in ("drawdown", "تراجع"):
        try:
            pct = float(str(arg).replace("%", ""))
        except (TypeError, ValueError):
            return "[BREAKER] استخدم: /breaker drawdown 12   (بالنسبة المئوية)"
        if pct > 1:
            pct = pct / 100.0
        pct = max(0.02, min(pct, 0.50))
        STORE.set_breaker_fields(daily_drawdown_pct=pct)
        CFG.MAX_DAILY_DRAWDOWN_PCT = pct
        return f"[BREAKER] حد التراجع اليومي = {pct*100:.1f}%\n" + format_breaker_status()

    if action in ("hours", "ساعات"):
        try:
            h = int(arg)
        except (TypeError, ValueError):
            return "[BREAKER] استخدم: /breaker hours 4"
        h = max(1, min(h, 48))
        STORE.set_breaker_fields(pause_hours=h)
        CFG.CIRCUIT_BREAKER_PAUSE_HOURS = h
        return f"[BREAKER] ساعات التوقف بعد القاطع = {h}\n" + format_breaker_status()

    if action in ("hard", "حاسم"):
        if arg and arg.lower() in ("off", "إيقاف", "disable", "0"):
            STORE.set_breaker_fields(hard_protection=0)
            CFG.HARD_LOSS_PROTECTION = False
            log_event("warning", "hard_loss_protection_disabled_via_telegram")
            return (
                "[ALERT] أُطفئت الحماية الحاسمة. البوت لن يغلق الصفقات تلقائياً عند خسارة رأس المال الكبيرة.\n"
                + format_breaker_status()
            )
        if arg and arg.lower() in ("on", "تشغيل", "enable", "1"):
            STORE.set_breaker_fields(hard_protection=1)
            CFG.HARD_LOSS_PROTECTION = True
            return "[BREAKER] الحماية الحاسمة مفعّلة.\n" + format_breaker_status()
        try:
            pct = float(str(arg).replace("%", "")) if arg else None
        except (TypeError, ValueError):
            pct = None
        if pct is None:
            return "[BREAKER] استخدم: /breaker hard on | /breaker hard off | /breaker hard 20"
        if pct > 1:
            pct = pct / 100.0
        pct = max(0.05, min(pct, 0.80))
        STORE.set_breaker_fields(hard_protection=1, daily_max_loss_pct=pct)
        CFG.HARD_LOSS_PROTECTION = True
        CFG.DAILY_MAX_LOSS_PCT = pct
        return f"[BREAKER] الحماية الحاسمة عند {pct*100:.0f}%\n" + format_breaker_status()

    return (
        "أوامر قاطع التيار:\n"
        "/breaker — الحالة\n"
        "/breaker on | off — تشغيل/إيقاف القاطع العادي\n"
        "/breaker reset — إلغاء الإيقاف الحالي ومتابعة التداول\n"
        "/breaker pause 2 — إيقاف يدوي لساعتين\n"
        "/breaker losses 8 — حد الخسائر المتتالية\n"
        "/breaker drawdown 12 — حد التراجع اليومي %\n"
        "/breaker hours 4 — ساعات التوقف بعد القاطع\n"
        "/breaker hard on|off|20 — الحماية الحاسمة"
    )


def force_config_over_db(client):
    """ترحيل يُنفَّذ مرة واحدة فقط (ملف علامة): قاعدة البيانات القديمة تحمل حدود قواطع (4%/8%)
    ورموزاً نشطة (SOL/WIF) وقمة رصيد قديمة، وكلها كانت تُطبَّق فوق الإعدادات الجديدة وتوقف
    البوت بعد أول خسارة أو تمنعه من فحص الرموز الجديدة. بعد التشغيل الأول تعود تعديلات
    تيليجرام (/breaker, /setsymbol) للعمل كالمعتاد."""
    if not CFG.FORCE_CONFIG_ON_FIRST_RUN:
        return
    marker_v7 = os.path.join(_SCRIPT_DIR, ".glama7_migrated")
    marker_v6 = os.path.join(_SCRIPT_DIR, ".glama6_migrated")
    marker_v5 = os.path.join(_SCRIPT_DIR, ".glama5_migrated")
    marker_v4 = os.path.join(_SCRIPT_DIR, ".glama4_migrated")
    marker = os.path.join(_SCRIPT_DIR, ".glama3_migrated")
    marker_v2 = os.path.join(_SCRIPT_DIR, ".glama2_migrated")
    if os.path.exists(marker_v7):
        return

    # [إصلاح حرِج - بند مُكتشَف بعد مراجعة صفقات حقيقية] الترحيل السابق
    # Glama5→Glama6 (الكتلة أدناه عند وجود marker_v5) كان يفترض خطأً أن
    # "لا شيء يغيّر حدود القاطع" وتخطّى فرضها على القاعدة القديمة تماماً.
    # لكن Glama 6 غيّر فعلياً MAX_CONSECUTIVE_LOSSES (3→2)،
    # CIRCUIT_BREAKER_PAUSE_HOURS (1→4)، وDAILY_MAX_LOSS_PCT (0.35→0.15) -
    # بطلب صريح موثَّق بنفس ملف الإعدادات. أي تنصيب كان قد رُحِّل من قبل
    # (أي من الحالات v2/v3/v4/v5/v6 أدناه) ظل فعلياً يعمل بحدود القاطع
    # القديمة الأضعف صامتاً طوال هذي المدة، رغم أن الكود يعرض الحدود
    # الجديدة - وهذا بالضبط ما يفسّر عدم إيقاف البوت مبكراً بعد خسائر
    # متتالية حقيقية. هذي الخطوة تصحّح فقط هذي الحقول الثلاثة الموثَّقة
    # صراحة (ولا تلمس الرموز النشطة/قمة الرصيد كي لا تُصفَّر إعدادات
    # المستخدم اليدوية الأخرى عبر تيليجرام).
    def _resync_breaker_limits_once(reason: str):
        try:
            STORE.set_breaker_fields(
                max_consecutive_losses=CFG.MAX_CONSECUTIVE_LOSSES,
                pause_hours=CFG.CIRCUIT_BREAKER_PAUSE_HOURS,
                daily_max_loss_pct=CFG.DAILY_MAX_LOSS_PCT,
            )
            log_event("info", "ترحيل Glama 7: إصلاح حدود قاطع التيار المتخلِّفة عن ترحيل سابق",
                      reason=reason, max_consecutive_losses=CFG.MAX_CONSECUTIVE_LOSSES,
                      pause_hours=CFG.CIRCUIT_BREAKER_PAUSE_HOURS,
                      daily_max_loss_pct=CFG.DAILY_MAX_LOSS_PCT)
            notify_telegram(
                "[UPDATE] Glama 7: تم تصحيح حدود قاطع التيار التي بقيت عالقة على "
                "القيم القديمة منذ ترحيل سابق (خسائر متتالية، ساعات التوقف، حد "
                f"التراجع اليومي) - أصبحت الآن: خسائر متتالية={CFG.MAX_CONSECUTIVE_LOSSES}، "
                f"توقف={CFG.CIRCUIT_BREAKER_PAUSE_HOURS}س، تراجع يومي={CFG.DAILY_MAX_LOSS_PCT*100:.0f}%"
            )
        except Exception as e:
            log_event("warning", "فشل تصحيح حدود قاطع التيار عند ترحيل Glama 7", msg=str(e))

    if os.path.exists(marker_v6):
        _resync_breaker_limits_once("v6_installation_had_stale_breaker_limits")
        with open(marker_v7, "w", encoding="utf-8") as f:
            f.write(utc_iso())
        return
    if os.path.exists(marker_v5):
        # [Glama 6] لا شيء في ترقية Glama5→Glama6 يغيّر حدود القاطع أو
        # قائمة الرموز النشطة المحفوظة في bot_state (فلتر اتجاه متوسط
        # الأمد جديد + CAPITAL_USDT محدَّث لـ5$ - كلاهما كود/CFG، لا حقول
        # DB) - لا داعي لإعادة فرض أي شيء فوق إعدادات المستخدم الحية.
        # [تصحيح Glama 7]: هذا الافتراض كان خاطئاً فعلياً (انظر التعليق
        # أعلى الدالة) - نصحّح حدود القاطع الثلاثة فقط الآن.
        _resync_breaker_limits_once("v5_installation_had_stale_breaker_limits")
        with open(marker_v6, "w", encoding="utf-8") as f:
            f.write(utc_iso())
        with open(marker_v7, "w", encoding="utf-8") as f:
            f.write(utc_iso())
        log_event("info", "ترحيل Glama 6: لا تغييرات أخرى على bot_state مطلوبة (Glama5 مرحَّل مسبقاً)")
        return
    if os.path.exists(marker_v4):
        _resync_breaker_limits_once("v4_installation_had_stale_breaker_limits")
        with open(marker_v5, "w", encoding="utf-8") as f:
            f.write(utc_iso())
        with open(marker_v6, "w", encoding="utf-8") as f:
            f.write(utc_iso())
        with open(marker_v7, "w", encoding="utf-8") as f:
            f.write(utc_iso())
        log_event("info", "ترحيل Glama 5/6: لا تغييرات أخرى على bot_state مطلوبة (Glama4 مرحَّل مسبقاً)")
        return
    if os.path.exists(marker):
        _resync_breaker_limits_once("v3_installation_had_stale_breaker_limits")
        for _m in (marker_v4, marker_v5, marker_v6, marker_v7):
            with open(_m, "w", encoding="utf-8") as f:
                f.write(utc_iso())
        log_event("info", "ترحيل Glama 4/5/6: لا تغييرات أخرى على bot_state مطلوبة (Glama3 مرحَّل مسبقاً)")
        return
    if os.path.exists(marker_v2):
        # تم ترحيل Glama 2 سابقاً: نُحدّث الرموز النشطة (BONK ← ZEC) وحدود القاطع المتخلِّفة
        try:
            STORE.set_active_symbols(tuple(CFG.CANDIDATE_SYMBOLS))
            _resync_breaker_limits_once("v2_installation_had_stale_breaker_limits")
            for _m in (marker, marker_v4, marker_v5, marker_v6, marker_v7):
                with open(_m, "w", encoding="utf-8") as f:
                    f.write(utc_iso())
            log_event("info", "ترحيل Glama 3/4/5/6: مزامنة الرموز النشطة + حدود القاطع", symbols=CFG.CANDIDATE_SYMBOLS)
        except Exception as e:
            log_event("warning", "فشل مزامنة الرموز النشطة", msg=str(e))
        return
    try:
        STORE.set_breaker_fields(
            max_consecutive_losses=CFG.MAX_CONSECUTIVE_LOSSES,
            pause_hours=CFG.CIRCUIT_BREAKER_PAUSE_HOURS,
            daily_drawdown_pct=CFG.MAX_DAILY_DRAWDOWN_PCT,
            daily_max_loss_pct=CFG.DAILY_MAX_LOSS_PCT,
        )
        STORE.set_active_symbols(tuple(CFG.CANDIDATE_SYMBOLS))
        STORE.force_reset_peak_balance(get_wallet_balance(client))
        STORE.set_halt_until(None)
        for _m in (marker, marker_v2, marker_v4, marker_v5, marker_v6, marker_v7):
            with open(_m, "w", encoding="utf-8") as f:
                f.write(utc_iso())
        log_event("info", "ترحيل Glama 7 لمرة واحدة (تشغيل أول): فُرضت الإعدادات الجديدة على قاعدة البيانات",
                  symbols=CFG.CANDIDATE_SYMBOLS)
    except Exception as e:
        log_event("warning", "فشل ترحيل الإعدادات لمرة واحدة", msg=str(e))


def apply_breaker_overrides():
    """يطبّق إعدادات قاطع التيار المحفوظة من تيليجرام على CFG عند الإقلاع."""
    s = STORE.get_breaker_settings()
    CFG.CIRCUIT_BREAKER_ENABLED = bool(int(s.get("breaker_enabled", 1)))
    CFG.HARD_LOSS_PROTECTION = bool(int(s.get("hard_protection", 1)))
    if s.get("max_consecutive_losses"):
        CFG.MAX_CONSECUTIVE_LOSSES = int(s["max_consecutive_losses"])
    if s.get("pause_hours"):
        CFG.CIRCUIT_BREAKER_PAUSE_HOURS = int(s["pause_hours"])
    if s.get("daily_drawdown_pct") is not None:
        CFG.MAX_DAILY_DRAWDOWN_PCT = float(s["daily_drawdown_pct"])
    if s.get("daily_max_loss_pct") is not None:
        CFG.DAILY_MAX_LOSS_PCT = float(s["daily_max_loss_pct"])


def get_available_balance(client: Client) -> float:
    balances = with_retry(client.futures_account_balance, description="get_balance")
    for b in balances:
        if b["asset"] == "USDT":
            return max(float(b.get("availableBalance", 0.0)), 0.0)
    log_event("error", "لم يتم العثور على رصيد USDT المتاح - منع التداول احتياطاً")
    return 0.0


def get_account_equity(client: Client) -> float:
    """totalMarginBalance = الرصيد + الربح/الخسارة غير المحقق على أي مركز
    مفتوح حالياً. بعكس get_wallet_balance، هذي القيمة تتحرك فوراً مع تحرك
    السعر ضد المركز المفتوح - تكشف خسارة كبيرة قبل إغلاق الصفقة فعلياً،
    مو بعدها."""
    account = with_retry(client.futures_account, description="get_account_equity")
    return float(account.get("totalMarginBalance", 0.0))


def get_wallet_balance(client: Client) -> float:
    """totalWalletBalance (وليس availableBalance) - لا يتأثر بهامش مقفول
    بصفقة مفتوحة أو بربح/خسارة غير محققة، فهو أصلح لقياس "خسارة يومية
    حقيقية" بدل تقلبات الهامش المتاح التي قد تُشغّل قاطع التيار خطأً أو
    تفشل في اكتشاف خسارة حقيقية.
    [إصلاح تدقيق حاسم]: لا يوجد أي fallback يُرجع CFG.CAPITAL_USDT كرصيد
    مزيَّف - لو تعذّرت قراءة رصيد USDT الحقيقي، الفشل يجب أن يكون صريحاً
    (استثناء) وليس رقماً ملفَّقاً قد يُغذّي قاطع التيار وحساب الحجم ببيانات
    غير حقيقية."""
    balances = with_retry(client.futures_account_balance, description="get_wallet_balance")
    for b in balances:
        if b["asset"] == "USDT":
            return float(b.get("balance", b.get("availableBalance", 0)))
    raise RuntimeError("تعذّر إيجاد رصيد USDT في استجابة Binance - رفض إرجاع رصيد مُلفَّق")


def check_minimum_margin(client: Client, filters: SymbolFilters) -> bool:
    """الحد الأدنى الحقيقي مشتق من minNotional/leverage الفعلي للرمز - وليس
    رقماً ثابتاً مفترضاً قد لا يطابق الرمز أو الرافعة الفعليين."""
    try:
        required = max(filters.min_notional / CFG.LEVERAGE, CFG.MIN_FREE_MARGIN_USDT)
        available = get_available_balance(client)
        if available < required:
            log_event("error", "الهامش المتاح أقل من الحد الأدنى المطلوب", available=available,
                      required=round(required, 4))
            return False
    except Exception as e:
        log_event("error", "تعذر التحقق من الحد الأدنى للهامش - منع الدخول احتياطاً", msg=str(e))
        return False
    return True


def check_funding_rate(client: Client, side: str, symbol: str = None) -> Optional[str]:
    """[WARN] تصحيح مهم: عندما يكون Funding Rate موجباً، أصحاب المراكز الطويلة
    (LONG) هم من يدفعون؛ وعندما يكون سالباً، أصحاب المراكز القصيرة (SHORT)
    هم من يدفعون. لذلك رافد سالب جداً يضر بالبيع (SELL) وليس الشراء، والعكس
    صحيح لرافد موجب جداً - هذه الدالة تفحص الاتجاه الصحيح حسب جهة الصفقة."""
    if not CFG.CHECK_FUNDING_RATE:
        return None
    symbol = symbol or CFG.SYMBOL
    try:
        funding_info = with_retry(client.futures_funding_rate, symbol=symbol, limit=1,
                                   description="check_funding")
        if not funding_info:
            return None
        rate = float(funding_info[0]["fundingRate"])
        if side == "BUY" and rate > CFG.MAX_ACCEPTABLE_FUNDING_RATE:
            return f"Funding Rate موجب جداً ({rate*100:.3f}%) - اللونغ يدفع، تخطي إشارة الشراء"
        if side == "SELL" and rate < CFG.MIN_ACCEPTABLE_FUNDING_RATE:
            return f"Funding Rate سالب جداً ({rate*100:.3f}%) - الشورت يدفع، تخطي إشارة البيع"
    except Exception as e:
        log_event("error", "تعذر التحقق من Funding Rate - منع الدخول احتياطاً", msg=str(e))
        return "تعذر التحقق من Funding Rate - تخطي الإشارة احتياطاً"
    return None


def check_liquidation_risk(client: Client, current_price: float, symbol: str) -> bool:
    """يستخدم liquidationPrice المُبلَّغ من المنصة نفسها (مبني داخلياً على
    markPrice الحقيقي) - أدق من أي حساب يدوي منفصل لسعر السوق."""
    try:
        positions = with_retry(client.futures_position_information, symbol=symbol,
                                description="get_position_risk")
        for pos in positions:
            amt = float(pos.get("positionAmt", 0))
            if amt == 0:
                continue
            liq_price = float(pos.get("liquidationPrice", 0) or 0)
            if liq_price <= 0:
                continue
            distance_pct = abs(current_price - liq_price) / current_price
            if distance_pct < CFG.LIQUIDATION_DISTANCE_ALERT_PCT:
                log_event("error", "[ALERT] خطر تصفية وشيك - إغلاق طارئ فوري",
                          symbol=symbol, liquidation_price=liq_price, distance_pct=round(distance_pct, 4))
                notify_telegram(f"[ALERT] خطر تصفية على {symbol}! المسافة {distance_pct*100:.2f}% - إغلاق طارئ")
                close_side = SIDE_SELL if amt > 0 else SIDE_BUY
                create_order_idempotent(client, "emergency_close_liquidation_risk",
                                         symbol=symbol, side=close_side, type=ORDER_TYPE_MARKET,
                                         quantity=abs(amt), reduceOnly=True)
                return True
    except Exception as e:
        log_event("warning", "تعذر التحقق من خطر التصفية", symbol=symbol, msg=str(e))
    return False


def get_book_quality(client: Client, price: float, symbol: str = None) -> bool:
    """يفحص اتساع السبريد وبُعد السعر المرجعي عن منتصف دفتر الأوامر قبل
    الدخول - يحمي من فتح صفقة بسعر سيء وقت سيولة ضعيفة أو تقلب حاد."""
    symbol = symbol or CFG.SYMBOL
    try:
        book = with_retry(client.futures_order_book, symbol=symbol, limit=5,
                           description="check_order_book")
        if not book.get("bids") or not book.get("asks"):
            return False
        bid, ask = float(book["bids"][0][0]), float(book["asks"][0][0])
        mid = (bid + ask) / 2
        if mid <= 0:
            return False
        spread_pct = (ask - bid) / mid
        if spread_pct > CFG.MAX_SPREAD_PCT:
            log_event("warning", "السبريد واسع جداً - إلغاء الدخول", spread_pct=round(spread_pct, 5))
            return False
        if abs(price - mid) / mid > CFG.MAX_ALLOWED_SLIPPAGE_PCT:
            log_event("warning", "السعر المرجعي بعيد عن منتصف دفتر الأوامر - إلغاء الدخول")
            return False
        return True
    except Exception as e:
        if CFG.FAIL_CLOSED_MARKET_CHECKS:
            log_event("warning", "تعذر فحص جودة دفتر الأوامر - منع الدخول احتياطاً (Fail-Closed)", msg=str(e))
            return False
        log_event("warning", "تعذر فحص جودة دفتر الأوامر - سيُسمح بالدخول احتياطاً (Fail-Open، غير موصى به)",
                  msg=str(e))
        return True


# ==============================================================================
# 7) مصدر البيانات: WebSocket (شموع مغلقة فقط) بدل REST المتكرر
# ==============================================================================


class KlineStream:
    """جلب الشموع عبر REST polling (مستقر على Termux وبدون تعارض asyncio).
    يتحقق كل بضع ثوانٍ من وجود شمعة مغلقة جديدة."""

    def __init__(self, client: Client, symbol: str, interval: str, lookback: int):
        self.client = client
        self.symbol = symbol
        self.interval = interval
        self.lookback = lookback
        self._lock = threading.Lock()
        self._df: Optional[pd.DataFrame] = None
        self._last_closed_open_time = -1
        self._last_msg_ts = time.time()
        self._running = True

        self._df = self._fetch_closed_klines()
        if len(self._df):
            self._last_closed_open_time = int(self._df["open_time"].iloc[-1])
        log_event("info", "بدء جلب الشموع عبر REST (مستقر على Termux)", symbol=symbol, interval=interval)

    def _raw_to_df(self, raw) -> pd.DataFrame:
        df = pd.DataFrame(raw, columns=[
            "open_time", "open", "high", "low", "close", "volume", "close_time",
            "quote_asset_volume", "trades", "taker_buy_base", "taker_buy_quote", "ignore",
        ])
        # تحويل صريح للأوقات الرقمية أيضاً لتجنب TypeError عند مقارنة close_time مع int
        for col in ["open", "high", "low", "close", "volume", "taker_buy_base", "open_time", "close_time"]:
            df[col] = pd.to_numeric(df[col], errors="coerce")
        df["taker_sell_base"] = df["volume"] - df["taker_buy_base"]
        return df

    def _fetch_closed_klines(self) -> pd.DataFrame:
        raw = with_retry(
            self.client.futures_klines,
            symbol=self.symbol,
            interval=self.interval,
            limit=self.lookback,
            description="rest_klines",
        )
        df = self._raw_to_df(raw)
        now_ms = int(time.time() * 1000)
        # استبعاد الشمعة الحية غير المغلقة
        closed = df[df["close_time"] <= now_ms].reset_index(drop=True)
        return closed

    def wait_for_new_candle(self, timeout=None) -> bool:
        """ينتظر شمعة مغلقة جديدة أو ينتهي الوقت."""
        timeout = timeout or CFG.POSITION_MONITOR_INTERVAL_SEC
        deadline = time.time() + timeout
        while time.time() < deadline and self._running:
            try:
                df = self._fetch_closed_klines()
                self._last_msg_ts = time.time()
                if len(df) == 0:
                    time.sleep(1)
                    continue
                latest_open = int(df["open_time"].iloc[-1])
                if latest_open > self._last_closed_open_time:
                    with self._lock:
                        self._df = df.tail(self.lookback).reset_index(drop=True)
                        self._last_closed_open_time = latest_open
                    return True
            except Exception as e:
                log_event("warning", "فشل جلب الشموع عبر REST", msg=str(e))
            time.sleep(1.5)
        # حتى لو ما في شمعة جديدة، حدّث البيانات
        try:
            df = self._fetch_closed_klines()
            with self._lock:
                if len(df):
                    self._df = df.tail(self.lookback).reset_index(drop=True)
            self._last_msg_ts = time.time()
        except Exception as e:
            log_event("warning", "فشل جلب الشموع الدورية (KlineStream) - سيُعاد المحاولة بالدورة القادمة", msg=str(e))
        return False

    def seconds_since_last_message(self) -> float:
        return time.time() - self._last_msg_ts

    def get_df(self) -> pd.DataFrame:
        with self._lock:
            if self._df is None or len(self._df) == 0:
                return pd.DataFrame()
            return self._df.copy()

    def stop(self):
        self._running = False


_BTC_DF_CACHE = {"ts": 0.0, "df": None}
_BTC_DF_CACHE_TTL_SEC = 30  # مرجعي فقط لنقاط الترتيب - لا حاجة لتحديث لحظي كل دورة فحص


def get_btc_reference_df(client: Client, lookback: int) -> pd.DataFrame:
    """[إصلاح بند 5 من المواصفة - حرِج] مصدر بيانات صريح ومستقل لـBTCUSDT
    حصراً. كان الكود سابقاً يستخدم stream.get_df() (بيانات الرمز الرئيسي
    CFG.SYMBOL الحالي - مثلاً 1000SATSUSDT أو XRPUSDT) ويسميها btc_df،
    مما يُفسد btc_momentum/btc_correlation/relative_strength كلياً كلما
    لم يكن الرمز المتداول حالياً هو BTCUSDT فعلاً. هذي الدالة تجلب
    BTCUSDT دائماً وبشكل صريح، بذاكرة تخزين مؤقت قصيرة (TTL) حتى لا تُضاف
    طلبات REST إضافية لكل عملة مرشحة في نفس دورة الفحص."""
    now = time.time()
    cached_df = _BTC_DF_CACHE["df"]
    if cached_df is not None and (now - _BTC_DF_CACHE["ts"]) < _BTC_DF_CACHE_TTL_SEC:
        return cached_df
    try:
        raw = with_retry(client.futures_klines, symbol="BTCUSDT", interval=CFG.TIMEFRAME,
                          limit=lookback, description="btc_reference_klines")
        df = pd.DataFrame(raw, columns=[
            "open_time", "open", "high", "low", "close", "volume", "close_time",
            "quote_asset_volume", "trades", "taker_buy_base", "taker_buy_quote", "ignore",
        ])
        for col in ["open", "high", "low", "close", "volume", "taker_buy_base", "open_time", "close_time"]:
            df[col] = pd.to_numeric(df[col], errors="coerce")
        df["taker_sell_base"] = df["volume"] - df["taker_buy_base"]
        now_ms = int(time.time() * 1000)
        df = df[df["close_time"] <= now_ms].reset_index(drop=True)
        _BTC_DF_CACHE["df"] = df
        _BTC_DF_CACHE["ts"] = now
        return df
    except Exception as e:
        log_event("warning", "تعذر جلب بيانات BTCUSDT المرجعية (btc_reference_df)", msg=str(e))
        # عند الفشل: أعِد آخر نسخة صالحة إن وُجدت (أفضل من إسقاط الفحص
        # بالكامل)، وإلا DataFrame فارغ يجعل المُستدعي يتجاهل مقارنة BTC بأمان.
        return cached_df if cached_df is not None else pd.DataFrame()



# ==============================================================================
# 8) المؤشرات: الدعم/المقاومة، AMB، Bollinger %B
# ==============================================================================

def find_support_resistance(df: pd.DataFrame, lookback: int):
    """يبحث عن أقرب دعم/مقاومة هيكليين حقيقيين ضمن كامل البيانات المتاحة
    (وليس فقط آخر بضع شمعات) - نقطة قمة/قاع محلية تتطلب أن تكون الأعلى/
    الأدنى ضمن `lookback` شمعة على كل جانب. هذا يلتقط مستويات هيكلية أقدم
    وأكثر دلالة كان النظام السابق يفوّتها لأنه كان يفحص فقط نافذة ضيقة
    جداً قرب نهاية البيانات (آخر ~lookback*2 شمعة تقريباً).

    [WARN] لا يوجد Lookahead Bias حقيقي هنا في التشغيل الحي: الدالة تُستدعى من
    جديد كل شمعة مغلقة بأحدث بيانات متاحة فقط، فأي "تأكيد" للمستوى يعتمد
    حصرياً على شموع مغلقة فعلياً لحظة الاستدعاء - لا بيانات مستقبلية."""
    highs, lows = df["high"].values, df["low"].values
    n = len(df)
    current_price = float(df["close"].iloc[-1]) if n > 0 else 0.0
    if current_price <= 0 or n < lookback * 2 + 2:
        return None, None

    resistance_candidates, support_candidates = [], []
    for i in range(lookback, n - 1 - lookback):
        window_high = highs[i - lookback:i + lookback + 1]
        window_low = lows[i - lookback:i + lookback + 1]
        if highs[i] == window_high.max():
            resistance_candidates.append(highs[i])
        if lows[i] == window_low.min():
            support_candidates.append(lows[i])

    # أقرب دعم فعلي تحت السعر الحالي، وأقرب مقاومة فعلية فوقه - وليس مجرد
    # آخر قمة/قاع صودف وجودهما بغض النظر عن موقعهما من السعر
    valid_supports = [s for s in support_candidates
                       if s < current_price and (current_price - s) / current_price <= CFG.MAX_SR_DISTANCE_PCT]
    valid_resistances = [r for r in resistance_candidates
                          if r > current_price and (r - current_price) / current_price <= CFG.MAX_SR_DISTANCE_PCT]

    support = max(valid_supports) if valid_supports else None
    resistance = min(valid_resistances) if valid_resistances else None
    return support, resistance


def compute_amb_trend(df: pd.DataFrame) -> pd.Series:
    close = df["close"].values
    high = df["high"].values
    low = df["low"].values
    n = len(close)

    adapt_len = CFG.AMB_ADAPT_LEN
    direction = np.abs(close - np.roll(close, adapt_len))
    direction[:adapt_len] = 0.0
    abs_diff = np.abs(np.diff(close, prepend=close[0]))
    noise = pd.Series(abs_diff).rolling(adapt_len).sum().fillna(0).values
    er = np.where(noise != 0, direction / np.where(noise == 0, 1, noise), 0.0)

    fast_sc = 2.0 / (CFG.AMB_FAST_SMOOTH + 1)
    slow_sc = 2.0 / (CFG.AMB_SLOW_SMOOTH + 1)
    sc = (er * (fast_sc - slow_sc) + slow_sc) ** 2

    ama1 = np.zeros(n)
    ama1[0] = close[0]
    for i in range(1, n):
        ama1[i] = ama1[i - 1] + sc[i] * (close[i] - ama1[i - 1])

    ama1_s = pd.Series(ama1)
    ama2 = ama1_s.ewm(span=max(2, round(CFG.AMB_BASE_LEN * 0.5)), adjust=False).mean()
    amr_line = ama2.ewm(span=2, adjust=False).mean()

    prev_close = pd.Series(close).shift(1)
    tr = pd.concat([
        pd.Series(high) - pd.Series(low),
        (pd.Series(high) - prev_close).abs(),
        (pd.Series(low) - prev_close).abs(),
    ], axis=1).max(axis=1)
    atr = tr.ewm(span=CFG.AMB_ATR_LEN, adjust=False).mean()
    atr_smooth = atr.ewm(span=CFG.AMB_BAND_SMOOTH, adjust=False).mean()
    atr_norm = atr_smooth.ewm(span=CFG.AMB_ATR_LEN, adjust=False).mean()
    vol_ratio = (atr_smooth / atr_norm.replace(0, np.nan)).fillna(1.0)

    dyn_mult_up = CFG.AMB_UPPER_MULT * vol_ratio.clip(0.5, 1.8)
    dyn_mult_dn = CFG.AMB_LOWER_MULT * vol_ratio.clip(0.5, 1.8)
    upper_band = (amr_line + dyn_mult_up * atr_smooth).ewm(span=CFG.AMB_BAND_SMOOTH, adjust=False).mean()
    lower_band = (amr_line - dyn_mult_dn * atr_smooth).ewm(span=CFG.AMB_BAND_SMOOTH, adjust=False).mean()

    is_bull = np.empty(n, dtype=bool)
    is_bull[0] = True
    for i in range(1, n):
        if close[i] > upper_band.iloc[i]:
            is_bull[i] = True
        elif close[i] < lower_band.iloc[i]:
            is_bull[i] = False
        else:
            is_bull[i] = is_bull[i - 1]
    return pd.Series(is_bull, index=df.index)


def compute_bb_percent(df: pd.DataFrame) -> pd.Series:
    close = df["close"]
    basis = close.rolling(CFG.BB_LENGTH).mean()
    dev = CFG.BB_MULT * close.rolling(CFG.BB_LENGTH).std()
    upper = basis + dev
    lower = basis - dev
    band_width = upper - lower
    # عرض النطاق قد يساوي صفر تماماً في بداية الشموع أو وقت سعر ثابت تماماً
    # (تقسيم على صفر = NaN/inf) - نحمي القيمة بدل تمريرها كإشارة صالحة
    pct_b = (close - lower) / band_width.replace(0, np.nan)
    return pct_b.clip(0, 1)


def price_jump_blocked(df: pd.DataFrame) -> bool:
    """قفزة سعر حادة بين شمعتين متتاليتين غالباً أخبار/سيولة غير طبيعية -
    نلغي الإشارة بدل التداول عليها كأنها نمط سعري عادي.

    الحد أصبح نسبياً لتقلب كل عملة (ATR) بدل نسبة ثابتة موحّدة للجميع -
    نسبة ثابتة كانت تُنصف BTC (تقلبه الطبيعي أقل من هذا الحد غالباً) بينما
    تُعاقب عملات متقلبة بطبيعتها (مثل DOGE) حتى في حركتها العادية غير
    المرتبطة بأي خبر فعلي. الحد الثابت (MAX_PRICE_JUMP_PCT) يبقى كأرضية
    دنيا مطلقة (Safety Floor) لأي عملة هادئة جداً حتى لا يصبح حدها شبه صفر."""
    if len(df) < 3:
        return True
    previous = float(df["close"].iloc[-2])
    current = float(df["close"].iloc[-1])
    if previous <= 0:
        return True
    jump = abs(current - previous) / previous

    atr = calculate_atr(df)
    atr_pct = (atr / previous) if (atr > 0 and previous > 0) else 0.0
    # اسمح بقفزة تصل لأربعة أضعاف الحركة الطبيعية للعملة (ATR)، بحد أدنى
    # مطلق = MAX_PRICE_JUMP_PCT حتى لا يصبح الحد شبه صفر لعملة هادئة جداً
    adaptive_threshold = max(CFG.MAX_PRICE_JUMP_PCT, atr_pct * 4.0)

    if jump > adaptive_threshold:
        log_event("warning", "قفزة سعرية حادة بين شمعتين - إلغاء الإشارة",
                  jump=round(jump, 4), threshold=round(adaptive_threshold, 4), atr_pct=round(atr_pct, 4))
        return True
    return False


def calculate_realized_pnl(side: str, entry_price: float, exit_price: float, qty: float,
                            fee_rate: float) -> float:
    """PnL تقديري بالدولار (يخصم عمولة الدخول والخروج بمعدل ثابت مُقدَّر).
    [WARN] هذا تقريب وليس الرقم الحقيقي من Binance - العمولة الفعلية قد تختلف
    (خصم BNB، مستوى VIP، إلخ)، ولا يشمل رسوم Funding. استخدم
    get_authoritative_pnl_usdt() كمصدر أول؛ هذه الدالة احتياطية فقط لو
    تعذر الوصول لسجل الدخل الحقيقي من المنصة."""
    gross = (exit_price - entry_price) * qty if side == "BUY" else (entry_price - exit_price) * qty
    fees = (entry_price * qty + exit_price * qty) * fee_rate
    return gross - fees


def get_authoritative_pnl_usdt(client: Client, since_iso: str, estimate_fallback: float,
                                symbol: str = None) -> tuple:
    """يستخرج الربح/الخسارة الحقيقي بالدولار من futures_income_history -
    المصدر الوحيد الموثوق فعلياً، لأنه يشمل realizedPnl الحقيقي + العمولة
    الفعلية (بما فيها خصم BNB إن وجد) + رسوم Funding خلال مدة الصفقة، بدل
    معادلة تقريبية مبنية على سعرين فقط. لو فشل الاستعلام أو رجع فارغاً
    (شبكة، صلاحيات، إلخ)، نرجع للتقدير الحسابي بدل حجب تسجيل الصفقة كلياً -
    رقم تقريبي أفضل من عدم تسجيل الصفقة إطلاقاً.
    يُرجع (net_pnl_usdt, fee_total, funding_total) - net_pnl_usdt = المجموع
    الكلي (realizedPnl + العمولة + التمويل) وهو الرقم المُلزم للتسجيل؛
    fee_total وfunding_total للعرض/التشخيص فقط (بطلب صريح في سجل الصفقة)."""
    symbol = symbol or CFG.SYMBOL
    try:
        since_dt = datetime.fromisoformat(since_iso)
        since_ms = int(since_dt.timestamp() * 1000) - 5000  # هامش أمان 5 ثوانٍ قبل وقت الفتح المحفوظ
    except (ValueError, TypeError) as e:
        log_event("warning", "تعذر تحليل وقت فتح الصفقة لاستخراج PnL الحقيقي - استخدام التقدير", msg=str(e))
        return estimate_fallback, None, None

    try:
        income = with_retry(client.futures_income_history, symbol=symbol, startTime=since_ms,
                             description="get_income_history")
    except Exception as e:
        log_event("warning", "تعذر جلب سجل الدخل الحقيقي من Binance - استخدام التقدير الحسابي بدلاً منه",
                  msg=str(e))
        return estimate_fallback, None, None

    total = 0.0
    fee_total = 0.0
    funding_total = 0.0
    matched_entries = 0
    for entry in income:
        itype = entry.get("incomeType")
        if itype in ("REALIZED_PNL", "COMMISSION", "FUNDING_FEE"):
            try:
                amount = float(entry.get("income", 0))
                total += amount
                if itype == "COMMISSION":
                    fee_total += amount
                elif itype == "FUNDING_FEE":
                    funding_total += amount
                matched_entries += 1
            except (ValueError, TypeError):
                continue

    if matched_entries == 0:
        log_event("warning", "سجل الدخل الحقيقي فارغ لهذه الفترة - استخدام التقدير الحسابي بدلاً منه")
        return estimate_fallback, None, None

    log_event("info", "تم استخراج PnL حقيقي من سجل دخل Binance", real_pnl_usdt=round(total, 4),
              fee_total=round(fee_total, 4), funding_total=round(funding_total, 4),
              estimate_was=round(estimate_fallback, 4), entries=matched_entries)
    return total, fee_total, funding_total


def check_liquidation_confirmation(client: Client, side: str, symbol: str) -> bool:
    """تأكيد اختياري: موجة تصفيات إجبارية حديثة بنفس اتجاه الإشارة تعني
    الحركة فعلاً "اصطياد سيولة" حقيقي (متوافق مع فكرة الاستراتيجية الأساسية)
    مو مجرد تقلب عادي. معطّل افتراضياً (USE_LIQUIDATION_CONFIRMATION=False).
    أي فشل بالاستعلام لا يمنع التداول - يُعامل كـ"لا تأكيد إضافي" فقط."""
    if not CFG.USE_LIQUIDATION_CONFIRMATION:
        return True  # الفلتر معطّل - لا يمنع شيء

    try:
        liquidations = with_retry(client.futures_liquidation_orders, symbol=symbol, limit=50,
                                   description="check_liquidation_confirmation")
    except AttributeError:
        log_event("error", "endpoint التصفيات غير متاح بهذه النسخة من python-binance - منع الدخول لأن الفلتر مفعّل")
        return False
    except Exception as e:
        log_event("error", "تعذر جلب بيانات التصفيات - منع الدخول لأن فلتر التصفيات مفعّل", msg=str(e))
        return False

    # صفقة شراء (BUY) تتأكد بتصفيات مراكز SELL (اضطرار البائعين للشراء
    # لإغلاق مراكزهم يدفع السعر للأعلى)، والعكس لصفقة بيع
    target_side = "SELL" if side == "BUY" else "BUY"
    matching = [o for o in liquidations if o.get("side") == target_side]

    confirmed = len(matching) >= CFG.MIN_LIQUIDATION_CONFIRMATION_COUNT
    log_event("info", f"تأكيد التصفيات: {len(matching)}/{CFG.MIN_LIQUIDATION_CONFIRMATION_COUNT} "
              f"مطلوبة - {'مؤكد [OK]' if confirmed else 'غير كافٍ [FAIL]'}")
    return confirmed


def _sweep_rejection_valid(o: float, h: float, l: float, c: float, side: str) -> bool:
    """التعريف الرياضي الدقيق للرفض (Rejection) - يُستخدم لكل من BUY/SELL.
    range > 0 يُتحقق منه قبل أي قسمة (يُفترض من المستدعي أنه تحقق مسبقاً)."""
    rng = h - l
    if rng <= 0:
        return False
    if side == "BUY":
        strong = (c > o) and ((c - l) / rng >= CFG.SWEEP_REJECTION_STRONG_PCT)
        lower_wick = min(o, c) - l
        acceptable = (lower_wick / rng >= CFG.SWEEP_REJECTION_ACCEPTABLE_PCT) and (c > (h + l) / 2)
        return bool(strong or acceptable)
    else:
        strong = (c < o) and ((h - c) / rng >= CFG.SWEEP_REJECTION_STRONG_PCT)
        upper_wick = h - max(o, c)
        acceptable = (upper_wick / rng >= CFG.SWEEP_REJECTION_ACCEPTABLE_PCT) and (c < (h + l) / 2)
        return bool(strong or acceptable)


def _sweep_atr_bonus(penetration: float, atr: float) -> float:
    """اختراق المستوى (Penetration) مقابل ATR - Soft Filter فقط، لا يرفض أبداً.
    Penetration = المقدار الذي تجاوز فيه السعر المستوى (وليس طول الفتيل)."""
    if atr <= 0 or penetration <= 0:
        return 0.0
    if penetration >= CFG.SWEEP_ATR_PENETRATION_STRONG * atr:
        return CFG.SWEEP_ATR_BONUS_STRONG
    if penetration >= CFG.SWEEP_ATR_PENETRATION_WEAK * atr:
        return CFG.SWEEP_ATR_BONUS_WEAK
    return 0.0


def detect_liquidity_sweep(df: pd.DataFrame, lookback: int = 20, amb_is_bull: bool = None,
                            bb_pct: float = None) -> Optional[tuple]:
    """اصطياد سيولة (Liquidity Sweep) + انعكاس - الاستراتيجية الرئيسية.
    شرط الكسر: فتيل يتجاوز أعلى قمة/أدنى قاع خلال `lookback` شمعة مرجعية،
    ثم إغلاق يعود داخل النطاق. شروط الجودة الإلزامية: حجم >= 1.3× المتوسط،
    دلتا تؤكد الاتجاه، رفض رياضي صالح (قوي أو مقبول)، **وAMB/BB الإلزاميان
    إذا REQUIRE_*=True** (إصلاح حرج بطلب صريح - كانت هذي البوابة الرئيسية
    تتجاوز AMB/BB تماماً رغم تفعيلهما في الإعدادات، لأنها الوحيدة التي لا
    تمر عبر _confirm_and_score). Penetration/ATR فلتر ناعم (مكافأة نقاط
    فقط، لا يرفض أبداً).

    التوقيت: لو شمعة الكسر نفسها فيها رفض مكتمل → تُستخدم مباشرة (نفس
    الشمعة). لو الكسر بلا رفض كافٍ، نسمح بشمعة تأكيد واحدة فقط تالية مباشرة
    (لا ننتظر أكثر من شمعة واحدة إضافية).

    يُرجع (side, atr_bonus) أو None. كل سبب رفض يُسجَّل بوضوح."""
    n = len(df)
    if n < lookback + 3:
        return None

    def _amb_bb_penalty(side: str, log_tag: str) -> float:
        """[مُعدَّل بطلب صريح] AMB/BB لم تعودا رفضاً قاطعاً - عقوبة نقاط فقط
        (مثل BOS/Retest تماماً الآن، توحيداً حقيقياً بين كل المسارات) لزيادة
        عدد الصفقات، مع إبقاء المعلومة مؤثرة على الترتيب لا حذفها بالكامل."""
        penalty = 0.0
        if amb_is_bull is not None and CFG.REQUIRE_AMB_CONFIRMATION and (amb_is_bull != (side == "BUY")):
            log_event("info", "amb_soft_penalty", reason_detail="amb_confirmation_failed", source=log_tag, side=side)
            penalty += 0.08
        if bb_pct is not None:
            if side == "BUY" and CFG.REQUIRE_BB_CONFIRMATION and bb_pct > CFG.BB_MIN_PCT + 0.15:
                log_event("info", "bb_soft_penalty", reason_detail="bb_confirmation_failed",
                          source=log_tag, side="BUY", bb_pct=round(bb_pct, 3))
                penalty += 0.08
            elif side == "SELL" and CFG.REQUIRE_BB_CONFIRMATION and bb_pct < CFG.BB_MAX_PCT - 0.15:
                log_event("info", "bb_soft_penalty", reason_detail="bb_confirmation_failed",
                          source=log_tag, side="SELL", bb_pct=round(bb_pct, 3))
                penalty += 0.08
        return penalty

    def _evaluate_break(sweep_pos: int, ref_start: int, ref_end: int, log_tag: str):
        """يفحص هل df.iloc[sweep_pos] كسرت مستوى الفترة المرجعية [ref_start,ref_end)
        وتحقق كل شروط الجودة. يُرجع (side, atr_bonus) أو None (مع تسجيل السبب)."""
        if ref_start < 0 or (ref_end - ref_start) < lookback:
            return None
        reference = df.iloc[ref_start:ref_end]
        swept_high = float(reference["high"].max())
        swept_low = float(reference["low"].min())

        candle = df.iloc[sweep_pos]
        o, h = float(candle["open"]), float(candle["high"])
        l, c = float(candle["low"]), float(candle["close"])
        rng = h - l
        if rng <= 0:
            log_event("info", "signal_rejected", reason="invalid_range", source=log_tag)
            return None

        side = level = None
        penetration = 0.0
        broke_low_now = l < swept_low and c > swept_low
        broke_high_now = h > swept_high and c < swept_high
        if broke_low_now and broke_high_now:
            # [إصلاح انحياز BUY - بند 2 من المواصفة] الشمعة كسرت المستويين
            # معاً (حالة غير عادية) - لا يجوز تفضيل BUY بترتيب if/elif.
            # تُصنَّف الحالة ملتبسة وتُرفض صراحة بدل اختيار جهة عشوائياً.
            log_event("info", "signal_rejected", reason="AMBIGUOUS_SWEEP", source=log_tag,
                      note="both_levels_broken_same_candle")
            return None
        elif broke_low_now:
            side, level, penetration = "BUY", swept_low, swept_low - l
        elif broke_high_now:
            side, level, penetration = "SELL", swept_high, h - swept_high
        if side is None:
            return None  # لا كسر إطلاقاً على هذي الشمعة - ليس فشل جودة، فقط لا يوجد نمط

        amb_bb_pen = _amb_bb_penalty(side, log_tag)

        vol_window = df["volume"].iloc[ref_start:ref_end]
        avg_vol = vol_window.mean()
        candle_vol = float(candle["volume"])
        if not np.isfinite(avg_vol) or avg_vol <= 0:
            log_event("info", "signal_rejected", reason="invalid_range", source=log_tag, note="avg_vol_invalid")
            return None
        if candle_vol < avg_vol * CFG.SWEEP_VOLUME_MULTIPLIER:
            log_event("info", "signal_rejected", reason="low_volume", source=log_tag, side=side,
                      volume=round(candle_vol, 4), required=round(avg_vol * CFG.SWEEP_VOLUME_MULTIPLIER, 4))
            return None

        delta = float(candle.get("taker_buy_base", 0) or 0) - float(candle.get("taker_sell_base", 0) or 0)
        delta_conflict = (side == "BUY" and delta <= 0) or (side == "SELL" and delta >= 0)
        # [إصلاح جودة الاتجاه بطلب صريح]: مخالفة قوية لـDelta = رفض صريح
        # للإشارة (وليس مجرد عقوبة نقاط) - "قوية" تعني أن حجم البيع/الشراء
        # المعاكس يشكّل نسبة معتبرة (10%+) من حجم الشمعة كاملة، أي ضغط
        # عكسي حقيقي وليس مجرد اختلال بسيط عشوائي.
        strong_delta_against = delta_conflict and candle_vol > 0 and abs(delta) >= candle_vol * 0.10
        if strong_delta_against:
            log_event("info", "signal_rejected", reason="REJECT_DELTA_CONFLICT", reason_detail="strong_delta_against_direction", source=log_tag,
                      side=side, delta=round(delta, 4), candle_vol=round(candle_vol, 4),
                      delta_pct_of_volume=round(abs(delta) / candle_vol * 100, 2))
            return None
        if delta_conflict:
            log_event("info", "sweep_delta_soft_penalty", source=log_tag, side=side, delta=round(delta, 4))

        if not _sweep_rejection_valid(o, h, l, c, side):
            log_event("info", "signal_rejected", reason="weak_wick", source=log_tag, side=side)
            return None

        atr = calculate_atr(df.iloc[:sweep_pos + 1])
        bonus = _sweep_atr_bonus(penetration, atr)
        if delta_conflict:
            bonus = min(bonus, 0.0) - 0.04
        bonus -= amb_bb_pen
        return (side, bonus)

    # === الحالة 1: شمعة الكسر تحتوي الرفض بنفسها (نفس الشمعة) ===
    result = _evaluate_break(n - 1, (n - 1) - lookback, n - 1, "sweep")
    if result:
        return result

    # === الحالة 2: شمعة سابقة واحدة فقط كسرت المستوى، والشمعة الحالية تؤكد بالرفض ===
    # نفس المستوى المرجعي المستخدم لو كانت الشمعة السابقة هي شمعة الكسر
    ref_start2 = (n - 1) - lookback
    ref_end2 = n - 1
    if ref_start2 >= 0 and (ref_end2 - ref_start2) >= lookback:
        reference2 = df.iloc[ref_start2:ref_end2]
        swept_high2 = float(reference2["high"].max())
        swept_low2 = float(reference2["low"].min())
        prev_candle = df.iloc[n - 2]
        pl, ph = float(prev_candle["low"]), float(prev_candle["high"])
        broke_low = pl < swept_low2
        broke_high = ph > swept_high2
        if broke_low and broke_high:
            # [إصلاح انحياز BUY - بند 2 من المواصفة] نفس المبدأ: الشمعة
            # السابقة كسرت المستويين معاً - حالة ملتبسة تُرفض ولا تُفضَّل BUY.
            log_event("info", "signal_rejected", reason="AMBIGUOUS_SWEEP", source="sweep_confirm",
                      note="both_levels_broken_prev_candle")
        elif broke_low or broke_high:
            side2 = "BUY" if broke_low else "SELL"
            level2 = swept_low2 if broke_low else swept_high2
            amb_bb_pen2 = _amb_bb_penalty(side2, "sweep_confirm")
            confirm = df.iloc[n - 1]
            co, ch = float(confirm["open"]), float(confirm["high"])
            cl, cc = float(confirm["low"]), float(confirm["close"])
            crng = ch - cl
            if crng <= 0:
                log_event("info", "signal_rejected", reason="invalid_range", source="sweep_confirm")
                return None
            if _sweep_rejection_valid(co, ch, cl, cc, side2):
                vol_window2 = df["volume"].iloc[ref_start2:ref_end2]
                avg_vol2 = vol_window2.mean()
                confirm_vol = float(confirm["volume"])
                if np.isfinite(avg_vol2) and avg_vol2 > 0 and confirm_vol >= avg_vol2 * CFG.SWEEP_VOLUME_MULTIPLIER:
                    delta2 = float(confirm.get("taker_buy_base", 0) or 0) - float(confirm.get("taker_sell_base", 0) or 0)
                    delta_ok = (delta2 > 0) if side2 == "BUY" else (delta2 < 0)
                    strong_delta_against2 = (not delta_ok) and confirm_vol > 0 and abs(delta2) >= confirm_vol * 0.10
                    if strong_delta_against2:
                        log_event("info", "signal_rejected", reason="REJECT_DELTA_CONFLICT", reason_detail="strong_delta_against_direction",
                                  source="sweep_confirm", side=side2, delta=round(delta2, 4),
                                  candle_vol=round(confirm_vol, 4))
                        return None
                    penetration2 = (level2 - pl) if side2 == "BUY" else (ph - level2)
                    atr2 = calculate_atr(df.iloc[:n - 1])
                    bonus2 = _sweep_atr_bonus(penetration2, atr2)
                    if not delta_ok:
                        log_event("info", "sweep_delta_soft_penalty", source="sweep_confirm", side=side2)
                        bonus2 = min(bonus2, 0.0) - 0.04
                    bonus2 -= amb_bb_pen2
                    return (side2, bonus2)
                else:
                    log_event("info", "signal_rejected", reason="low_volume", source="sweep_confirm", side=side2)
            else:
                log_event("info", "signal_rejected", reason="no_rejection", source="sweep_confirm", side=side2)
            return None

    log_event("info", "signal_rejected", reason="tiny_sweep", source="sweep")
    return None


def detect_bos_retest(df: pd.DataFrame, lookback: int = 20) -> Optional[str]:
    """كسر هيكل حقيقي (BOS) + اندفاع (Displacement) + إعادة اختبار (Retest)
    + رفض/تأكيد عند الإعادة - طبقة ثانوية مستقلة تماماً عن Liquidity Sweep.
    مجرد ملامسة دعم/مقاومة مع إغلاق لا تُعتبر كافية بعد الآن (كانت الطريقة
    القديمة) - يجب توفر التسلسل الكامل: BOS ← Displacement ← Retest ← رفض.

    البحث يغطي آخر 10 شمعات كنقطة بداية محتملة لـBOS، بشرط أن يكون هناك
    مجال كافٍ بعدها لشمعة Displacement + إعادة اختبار تنتهي بالشمعة الحالية
    (الشمعة الأخيرة يجب أن تكون هي شمعة التأكيد/الرفض عند إعادة الاختبار،
    وإلا فالفرصة انقضت زمنياً ولا تُعتبر إشارة "الآن")."""
    n = len(df)
    if n < lookback + 10:
        return None

    search_start = max(lookback, n - 16)
    # BUG-04: نضمن أن شمعة الاندفاع (bos_pos+1) منفصلة تماماً عن شمعة الرفض الحالية (n-1)
    # أي: bos_pos + 1 < n - 1  ⟹  bos_pos <= n - 3  (الحد الأعلى للحلقة = n-2 حصري)
    for bos_pos in range(search_start, n - 2):
        reference = df.iloc[bos_pos - lookback:bos_pos]
        if len(reference) < lookback:
            continue
        swing_high = float(reference["high"].max())
        swing_low = float(reference["low"].min())
        bos_close = float(df.iloc[bos_pos]["close"])

        bos_side = level = None
        if bos_close > swing_high:
            bos_side, level = "BUY", swing_high
        elif bos_close < swing_low:
            bos_side, level = "SELL", swing_low
        if bos_side is None:
            continue

        # Displacement: الشمعة التالية مباشرة تُظهر جسماً حقيقياً واضحاً بنفس الاتجاه
        # ويجب أن تكون مستقلة عن شمعة الرفض (الأخيرة) — لا يجوز أن تكون نفسها
        if bos_pos + 1 >= n - 1:
            continue
        disp = df.iloc[bos_pos + 1]
        d_o, d_h = float(disp["open"]), float(disp["high"])
        d_l, d_c = float(disp["low"]), float(disp["close"])
        d_range = d_h - d_l
        if d_range <= 0:
            continue
        d_body_ratio = abs(d_c - d_o) / d_range
        if d_body_ratio < 0.40:
            log_event("info", "signal_rejected", reason="no_displacement", source="bos_retest", side=bos_side)
            continue
        if (bos_side == "BUY" and d_c <= d_o) or (bos_side == "SELL" and d_c >= d_o):
            log_event("info", "signal_rejected", reason="no_displacement", source="bos_retest", side=bos_side)
            continue

        # Retest: نبحث عن إعادة اختبار لمنطقة الكسر تنتهي بالشمعة الحالية
        # تحديداً (عشان تكون إشارة قابلة للتنفيذ الآن، لا فرصة فائتة)
        retest = df.iloc[-1]
        r_o, r_h = float(retest["open"]), float(retest["high"])
        r_l, r_c = float(retest["low"]), float(retest["close"])
        touched = (r_l <= level * 1.003) if bos_side == "BUY" else (r_h >= level * 0.997)
        if not touched:
            continue
        if not _sweep_rejection_valid(r_o, r_h, r_l, r_c, bos_side):
            log_event("info", "signal_rejected", reason="no_rejection", source="bos_retest", side=bos_side)
            continue

        return bos_side

    return None


def detect_sr_touch(df: pd.DataFrame) -> Optional[str]:
    """مسار ثالث أخف: ملامسة أقرب دعم/مقاومة هيكلي + رفض صالح على الشمعة الحالية.
    يُستخدم لملء هدف ~30 صفقة عندما لا يكتمل Sweep أو BOS الكامل."""
    if not CFG.ALLOW_SR_TOUCH_SIGNAL:
        return None
    support, resistance = find_support_resistance(df, CFG.SWING_LOOKBACK)
    last = df.iloc[-1]
    o, h = float(last["open"]), float(last["high"])
    l, c = float(last["low"]), float(last["close"])
    if support and l <= support * 1.005 and c > support and _sweep_rejection_valid(o, h, l, c, "BUY"):
        return "BUY"
    if resistance and h >= resistance * 0.995 and c < resistance and _sweep_rejection_valid(o, h, l, c, "SELL"):
        return "SELL"
    return None


def check_recent_momentum(df: pd.DataFrame, side: str) -> tuple:
    """[بطلب صريح - ملف الإصلاحات المتوازنة] رفض قاطع ضد الدخول العكسي على
    سيولة كاذبة:
      يمنع SELL عندما يكون الزخم صاعداً بقوة
      يمنع BUY  عندما يكون الزخم هابطاً بقوة
    يُرجع (ok: bool, reason: str)."""
    if not CFG.ENABLE_MOMENTUM_FILTER:
        return True, "momentum_filter_disabled"

    lookback = max(2, int(CFG.MOMENTUM_LOOKBACK_CANDLES))
    if df is None or len(df) < lookback + 1:
        return True, "insufficient_data_allow"   # لا نرفض عند نقص بيانات

    recent = df.iloc[-lookback:]
    bullish_count = int((recent["close"] > recent["open"]).sum())
    bearish_count = int((recent["close"] < recent["open"]).sum())
    bullish_ratio = bullish_count / lookback
    bearish_ratio = bearish_count / lookback

    first_close = float(recent["close"].iloc[0])
    last_close = float(recent["close"].iloc[-1])
    if first_close <= 0:
        return True, "invalid_price_allow"

    net_move = (last_close - first_close) / first_close

    if side == "SELL" and bullish_ratio >= CFG.MOMENTUM_MIN_DIRECTION_RATIO and net_move >= CFG.MOMENTUM_MIN_MOVE_PCT:
        return False, (
            f"REJECT_FAKE_SWEEP_MOMENTUM: SELL blocked — "
            f"{bullish_count}/{lookback} bullish, move={net_move*100:.2f}%"
        )

    if side == "BUY" and bearish_ratio >= CFG.MOMENTUM_MIN_DIRECTION_RATIO and net_move <= -CFG.MOMENTUM_MIN_MOVE_PCT:
        return False, (
            f"REJECT_FAKE_SWEEP_MOMENTUM: BUY blocked — "
            f"{bearish_count}/{lookback} bearish, move={net_move*100:.2f}%"
        )

    return True, "momentum_ok"


def _mid_term_trend_conflict(df: pd.DataFrame, side: str, lookback: int = 24) -> tuple:
    """[Glama 6 - إصلاح "دخول عكس الاتجاه" بطلب صريح بعد خسائر متتالية]
    فلتر اتجاه 1H (higher_timeframe_trend) وحده لا يكفي: قد يبقى معنوناً
    BUY تقنياً (أو NEUTRAL بحد أدنى 0.2%) بينما السعر على إطار التنفيذ
    نفسه ما زال في منتصف انهيار متواصل - فتُشترى "ارتدادة قطة ميتة"
    (dead-cat bounce) منتصف الهبوط. هذا يفحص الاتجاه المتوسط على نفس
    إطار التنفيذ (آخر lookback شمعة، افتراضياً 24) عبر ميل EMA قصير - إن
    كان الانحدار/الصعود المتوسط >=2% بعكس اتجاه الإشارة، تُرفض. يُطبَّق
    فقط على المصادر العكسية (sweep/exhaustion_reversal/sr_touch) التي
    تراهن على انعكاس - وليس trend_riding/bos_retest المتوافقين مع
    الاتجاه أصلاً بطبيعتهما. يُرجع (ok: bool, detail: str)."""
    if df is None or len(df) < lookback + 5:
        return True, "insufficient_data_allow"
    window = df["close"].iloc[-lookback:]
    span = max(3, lookback // 4)
    ema_fast = window.ewm(span=span, adjust=False).mean()
    start_val = float(ema_fast.iloc[0])
    if start_val <= 0:
        return True, "invalid_price_allow"
    slope_pct = (float(ema_fast.iloc[-1]) - start_val) / start_val
    if side == "BUY" and slope_pct <= -0.02:
        return False, f"mid_term_still_falling(slope={slope_pct*100:.2f}%)"
    if side == "SELL" and slope_pct >= 0.02:
        return False, f"mid_term_still_rising(slope={slope_pct*100:.2f}%)"
    return True, "mid_term_ok"


def confirm_sweep_reversal(df: pd.DataFrame, side: str, sweep_level: float = None) -> tuple:
    """[بطلب صريح - ملف الإصلاحات المتوازنة] تأكيد بعد Sweep، مسار
    signal_source == "sweep" فقط. لا يكتفي بالفتيل - يشترط شمعة تأكيد بسيطة
    في اتجاه الصفقة. ليس صارماً جداً حتى لا يقتل كل الفرص (عتبة جسم 0.35)."""
    if not CFG.REQUIRE_SWEEP_CONFIRMATION:
        return True, "sweep_confirm_disabled"

    if df is None or len(df) < 2:
        return True, "insufficient_data_allow"

    last = df.iloc[-1]
    prev = df.iloc[-2]
    o, h, l, c = float(last["open"]), float(last["high"]), float(last["low"]), float(last["close"])
    prev_c = float(prev["close"])
    rng = max(h - l, 1e-12)
    body_ratio = abs(c - o) / rng

    if side == "SELL":
        # شمعة هابطة + إغلاق تحت إغلاق السابقة + جسم معقول
        ok = (c < o) and (c < prev_c) and (body_ratio >= 0.35)
        if not ok:
            return False, "sweep_no_bearish_confirm_candle"
        if sweep_level is not None and c >= sweep_level:
            return False, "sweep_close_still_above_level"
    elif side == "BUY":
        ok = (c > o) and (c > prev_c) and (body_ratio >= 0.35)
        if not ok:
            return False, "sweep_no_bullish_confirm_candle"
        if sweep_level is not None and c <= sweep_level:
            return False, "sweep_close_still_below_level"

    return True, "sweep_confirmed"


def check_radar_liquidity(df: pd.DataFrame) -> Optional[str]:
    """رادار تكتيكي (Structure Break Volume Profile) - بطلب صريح من المستخدم.
    يُشغَّل قبل أي تقييم إشارة أخرى، ويرجع سبب الرفض كنص لو رفض الدخول،
    أو None لو السوق نظيف ويمكن المتابعة لتقييم الإشارة.

    الفلتر الأول (سوق ميت/عرضي): يقارن حجم الشمعة الحالية بمتوسط آخر 20
    شمعة - لو الحجم الحالي أقل من RADAR_DEAD_MARKET_VOLUME_RATIO من
    المتوسط، السوق يُصنَّف هادئاً/عرضياً بلا قناعة حقيقية، فيتوقف البوت
    عن الدخول مؤقتاً بدل ملاحقة حركة عشوائية بلا سيولة كافية خلفها.

    الفلتر الثاني (سيولة كاذبة/فخ حيتان): لو حدث كسر هيكل بفتيل طويل
    (يتجاوز RADAR_FAKE_WICK_RATIO من مدى الشمعة كاملاً) لكن بحجم تداول
    ضعيف نسبياً (أقل من RADAR_LOW_VOLUME_NODE_RATIO من المتوسط)، فهذا
    نمط كلاسيكي لفخ سيولة/اصطياد أوامر وقف بلا قناعة سوقية حقيقية خلفه -
    يُرفض الدخول تماماً حمايةً لرأس المال الصغير."""
    if len(df) < 21:
        return None

    last = df.iloc[-1]
    avg_vol = df["volume"].iloc[-21:-1].mean()
    if not np.isfinite(avg_vol) or avg_vol <= 0:
        return None

    current_vol = float(last["volume"])
    vol_ratio = current_vol / avg_vol

    # الفلتر الأول: سوق ميت / عرضي بلا سيولة كافية
    if vol_ratio < CFG.RADAR_DEAD_MARKET_VOLUME_RATIO:
        log_event("info", "radar_rejected", reason="DEAD_MARKET",
                  volume=round(current_vol, 4), avg_volume=round(float(avg_vol), 4),
                  ratio=round(vol_ratio, 3), threshold=CFG.RADAR_DEAD_MARKET_VOLUME_RATIO)
        return "radar_dead_market"

    # الفلتر الثاني: فتيل طويل (اختراق/كسر هيكل) + حجم تداول ضعيف = سيولة كاذبة
    o, h, l, c = float(last["open"]), float(last["high"]), float(last["low"]), float(last["close"])
    candle_range = h - l
    if candle_range > 0:
        upper_wick = h - max(o, c)
        lower_wick = min(o, c) - l
        max_wick_ratio = max(upper_wick, lower_wick) / candle_range
        if max_wick_ratio > CFG.RADAR_FAKE_WICK_RATIO and vol_ratio < CFG.RADAR_LOW_VOLUME_NODE_RATIO:
            log_event("info", "radar_rejected", reason="FAKE_LIQUIDITY_TRAP",
                      wick_ratio=round(max_wick_ratio, 3), volume_ratio=round(vol_ratio, 3),
                      wick_threshold=CFG.RADAR_FAKE_WICK_RATIO, volume_threshold=CFG.RADAR_LOW_VOLUME_NODE_RATIO)
            return "radar_fake_liquidity"

    return None


def kalman_filter_series(prices) -> np.ndarray:
    """مرشح كالمان أحادي البعد (Random-Walk + قياس ضوضائي) بنمط نقي بلا مكتبات.
    يعمل على السعر المُطبَّع (÷ أول سعر) فيصلح لأي عملة مهما كان سعرها - النسخة القديمة
    كانت تستخدم تباينات مطلقة (r=0.01) فتجمد الخط قرب أول سعر على العملات الرخيصة
    مثل 1000SATS. تباين القياس r يُقدَّر من تباين فروق الأسعار، وq = r × KALMAN_Q_OVER_R.
    يُرجع مصفوفة الخط العادل بنفس طول الأسعار."""
    arr = np.asarray(prices, dtype=float)
    arr = arr[np.isfinite(arr)]
    n = len(arr)
    if n < 3 or arr[0] <= 0:
        return arr.copy()
    base = float(arr[0])
    z = arr / base
    d = np.diff(z)
    r = float(np.var(d)) if len(d) > 1 else 0.0
    if not np.isfinite(r) or r < 1e-14:
        r = 1e-14
    q = r * CFG.KALMAN_Q_OVER_R
    x, p = float(z[0]), r
    out = np.empty(n)
    out[0] = x
    for i in range(1, n):
        p_pred = p + q
        k = p_pred / (p_pred + r)
        x = x + k * (float(z[i]) - x)
        p = (1.0 - k) * p_pred
        out[i] = x
    return out * base


def apply_kalman_smoothing(prices: np.ndarray) -> float:
    """آخر قيمة لخط السعر العادل (كالمان). للتوافق مع الاستدعاءات القديمة."""
    series = kalman_filter_series(prices)
    if len(series):
        return float(series[-1])
    return 0.0


def kalman_crash_guard(df: pd.DataFrame, side: str, atr: float) -> Optional[str]:
    """حارس الانهيار: يمنع الدخول العكسي الانتحاري. شراء (BUY) يُرفض لو السعر أسفل الخط
    العادل بأكثر من KALMAN_CRASH_ATR_MULT×ATR والخط نفسه يهبط بأكثر من
    KALMAN_CRASH_SLOPE_ATR_MULT×ATR خلال 5 خطوات (انهيار حقيقي وليس فتيلاً عابراً).
    البيع (SELL) هو النظير العكسي. يُرجع سبب الرفض أو None."""
    if df is None or len(df) < 20 or not atr or atr <= 0:
        return None
    closes = df["close"].iloc[-60:].to_numpy(dtype=float)
    series = kalman_filter_series(closes)
    if len(series) < 8:
        return None
    fair = float(series[-1])
    dev = float(closes[-1]) - fair
    slope = fair - float(series[-6])
    if side == "BUY":
        if (-dev) > CFG.KALMAN_CRASH_ATR_MULT * atr and slope < -CFG.KALMAN_CRASH_SLOPE_ATR_MULT * atr:
            return "kalman_crash_down"
    else:
        if dev > CFG.KALMAN_CRASH_ATR_MULT * atr and slope > CFG.KALMAN_CRASH_SLOPE_ATR_MULT * atr:
            return "kalman_crash_up"
    return None


def calculate_wick_z_score(df: pd.DataFrame, side: str, lookback: int = 30) -> float:
    """Z-Score لطول فتيل الشمعة الأخيرة المغلقة مقارنة بآخر lookback شمعة مغلقة سابقة.
    الفتيل في اتجاه الإشارة: BUY = الفتيل السفلي، SELL = العلوي. الطول كنسبة من
    سعر الإغلاق (مقياس مستقل عن سعر العملة). كلما زاد Z كان الفتيل أندر إحصائياً.
    (مقياس نسبي للندرة، وليس ضماناً لوجود مصيدة سيولة.)"""
    if df is None or len(df) < lookback + 1:
        return 0.0
    window = df.iloc[-(lookback + 1):-1]
    o = window["open"].to_numpy(dtype=float)
    h = window["high"].to_numpy(dtype=float)
    l = window["low"].to_numpy(dtype=float)
    c = window["close"].to_numpy(dtype=float)
    if side == "BUY":
        wicks = np.minimum(o, c) - l
    else:
        wicks = h - np.maximum(o, c)
    wicks = wicks / np.where(c > 0, c, np.nan)
    wicks = wicks[np.isfinite(wicks)]
    if len(wicks) < 10:
        return 0.0
    mean, std = float(np.mean(wicks)), float(np.std(wicks))
    if std <= 1e-12:
        return 0.0
    last = df.iloc[-1]
    lo, lh, ll, lc = float(last["open"]), float(last["high"]), float(last["low"]), float(last["close"])
    if lc <= 0:
        return 0.0
    cur = ((min(lo, lc) - ll) if side == "BUY" else (lh - max(lo, lc))) / lc
    return (cur - mean) / std


def wick_z_for_signal(df: pd.DataFrame, side: str) -> float:
    """Z للشمعة الأخيرة أو السابقة لها (الـSweep قد يُؤكَّد بعد شمعة واحدة) - الأكبر منهما."""
    lb = CFG.WICK_Z_LOOKBACK
    z_now = calculate_wick_z_score(df, side, lb)
    z_prev = calculate_wick_z_score(df.iloc[:-1], side, lb) if len(df) > lb + 2 else 0.0
    return max(z_now, z_prev)


def calculate_rsi(df: pd.DataFrame, length: int = 14) -> float:
    """RSI(14) قياسي (Wilder smoothing) - عامل تأكيد فقط، وليس trigger
    وحيد لأي صفقة (بطلب صريح - بند 8): يُستخدم لاحقاً في detect_signal
    لتجنب الشراء بعد اندفاع صاعد طويل جداً أو البيع بعد هبوط حاد بالفعل،
    وليس كقاعدة "RSI<30=>شراء" أو "RSI>70=>بيع" المباشرة الممنوعة صراحة."""
    if df is None or len(df) < length + 1:
        return 50.0
    close = df["close"]
    delta = close.diff()
    gain = delta.clip(lower=0.0)
    loss = -delta.clip(upper=0.0)
    avg_gain = gain.ewm(alpha=1.0 / length, adjust=False, min_periods=length).mean()
    avg_loss = loss.ewm(alpha=1.0 / length, adjust=False, min_periods=length).mean()
    last_gain = float(avg_gain.iloc[-1]) if np.isfinite(avg_gain.iloc[-1]) else 0.0
    last_loss = float(avg_loss.iloc[-1]) if np.isfinite(avg_loss.iloc[-1]) else 0.0
    if last_loss <= 1e-12:
        return 100.0 if last_gain > 0 else 50.0
    rs = last_gain / last_loss
    rsi = 100.0 - (100.0 / (1.0 + rs))
    return float(rsi) if np.isfinite(rsi) else 50.0


def check_pump_dump_filter(df: pd.DataFrame, atr: float) -> bool:
    """فلتر Pump/Dump (بطلب صريح - بند 9): يمنع الدخول فوراً بعد شمعة
    انفجارية (range > 2.5×ATR + volume spike قوي) - الهدف منع شراء القمة
    أو بيع القاع مباشرة بعد اندفاع حاد بلا أي retest/تهدئة. يُرجع True لو
    يجب حظر الدخول الآن."""
    if df is None or len(df) < 21 or not atr or atr <= 0:
        return False
    last = df.iloc[-1]
    candle_range = float(last["high"]) - float(last["low"])
    if candle_range <= 0:
        return False
    avg_vol = df["volume"].iloc[-21:-1].mean()
    if not np.isfinite(avg_vol) or avg_vol <= 0:
        return False
    volume_spike_ratio = float(last["volume"]) / avg_vol
    range_atr_ratio = candle_range / atr

    if range_atr_ratio > CFG.PUMP_DUMP_RANGE_ATR_MULT and volume_spike_ratio > CFG.PUMP_DUMP_VOLUME_SPIKE_RATIO:
        log_event("info", "signal_rejected", reason="REJECT_PUMP_DUMP_CANDLE", reason_detail="explosive_candle_needs_retest",
                  range_atr_ratio=round(range_atr_ratio, 2), volume_spike_ratio=round(volume_spike_ratio, 2),
                  threshold_range=CFG.PUMP_DUMP_RANGE_ATR_MULT, threshold_volume=CFG.PUMP_DUMP_VOLUME_SPIKE_RATIO)
        return True
    return False


def classify_atr_regime(df: pd.DataFrame, atr: float) -> str:
    """تصنيف التذبذب (بطلب صريح - بند 11): QUIET/NORMAL/HIGH/EXTREME حسب
    نسبة مئوية لـATR/price مقارنة بآخر ATR_PERCENTILE_LOOKBACK شمعة.
    QUIET غالباً يُرفض (سوق ميت)، EXTREME لا يُدخل مباشرة (يُخفَّض risk
    ويُمنع رفع leverage - راجع استخدامها في open_trade)."""
    if df is None or atr is None or atr <= 0 or len(df) < 30:
        return "NORMAL"
    lookback = min(CFG.ATR_PERCENTILE_LOOKBACK, len(df) - 1)
    highs, lows, closes = df["high"].iloc[-lookback:], df["low"].iloc[-lookback:], df["close"].iloc[-lookback:]
    prev_close = closes.shift(1)
    tr = pd.concat([highs - lows, (highs - prev_close).abs(), (lows - prev_close).abs()], axis=1).max(axis=1)
    atr_series = (tr.rolling(14).mean() / closes).dropna()
    if len(atr_series) < 10:
        return "NORMAL"
    current_atr_pct = atr / float(closes.iloc[-1])
    percentile = float((atr_series < current_atr_pct).mean() * 100)
    if percentile >= CFG.ATR_REGIME_EXTREME_PCTL:
        return "EXTREME"
    if percentile >= CFG.ATR_REGIME_HIGH_PCTL:
        return "HIGH"
    if percentile <= CFG.ATR_REGIME_QUIET_PCTL:
        return "QUIET"
    return "NORMAL"


def ai_variance_check(prices: np.ndarray, volume_ratio: float) -> bool:
    """فلتر حماية بسيط وصادق (بطلب المستخدم - نُفِّذ حرفياً كما كُتب،
    بلا أي تضخيم تسويقي): يحسب متوسط العائدات على آخر 5 شموع؛ لو الزخم
    حاد جداً (>1.5%) مع انفجار حجم حقيقي (>2x المتوسط)، هذا على الأرجح
    اتجاه عنيف حقيقي (breakout) وليس مصيدة سيولة قابلة للارتداد - فيمنع
    الدخول عكسه حمايةً للحساب. يُرجع False = امنع الدخول، True = آمن."""
    if prices is None or len(prices) < 2:
        return True
    returns = np.diff(prices) / prices[:-1]
    momentum = np.mean(returns)
    if abs(momentum) > 0.015 and volume_ratio > 2.0:
        return False
    return True


def _detect_exhaustion_reversal(df: pd.DataFrame, atr_now: float) -> Optional[str]:
    """[Glama 5 - ميزة جديدة بطلب صريح: "اصطياد القمة ليبيع والقاع ليشتري"]
    مصدر إشارة مستقل عن sweep (الذي يعتمد على نقطة تأرجح هيكلية محدَّدة) -
    هذا يكتشف انعكاس استنزاف (Exhaustion Reversal) عند تمدد إحصائي حقيقي
    للسعر ككل، بصرف النظر عن الهيكل: يشترط تراكم دليلين على الأقل من ثلاثة
    أدلة تمدد مستقلة معاً (خروج فعلي عن نطاق بولينجر + RSI في تشبع أعمق من
    العتبة العادية بـ5 نقاط + انحراف >=2.2 ATR عن EMA20)، بالإضافة لشمعة
    انعكاس تأكيدية حقيقية (فتيل رفض قوي بعكس اتجاه التمدد Z>=1.2 + انقلاب
    فعلي في اتجاه إغلاق الشمعة الأخيرة) - يمنع الدخول على مجرد "السعر
    مرتفع/منخفض" بلا دليل انعكاس فعلي يدعمه (لا يريد شراء سكين ساقطة ولا
    بيع صاروخ صاعد بلا أي إشارة توقف حقيقية)."""
    if len(df) < CFG.BB_LENGTH + 5:
        return None
    close = df["close"]
    bb_pct = compute_bb_percent(df).iloc[-1]
    if not np.isfinite(bb_pct):
        return None
    if atr_now <= 0:
        return None
    rsi_now = calculate_rsi(df, CFG.RSI_LENGTH)
    ema20 = float(close.ewm(span=20, adjust=False).mean().iloc[-1])
    last_close = float(close.iloc[-1])
    ema_dev_atr = (last_close - ema20) / atr_now

    top_evidence = int(bb_pct >= 1.0) + int(rsi_now >= CFG.RSI_OVERBOUGHT + 5) + int(ema_dev_atr >= 2.2)
    bottom_evidence = int(bb_pct <= 0.0) + int(rsi_now <= CFG.RSI_OVERSOLD - 5) + int(ema_dev_atr <= -2.2)

    side = None
    if top_evidence >= 2:
        side = "SELL"
    elif bottom_evidence >= 2:
        side = "BUY"
    if side is None:
        return None

    # شمعة انعكاس تأكيدية إلزامية: بلا دليل رفض حقيقي بالفتيل + انقلاب
    # اتجاه الإغلاق، مجرد "التمدد الإحصائي" وحده غير كافٍ للدخول عكس الاتجاه
    z = wick_z_for_signal(df, side)
    if z < 1.2:
        return None
    last_row = df.iloc[-1]
    bullish_close = float(last_row["close"]) >= float(last_row["open"])
    if side == "SELL" and bullish_close:
        return None
    if side == "BUY" and not bullish_close:
        return None
    return side


def _detect_signal_core(df: pd.DataFrame) -> Optional[tuple]:
    """إشارة دخول قابلة للتنفيذ على رأس مال صغير، مع تقييم جودة أولي.
    الأولوية الأولى: اصطياد سيولة + انعكاس (Liquidity Sweep + Reversal) -
    الاستراتيجية الرئيسية، مكتملة الشروط ومستقلة بذاتها (V6.1). لو فشل
    الـSweep لأي سبب جودة، لا يتحول تلقائياً - يُقيَّم BOS+Retest (تسلسل
    كسر هيكل ← اندفاع ← إعادة اختبار ← رفض حقيقي) بشروطه المستقلة بالكامل.

    يُرجع (الاتجاه, درجة_جزئية 0-1, المصدر) أو None. المصدر "sweep" أو "bos_retest" أو "sr_touch"."""
    if price_jump_blocked(df):
        log_event("info", "رفض: قفزة سعر حادة")
        return None

    radar_rejection = check_radar_liquidity(df)
    if radar_rejection:
        return None

    atr_now = calculate_atr(df, length=14)
    if check_pump_dump_filter(df, atr_now):
        return None
    volatility_regime_local = classify_atr_regime(df, atr_now)
    if volatility_regime_local == "QUIET":
        log_event("info", "signal_rejected", reason="REJECT_QUIET_MARKET", reason_detail="atr_percentile_too_low")
        return None

    rsi_now = calculate_rsi(df, CFG.RSI_LENGTH)

    last = df.iloc[-1]
    if len(df) < 21:
        return None

    # خط كالمان العادل + انحراف السعر الحالي عنه (عامل تأكيد ناعم فقط)
    kalman_line = apply_kalman_smoothing(df["close"].iloc[-40:].to_numpy(dtype=float))
    kalman_deviation_pct = ((float(last["close"]) - kalman_line) / kalman_line) if kalman_line > 0 else 0.0

    def _stat_score_adjustment(side_: str) -> float:
        """تعديل نقاط ناعم (±0.03 إلى ±0.08 كحد أقصى) من كالمان وZ-Score -
        عوامل ترتيب إضافية فقط، لا تفتح ولا ترفض صفقة بمفردها أبداً."""
        adj = 0.0
        if side_ == "BUY" and kalman_deviation_pct < -0.01:
            adj += 0.03   # شراء والسعر تحت الخط العادل = يراهن على عودة منطقية
        elif side_ == "SELL" and kalman_deviation_pct > 0.01:
            adj += 0.03
        elif side_ == "BUY" and kalman_deviation_pct > 0.02:
            adj -= 0.03   # شراء والسعر أصلاً بعيد فوق الخط العادل = مطاردة سعر
        elif side_ == "SELL" and kalman_deviation_pct < -0.02:
            adj -= 0.03
        z = calculate_wick_z_score(df, side_)
        if z > 2.0:
            adj += 0.05   # فتيل نادر إحصائياً في اتجاه الإشارة
        elif z > 1.0:
            adj += 0.02
        return adj

    avg_vol = df["volume"].iloc[-20:-1].mean()
    if not np.isfinite(avg_vol) or avg_vol <= 0:
        return None

    volume_ratio = float(last["volume"] / avg_vol)

    # --- [Trend Riding + نظام هيرست] ---
    # موضعه: بعد فلاتر الحماية (قفزة السعر/Pump-Dump/الرادار/السوق الهامد) وقبل ai_variance_check
    # (الذي يرفض الزخم العنيف لأنه مصمَّم للدخول العكسي). الاتجاه الأقوى مع الحجم لا يُرفض هنا.
    if CFG.ENABLE_TREND_RIDING:
        closes_array = df["close"].iloc[-CFG.HURST_LOOKBACK:].to_numpy(dtype=float)
        hurst_val = calculate_hurst_exponent(closes_array)
        if hurst_val > 0.55 and volume_ratio >= CFG.TREND_RIDING_MIN_VOLUME_RATIO and len(df) >= 5:
            recent_closes = df["close"].iloc[-5:].to_numpy(dtype=float)
            momentum = (recent_closes[-1] - recent_closes[0]) / recent_closes[0] if recent_closes[0] > 0 else 0.0
            # [Glama 5 - إصلاح "شراء القمة/بيع القاع" بطلب صريح] ركوب
            # الاتجاه كان يفتح صفقة بمجرد زخم قوي خلال 5 شموع، بلا أي فحص
            # لمدى ابتعاد السعر أصلاً عن متوسطه - وهذا بالضبط تعريف "شراء
            # حركة انفجارية بعد ما نضجت فعلاً" (chasing) على عملات صغيرة
            # متقلبة: كثيراً ما تكون تلك اللحظة نفسها قريبة من قمة/قاع
            # الحركة قبل الارتداد، وليست بدايتها. الآن نتحقق أن السعر لم
            # يبتعد أصلاً أكثر من CFG.TREND_RIDING_MAX_EXTENSION_ATR وحدة
            # ATR عن EMA20 بنفس اتجاه الصفقة - لو كان بعيداً هذا القدر،
            # الحركة "ناضجة" إحصائياً بالفعل ونترك exhaustion_reversal
            # يتولاها كفرصة انعكاس بدل ركوب الاتجاه يلاحقها متأخراً.
            atr_for_extension = calculate_atr(df, length=14)
            ext_ok = True
            if atr_for_extension > 0:
                ema20_tr = float(df["close"].ewm(span=20, adjust=False).mean().iloc[-1])
                dev_atr = (float(recent_closes[-1]) - ema20_tr) / atr_for_extension
                if momentum >= CFG.TREND_RIDING_MOMENTUM_MIN and dev_atr >= CFG.TREND_RIDING_MAX_EXTENSION_ATR:
                    ext_ok = False
                    log_event("info", "signal_rejected", reason="REJECT_TREND_RIDING_OVEREXTENDED",
                              reason_detail="momentum_strong_but_already_far_from_ema_chasing_a_top",
                              side="BUY", deviation_atr=round(dev_atr, 2))
                elif momentum <= -CFG.TREND_RIDING_MOMENTUM_MIN and dev_atr <= -CFG.TREND_RIDING_MAX_EXTENSION_ATR:
                    ext_ok = False
                    log_event("info", "signal_rejected", reason="REJECT_TREND_RIDING_OVEREXTENDED",
                              reason_detail="momentum_strong_but_already_far_from_ema_chasing_a_bottom",
                              side="SELL", deviation_atr=round(dev_atr, 2))
            if ext_ok and momentum >= CFG.TREND_RIDING_MOMENTUM_MIN:
                diag = {"volume_ratio": volume_ratio, "hurst": round(hurst_val, 2), "mode": "TREND_RIDING"}
                log_event("info", "ركوب الاتجاه العنيف: رصد زخم صاعد حاد", hurst=round(hurst_val, 2),
                          move=round(momentum * 100, 2))
                return ("BUY", 0.85, "trend_riding", diag)
            elif ext_ok and momentum <= -CFG.TREND_RIDING_MOMENTUM_MIN:
                diag = {"volume_ratio": volume_ratio, "hurst": round(hurst_val, 2), "mode": "TREND_RIDING"}
                log_event("info", "ركوب الاتجاه العنيف: رصد زخم هابط حاد", hurst=round(hurst_val, 2),
                          move=round(momentum * 100, 2))
                return ("SELL", 0.85, "trend_riding", diag)
    # السوق ارتدادي (H <= 0.55) أو لا زخم كافٍ (أو ناضج جداً وتُرك لـexhaustion_reversal): يكمل المنطق الأصلي (Sweep / BOS-Retest / SR) بلا تغيير.

    # فلتر حماية الزخم العنيف (ai_variance_check) - بطلب المستخدم، منفّذ
    # حرفياً كما كُتب: يميّز بين "مصيدة سيولة قابلة للارتداد" و"اتجاه عنيف
    # حقيقي (breakout)" لا يجوز الدخول عكسه. آخر 5 شموع إغلاق.
    if len(df) >= 6:
        recent_closes = df["close"].iloc[-6:].to_numpy(dtype=float)
        if not ai_variance_check(recent_closes, volume_ratio):
            log_event("info", "signal_rejected", reason="REJECT_VIOLENT_MOMENTUM",
                      reason_detail="ai_variance_check: momentum>1.5% مع حجم>2x - اتجاه عنيف حقيقي، ليس مصيدة",
                      volume_ratio=round(volume_ratio, 3))
            return None

    # مستويات الحجم المتدرّجة (بدل رفض/قبول ثنائي فقط):
    # <1.0 = رفض حاسم | 1.0-1.1 = ضعيف (عقوبة ناعمة، لا يمنع) | >=1.1 = صالح
    # >=1.3 = مكافأة تأكيد | >=1.5 = مكافأة إضافية صغيرة
    if volume_ratio < 0.85:
        log_event("info", "signal_rejected", reason="REJECT_LOW_VOLUME", reason_detail="volume_too_low",
                  volume=float(last["volume"]), avg_volume=float(avg_vol), ratio=round(volume_ratio, 3))
        return None
    elif volume_ratio < CFG.MIN_VOLUME_RATIO:
        volume_score = 0.02
    elif volume_ratio < 1.3:
        volume_score = 0.10
    elif volume_ratio < 1.5:
        volume_score = 0.16
    else:
        volume_score = 0.20

    amb_is_bull = bool(compute_amb_trend(df).iloc[-1])
    bb_pct = compute_bb_percent(df).iloc[-1]
    if not np.isfinite(bb_pct):
        bb_pct = 0.5

    live_delta = float(last.get("taker_buy_base", 0) or 0) - float(last.get("taker_sell_base", 0) or 0)
    delta_score = min(abs(live_delta) / (avg_vol * 0.5), 1.0) * 0.2 if avg_vol > 0 else 0.0

    def _confirm_and_score(side: str) -> Optional[float]:
        """يتحقق من الدلتا + AMB + BB لهذا الاتجاه. AMB/BB يُرفضان إلزامياً
        إذا REQUIRE_*=True (بطلب صريح). الدلتا المعاكسة بقوة تُرفض صراحة
        (وليس عقوبة نقاط فقط) - "بقوة" = 10%+ من حجم الشمعة الأخيرة."""
        last_vol = float(last["volume"])
        strong_delta_against = (
            (side == "BUY" and live_delta < 0 and last_vol > 0 and abs(live_delta) >= last_vol * 0.10) or
            (side == "SELL" and live_delta > 0 and last_vol > 0 and abs(live_delta) >= last_vol * 0.10)
        )
        if strong_delta_against:
            log_event("info", "signal_rejected", reason="REJECT_DELTA_CONFLICT", reason_detail="strong_delta_against_direction", side=side,
                      delta=round(live_delta, 4), candle_vol=round(last_vol, 4),
                      delta_pct_of_volume=round(abs(live_delta) / last_vol * 100, 2) if last_vol > 0 else None)
            return None
        score = volume_score + delta_score
        if side == "BUY" and live_delta < 0:
            score -= 0.06
        if side == "SELL" and live_delta > 0:
            score -= 0.06
        # [مُعدَّل بطلب صريح] AMB/BB لم يعودا رفضاً قاطعاً - نقاط ترتيب فقط
        # (توحيداً مع Sweep) - REQUIRE_* يبقى المفتاح الذي يُفعِّل/يُعطِّل
        # تأثيرهما على الدرجة، وليس بوابة رفض بعد الآن.
        if CFG.REQUIRE_AMB_CONFIRMATION:
            score += 0.06 if amb_is_bull == (side == "BUY") else -0.08
        # RSI كعامل تأكيد فقط (بند 8) - لا "RSI<30=>شراء" ولا "RSI>70=>بيع"
        # مباشرة. تجنّب فقط الشراء بعد اندفاع صاعد قوي جداً، أو البيع بعد
        # هبوط حاد أصلاً بلا رفض/استعادة مؤكدة (والإشارة هنا أصلاً وصلت من
        # كسر هيكل/سيولة مؤكد، فهذا عقوبة نقاط إضافية فقط وليس رفضاً قاطعاً).
        if side == "BUY" and rsi_now >= CFG.RSI_OVERBOUGHT:
            score -= 0.06
        elif side == "SELL" and rsi_now <= CFG.RSI_OVERSOLD:
            score -= 0.06
        score += _stat_score_adjustment(side)
        if side == "BUY":
            if CFG.REQUIRE_BB_CONFIRMATION and bb_pct > CFG.BB_MIN_PCT + 0.15:
                score -= 0.08
            bb_depth = min(max(CFG.BB_MIN_PCT - bb_pct, 0.0) / CFG.BB_MIN_PCT, 1.0) * 0.2 if CFG.BB_MIN_PCT > 0 else 0.0
        else:
            if CFG.REQUIRE_BB_CONFIRMATION and bb_pct < CFG.BB_MAX_PCT - 0.15:
                score -= 0.08
            bb_depth = min(max(bb_pct - CFG.BB_MAX_PCT, 0.0) / max(1.0 - CFG.BB_MAX_PCT, 0.001), 1.0) * 0.2
        return max(score + bb_depth, 0.02)

    # === الأولوية 1: اصطياد سيولة + انعكاس (الاستراتيجية الرئيسية) ===
    # [إصلاح حرج] الدالة تتحقق داخلياً من: كسر+إغلاق، حجم>=1.3x، دلتا،
    # رفض رياضي، **وAMB/BB الإلزاميان الآن أيضاً** (كانا يُتجاوَزان تماماً
    # هنا سابقاً رغم REQUIRE_*=True - كانا يُطبَّقان فقط على BOS/Retest/SR).
    sweep_result = detect_liquidity_sweep(df, lookback=20, amb_is_bull=amb_is_bull, bb_pct=bb_pct)
    if sweep_result:
        sweep_side, atr_bonus = sweep_result
        score = min(volume_score + delta_score + atr_bonus, 1.0)
        # نفس عقوبة تأكيد RSI المطبَّقة على المسارات الأخرى - عامل ترتيب فقط
        if sweep_side == "BUY" and rsi_now >= CFG.RSI_OVERBOUGHT:
            score = max(score - 0.06, 0.02)
        elif sweep_side == "SELL" and rsi_now <= CFG.RSI_OVERSOLD:
            score = max(score - 0.06, 0.02)
        score = max(min(score + _stat_score_adjustment(sweep_side), 1.0), 0.02)
        log_event("info", "إشارة اصطياد سيولة", side=sweep_side, close=float(last["close"]),
                  delta=round(live_delta, 4), atr_bonus=round(atr_bonus, 3), partial_score=round(score, 3), rsi=round(rsi_now, 1))
        diag = {"volume_ratio": round(volume_ratio, 4), "amb_direction": "BUY" if amb_is_bull else "SELL",
                "bb_percent": round(bb_pct, 4), "delta": round(live_delta, 4), "rsi": round(rsi_now, 1),
                "atr": round(atr_now, 6), "volatility_regime": volatility_regime_local}
        return (sweep_side, score, "sweep", diag)

    # === الأولوية 1.5: انعكاس استنزاف عند قمة/قاع إحصائي (Exhaustion Reversal) ===
    # [Glama 5 - ميزة جديدة بطلب صريح] مستقل تماماً عن sweep - لا يشترط نقطة
    # تأرجح هيكلية، بل تمدداً إحصائياً حقيقياً (بولينجر+RSI+انحراف ATR عن
    # EMA20) مع شمعة انعكاس تأكيدية. هذا هو المصدر المخصَّص فعلياً لـ"اصطياد
    # القمة ليبيع والقاع ليشتري" - بشروط رفض حقيقية، وليس مجرد ملامسة سعر.
    exhaustion_side = _detect_exhaustion_reversal(df, atr_now)
    if exhaustion_side:
        score = _confirm_and_score(exhaustion_side)
        if score is not None:
            # مكافأة جودة: تراكم أدلة تمدد مستقلة + رفض مؤكد بالفتيل = إعداد أعلى من المتوسط
            score = min(score + 0.10, 1.0)
            log_event("info", "إشارة انعكاس استنزاف عند قمة/قاع إحصائي", side=exhaustion_side,
                      close=float(last["close"]), bb_pct=round(bb_pct, 3), rsi=round(rsi_now, 1),
                      partial_score=round(score, 3))
            diag = {"volume_ratio": round(volume_ratio, 4), "amb_direction": "BUY" if amb_is_bull else "SELL",
                    "bb_percent": round(bb_pct, 4), "delta": round(live_delta, 4),
                    "rsi": round(rsi_now, 1), "atr": round(atr_now, 6), "volatility_regime": volatility_regime_local}
            return (exhaustion_side, score, "exhaustion_reversal", diag)

    # === الأولوية 2: BOS + Retest (طبقة ثانوية مستقلة تماماً) ===
    # فشل الـSweep لا يتحول تلقائياً لهذا المسار - يُقيَّم بشروطه المستقلة
    # بالكامل (تسلسل BOS←Displacement←Retest←رفض حقيقي، وليس مجرد ملامسة)
    bos_side = detect_bos_retest(df, lookback=CFG.SWING_LOOKBACK * 4)
    if bos_side:
        score = _confirm_and_score(bos_side)
        if score is not None:
            log_event("info", "إشارة BOS+Retest", side=bos_side, close=float(last["close"]),
                      delta=round(live_delta, 4), bb_pct=round(bb_pct, 3), amb_bull=amb_is_bull,
                      partial_score=round(score, 3))
            diag = {"volume_ratio": round(volume_ratio, 4), "amb_direction": "BUY" if amb_is_bull else "SELL",
                    "bb_percent": round(bb_pct, 4), "delta": round(live_delta, 4),
                    "rsi": round(rsi_now, 1), "atr": round(atr_now, 6), "volatility_regime": volatility_regime_local}
            return (bos_side, score, "bos_retest", diag)

    sr_side = detect_sr_touch(df)
    if sr_side:
        score = _confirm_and_score(sr_side)
        if score is not None:
            log_event("info", "إشارة ملامسة دعم/مقاومة", side=sr_side, close=float(last["close"]),
                      delta=round(live_delta, 4), bb_pct=round(bb_pct, 3), amb_bull=amb_is_bull,
                      partial_score=round(score, 3))
            diag = {"volume_ratio": round(volume_ratio, 4), "amb_direction": "BUY" if amb_is_bull else "SELL",
                    "bb_percent": round(bb_pct, 4), "delta": round(live_delta, 4),
                    "rsi": round(rsi_now, 1), "atr": round(atr_now, 6), "volatility_regime": volatility_regime_local}
            return (sr_side, max(score * 0.92, 0.02), "sr_touch", diag)

    return None



def calculate_hurst_exponent(prices: np.ndarray) -> float:
    """أُس هيرست لتصنيف نظام السوق: H < 0.45 ارتدادي (مناسب للـSweep) ، H > 0.55 اتجاهي.
    يُقاس بميل log(std فروق لوغاريتم السعر عند الإزاحة lag) على log(lag) - الميل نفسه = H.
    (النسخة الأصلية كانت تُرجع 0.5 دائماً: polyfit يُرجع مصفوفة فيفشل np.isfinite داخل if
    ويُمسَك الاستثناء، كما أنها كانت تطبّق std على فروق العوائد فلا يظهر أي تدرّج مع lag.)"""
    try:
        arr = np.asarray(prices, dtype=float)
        arr = arr[np.isfinite(arr) & (arr > 0)]
        if len(arr) < 30:
            return 0.5
        logp = np.log(arr)
        lags = np.arange(2, min(20, len(logp) // 2))
        if len(lags) < 3:
            return 0.5
        tau = np.array([np.std(logp[lag:] - logp[:-lag]) for lag in lags], dtype=float)
        mask = np.isfinite(tau) & (tau > 0)
        if int(mask.sum()) < 3:
            return 0.5
        slope = float(np.polyfit(np.log(lags[mask]), np.log(tau[mask]), 1)[0])
        if not np.isfinite(slope):
            return 0.5
        return float(np.clip(slope, 0.0, 1.0))
    except Exception:
        return 0.5


_LAST_MARKET_SCAN_TIME = 0.0
_DYNAMIC_SYMBOL_CACHE = ()


def _scanner_opportunity_score(quote_volume: float, abs_change_pct: float, max_volume: float) -> float:
    """[Glama 4 - بند 3/5 من تقرير التطوير الهجومي] Opportunity Score يمزج
    السيولة (رتبة نسبية بين المرشحين) مع قوة حركة 24 ساعة - لكن بدل
    ملاحقة أعلى |تغيّر| خام (قد يكون pump/dump خالص على سيولة ضعيفة)،
    الحركة المعتدلة-إلى-القوية (2%-12%) تُكافأ بأقصى وزن، بينما الحركات
    المتطرفة جداً (>12%، على الأرجح استنزفت نفسها فعلاً أو فخ سيولة)
    تُخفَّض أولويتها تدريجياً بدل استبعادها بالكامل (قد تعطي ركوب اتجاه
    حقيقي لاحقاً عبر trend_riding، لكن لا تتصدر القائمة لمجرد ضخامتها)."""
    liquidity_score = min(quote_volume / max_volume, 1.0) if max_volume > 0 else 0.0
    if abs_change_pct <= 2.0:
        move_score = abs_change_pct / 2.0 * 0.5          # حركة خفيفة جداً - أولوية منخفضة (قد تكون سوق هامد)
    elif abs_change_pct <= 12.0:
        move_score = 0.5 + (abs_change_pct - 2.0) / 10.0 * 0.5   # المنطقة المفضّلة: 2%-12%
    else:
        # فوق 12%: تراجع تدريجي (ليس صفراً) - يبقى مرشحاً لكن بأولوية أقل
        move_score = max(1.0 - (abs_change_pct - 12.0) / 30.0, 0.15)
    return liquidity_score * 0.45 + move_score * 0.55


def update_dynamic_active_symbols(client: Client) -> tuple:
    """ماسح السوق: أعلى MAX_SCANNER_SYMBOLS عملة USDT حسب Opportunity Score
    (سيولة + قوة حركة معتدلة-إلى-قوية، وليس أعلى |تغيّر 24س| خام فقط) -
    بسيولة >= MIN_24H_QUOTE_VOLUME_USDT. يُحدَّث كل ساعة. عند الفشل يُرجع
    آخر نتيجة ناجحة، وإلا العملات المرشحة الافتراضية."""
    global _LAST_MARKET_SCAN_TIME, _DYNAMIC_SYMBOL_CACHE
    now = time.time()
    if _DYNAMIC_SYMBOL_CACHE and (now - _LAST_MARKET_SCAN_TIME < 3600.0):
        return _DYNAMIC_SYMBOL_CACHE
    try:
        tickers = with_retry(client.futures_ticker, description="scanner_fetch_tickers")
        df_t = pd.DataFrame(tickers)
        df_t = df_t[df_t["symbol"].astype(str).str.endswith("USDT")].copy()
        df_t["quoteVolume"] = pd.to_numeric(df_t["quoteVolume"], errors="coerce")
        df_t["priceChangePercent"] = pd.to_numeric(df_t["priceChangePercent"], errors="coerce").abs()
        df_t = df_t.dropna(subset=["quoteVolume", "priceChangePercent"])
        df_t = df_t[df_t["quoteVolume"] >= CFG.MIN_24H_QUOTE_VOLUME_USDT]
        if len(df_t):
            max_vol = float(df_t["quoteVolume"].max())
            df_t["opportunity_score"] = df_t.apply(
                lambda r: _scanner_opportunity_score(float(r["quoteVolume"]), float(r["priceChangePercent"]), max_vol),
                axis=1,
            )
            df_t = df_t.sort_values(by="opportunity_score", ascending=False)
        top_symbols = df_t["symbol"].head(CFG.MAX_SCANNER_SYMBOLS).tolist()
        if top_symbols:
            merged = list(top_symbols)
            if CFG.SCANNER_ALWAYS_INCLUDE_CANDIDATES:
                merged = list(dict.fromkeys(list(CFG.CANDIDATE_SYMBOLS) + top_symbols))
            _DYNAMIC_SYMBOL_CACHE = tuple(merged)
            _LAST_MARKET_SCAN_TIME = now
            log_event("info", "الماسح الديناميكي: تم تحديث قائمة العملات (Opportunity Score)", top_coins=top_symbols,
                      scanned_total=len(merged))
            return _DYNAMIC_SYMBOL_CACHE
    except Exception as e:
        log_event("warning", "فشل تحديث الماسح الديناميكي - استخدام آخر نتيجة/المرشحين الافتراضيين", msg=str(e))
    return _DYNAMIC_SYMBOL_CACHE or tuple(CFG.CANDIDATE_SYMBOLS)


def _wick_z_score_adjustment(z: float) -> float:
    """[Glama 4 - بند 2/6] تحويل Wick Z-Score من بوابة ثنائية إلى مكافأة/
    عقوبة نقاط متدرّجة: فتيل نادر إحصائياً (Z مرتفع) = مكافأة قوية، فتيل
    متوسط = محايد تقريباً، فتيل ضعيف جداً (لكن فوق الأرضية الصلبة) = عقوبة
    خفيفة (وليس رفضاً قاطعاً - بقية أدلة الإشارة قد تعوّضه)."""
    if z >= CFG.WICK_Z_MIN:
        return 0.08
    if z >= 1.0:
        return 0.03
    if z >= CFG.WICK_Z_HARD_FLOOR:
        return -0.03
    return -0.10  # لن يُصادَف عملياً لأن ما دون الأرضية يُرفض قبل الوصول هنا


def classify_market_regime(df: pd.DataFrame, atr: float) -> str:
    """[إصلاح - بطلب صريح من تقرير مراجعة مخصَّص لمشكلة "الدخول عكس
    الاتجاه"] يُصنّف نظام السوق الحالي من 4 مؤشرات مستقلة (محاذاة EMA20/50،
    ميل EMA20 بوحدات ATR خلال آخر 30 شمعة، أُس هيرست، وأغلبية شموع آخر 15)
    إلى TRENDING_UP / TRENDING_DOWN / RANGING / CHOPPY. هذا تصنيف مستقل عن
    _mid_term_trend_conflict الموجود مسبقاً (الذي يرفض/يقبل إشارة واحدة)
    - الغرض هنا تصنيف حالة السوق نفسها لاستخدامها كبوابة عامة قبل قبول أي
    مصدر إشارة انعكاسي أصلاً (انظر _is_source_allowed_in_regime)."""
    if df is None or len(df) < 60 or atr <= 0:
        return "CHOPPY"  # بيانات غير كافية = لا تداول
    closes = df["close"]
    last_close = float(closes.iloc[-1])
    if last_close <= 0:
        return "CHOPPY"

    ema20 = float(closes.ewm(span=20, adjust=False).mean().iloc[-1])
    ema50 = float(closes.ewm(span=50, adjust=False).mean().iloc[-1])
    ema_aligned_up = ema20 > ema50 and last_close > ema20
    ema_aligned_down = ema20 < ema50 and last_close < ema20

    window = closes.iloc[-30:]
    ema_win = window.ewm(span=20, adjust=False).mean()
    ema_slope_atr = (float(ema_win.iloc[-1]) - float(ema_win.iloc[0])) / atr

    hurst = calculate_hurst_exponent(closes.iloc[-100:].to_numpy(dtype=float))

    recent_15 = df.iloc[-15:]
    up_count = int((recent_15["close"] > recent_15["open"]).sum())
    down_count = int((recent_15["close"] < recent_15["open"]).sum())

    trending_up_score = sum([
        ema_aligned_up,
        ema_slope_atr > 1.5,
        hurst > 0.55,
        up_count >= 10,
    ])
    trending_down_score = sum([
        ema_aligned_down,
        ema_slope_atr < -1.5,
        hurst > 0.55,
        down_count >= 10,
    ])

    if trending_up_score >= 3:
        return "TRENDING_UP"
    if trending_down_score >= 3:
        return "TRENDING_DOWN"

    ema_gap_pct = abs(ema20 - ema50) / last_close
    if hurst < 0.45 and ema_gap_pct < 0.005:
        return "RANGING"
    return "CHOPPY"


def _is_source_allowed_in_regime(source: str, side: str, regime: str) -> tuple:
    """قائمة بيضاء صريحة (مصدر × نظام سوق) - تمنع المصادر الانعكاسية من
    الدخول ضد اتجاه قوي بلا داعٍ. [ملاحظة صريحة بطلب المستخدم] هذا تصنيف
    CHOPPY صارم فعلاً - لو لاحظت البوت توقف عن التداول كلياً، هذا أول مكان
    يُشتبه فيه (راجع /trendstats لتوزيع الأنظمة الفعلي خلال اليوم)."""
    if regime == "CHOPPY":
        return False, "regime_choppy_no_trade"

    if regime == "TRENDING_UP":
        if side == "SELL":
            if source == "exhaustion_reversal":
                return True, "exhaustion_against_strong_uptrend_needs_full_evidence"
            return False, f"block_{source}_against_strong_uptrend"
        if source in ("trend_riding", "bos_retest", "sweep", "sr_touch"):
            return True, "trend_aligned_or_reversal_buy_in_uptrend_ok"
        return False, f"unknown_source_{source}"

    if regime == "TRENDING_DOWN":
        if side == "BUY":
            if source == "exhaustion_reversal":
                return True, "exhaustion_against_strong_downtrend_needs_full_evidence"
            return False, f"block_{source}_against_strong_downtrend"
        if source in ("trend_riding", "bos_retest", "sweep", "sr_touch"):
            return True, "trend_aligned_or_reversal_sell_in_downtrend_ok"
        return False, f"unknown_source_{source}"

    if regime == "RANGING":
        if source == "trend_riding":
            return False, "trend_riding_blocked_in_ranging"
        if source in ("sweep", "exhaustion_reversal", "sr_touch", "bos_retest"):
            return True, "reversal_ok_in_ranging"
        return False, f"unknown_source_{source}"

    return False, "unknown_regime"


def detect_signal(df: pd.DataFrame) -> Optional[tuple]:
    """البوابة العامة للإشارات: المنطق الأصلي + بوابة إلزامية واحدة صلبة
    (حارس انهيار كالمان). [Glama 4] Wick Z-Score لم يعد رفضاً قاطعاً عند
    Z<=2.0 (كان يقتل إشارات متوسطة الجودة كثيرة) - الرفض القاطع الوحيد
    المتبقي هو فتيل شبه معدوم (Z < WICK_Z_HARD_FLOOR)؛ فوق ذلك، Z يُضاف
    كمكافأة/عقوبة نقاط ضمن الدرجة النهائية (_wick_z_score_adjustment)."""
    result = _detect_signal_core(df)
    if not result:
        return None
    side, score, source, diag = result
    _record_signal_side(side)  # [بند 30] عداد خام قبل أي رفض - انظر تعريف الدالة
    atr = calculate_atr(df, length=14)

    # [إصلاح - المشكلة المُبلَّغ عنها صراحة: "البوت يدخل عكس اتجاه"] بوابة
    # نظام السوق: تُطبَّق على المصدر النهائي الذي فاز (سواء sweep/sr_touch/
    # bos_retest/trend_riding/exhaustion_reversal) بدل تعديل كل دالة كشف
    # على حدة - نقطة تحقق مركزية واحدة أكثر أماناً من تفريق المنطق. يُسجَّل
    # نظام السوق بالتشخيص دائماً حتى لو سُمحت الإشارة.
    market_regime = classify_market_regime(df, atr)
    diag["market_regime"] = market_regime
    regime_ok, regime_reason = _is_source_allowed_in_regime(source, side, market_regime)
    if not regime_ok:
        log_event("info", "signal_rejected", reason="REJECT_COUNTERTREND_REGIME", reason_detail=regime_reason,
                  side=side, signal_source=source, market_regime=market_regime)
        return None

    if CFG.KALMAN_CRASH_GUARD:
        reason = kalman_crash_guard(df, side, atr)
        if reason:
            log_event("info", "signal_rejected", reason="REJECT_KALMAN_CRASH", reason_detail=reason,
                      side=side, signal_source=source)
            return None
    z = wick_z_for_signal(df, side)
    diag["wick_z"] = round(float(z), 3)
    if CFG.WICK_Z_REQUIRED and source not in CFG.WICK_Z_EXEMPT_SOURCES and z < CFG.WICK_Z_HARD_FLOOR:
        log_event("info", "signal_rejected", reason="REJECT_WICK_Z_LOW",
                  reason_detail="wick_essentially_absent", side=side, signal_source=source,
                  wick_z=round(float(z), 3), hard_floor=CFG.WICK_Z_HARD_FLOOR)
        return None
    if source not in CFG.WICK_Z_EXEMPT_SOURCES:
        wick_adj = _wick_z_score_adjustment(z)
        diag["wick_z_score_adj"] = round(wick_adj, 3)
        score = max(min(score + wick_adj, 1.0), 0.02)
    return (side, score, source, diag)


# ==============================================================================
# 9) تنفيذ الصفقات (عمولة/انزلاق، دقة، بدون تعارض أوامر)
# ==============================================================================

def net_target_pct(target_pct: float) -> float:
    """يضيف تكلفة العمولة (دخول + خروج) والانزلاق إلى النسبة المطلوبة
    كي يكون الربح الصافي الفعلي مطابقاً للهدف بعد خصم التكاليف."""
    cost = (CFG.TAKER_FEE_RATE * 2) + CFG.SLIPPAGE_BUFFER_PCT
    return target_pct + cost


def _place_entry_order(client: Client, filters: SymbolFilters, entry_side: str, close_side: str,
                        qty: float, ref_price: float, symbol: str = None) -> Optional[dict]:
    """يفتح المركز إما بأمر MARKET مباشر (الافتراضي)، أو بأمر LIMIT قريب من
    السعر الحالي لتقليل الانزلاق - مع إلغاء تلقائي وتحويل لأمر سوق لو ما
    تنفّذ خلال مهلة قصيرة."""
    symbol = symbol or CFG.SYMBOL
    if not CFG.USE_LIMIT_ENTRY:
        return create_order_idempotent(client, "open_market_order", symbol=symbol, side=entry_side,
                                        type=ORDER_TYPE_MARKET, quantity=qty)

    buf = CFG.LIMIT_ENTRY_SLIPPAGE_BUFFER_PCT
    limit_price = filters.round_price(ref_price * (1 + buf) if entry_side == SIDE_BUY else ref_price * (1 - buf))

    order = create_order_idempotent(client, "open_limit_order", symbol=symbol, side=entry_side,
                                     type=ORDER_TYPE_LIMIT, price=limit_price, quantity=qty,
                                     timeInForce=TIME_IN_FORCE_GTC)

    start = time.time()
    refreshed = order
    while time.time() - start < CFG.LIMIT_ENTRY_TIMEOUT_SEC:
        refreshed = with_retry(client.futures_get_order, symbol=symbol, orderId=order["orderId"],
                                description="poll_limit_entry")
        if refreshed.get("status") == "FILLED":
            return refreshed
        time.sleep(1)

    log_event("warning", "أمر LIMIT للدخول لم يُنفَّذ (كلياً) خلال المهلة - إلغاء والتحقق من التنفيذ الجزئي",
              limit_price=limit_price, timeout_sec=CFG.LIMIT_ENTRY_TIMEOUT_SEC, symbol=symbol)
    try:
        with_retry(client.futures_cancel_order, symbol=symbol, orderId=order["orderId"],
                   description="cancel_unfilled_limit_entry")
    except BinanceAPIException as e:
        if e.code != -2011:
            log_event("warning", "فشل إلغاء أمر LIMIT المعلّق", msg=str(e))

    final_status = with_retry(client.futures_get_order, symbol=symbol, orderId=order["orderId"],
                               description="final_check_limit_entry")
    if final_status.get("status") == "FILLED":
        return final_status

    filled_qty = float(final_status.get("executedQty", 0) or 0)
    remaining_qty = filters.round_qty(qty - filled_qty)

    if remaining_qty <= 0:
        return final_status

    if filled_qty <= 0:
        return create_order_idempotent(client, "fallback_market_entry_full", symbol=symbol,
                                        side=entry_side, type=ORDER_TYPE_MARKET, quantity=qty)

    log_event("warning", "أمر LIMIT نُفّذ جزئياً - إكمال الكمية المتبقية فقط بأمر سوق",
              filled_qty=filled_qty, remaining_qty=remaining_qty, symbol=symbol)
    market_fill = create_order_idempotent(client, "fallback_market_entry_partial", symbol=symbol,
                                           side=entry_side, type=ORDER_TYPE_MARKET, quantity=remaining_qty)

    limit_avg = float(final_status.get("avgPrice", 0) or 0)
    market_qty, market_avg = _confirm_entry_fill(client, market_fill, fallback_price=ref_price, symbol=symbol)
    if market_qty <= 0:
        # [إصلاح حرِج - تحقق مطابق من تقرير مراجعة ثالث، لكن بحل أدق] كان
        # الكود سابقاً يفترض market_qty = remaining_qty (تنفيذاً كاملاً لم
        # يتأكد فعلياً) - قد يُسجّل كمية أكبر من الحقيقية محلياً. لكن
        # إرجاع None هنا (كما اقتُرح) خطير بنفس القدر: فيلد الحماية جزء
        # LIMIT الذي نُفّذ فعلاً (filled_qty > 0 مؤكَّد أعلاه) بلا SL/TP
        # إطلاقاً. الحل الصحيح: نسأل المنصة نفسها عن المركز الحي الفعلي -
        # مصدر الحقيقة الوحيد - بدل افتراض أي رقم أو التخلي عن الحماية.
        live_now = get_live_position(client, symbol=symbol)
        if live_now and live_now.get("qty", 0) > 0:
            total_qty = filters.round_qty(live_now["qty"])
            combined_avg = live_now.get("entry_price") or limit_avg or ref_price
            log_event("warning", "تعذر تأكيد تنفيذ أمر السوق المكمِّل - استُخدم المركز الحي الفعلي من "
                      "المنصة مباشرة بدل الافتراض", symbol=symbol, live_qty=total_qty, live_avg=combined_avg)
            return {**market_fill, "avgPrice": str(combined_avg), "executedQty": str(total_qty)}
        # حتى المركز الحي غير مؤكَّد - آخر ما نملكه فعلياً هو الجزء الذي
        # نفّذته LIMIT وحده (مؤكَّد سابقاً)، فهذا أضمن رقم نسجّله محلياً -
        # يضمن الحماية على الأقل لما نُفّذ فعلاً، بدل تسجيل كمية وهمية أكبر.
        log_event("error", "[ALERT] تعذر تأكيد أمر السوق المكمِّل حتى من المركز الحي - "
                  "سيُسجَّل فقط الجزء المؤكَّد من LIMIT، تحقق يدوياً من Binance",
                  symbol=symbol, limit_filled_qty=filled_qty)
        return {**final_status, "avgPrice": str(limit_avg), "executedQty": str(filled_qty)}
    total_qty = filled_qty + market_qty
    combined_avg = ((limit_avg * filled_qty) + (market_avg * market_qty)) / total_qty if total_qty > 0 else ref_price

    return {**market_fill, "avgPrice": str(combined_avg), "executedQty": str(total_qty)}


def live_win_rate() -> tuple:
    """نسبة الفوز الحية من جدول الإحصاءات المحلي، ممزوجة بافتراض أولي (Bayesian)
    كي لا تتقلب كثيراً بعد صفقات قليلة. يُرجع (p, عدد_الصفقات, الرابحة)."""
    try:
        wins, n = STORE.get_strategy_win_stats()
    except Exception:
        wins, n = 0, 0
    k = max(int(CFG.KELLY_PRIOR_WEIGHT), 0)
    p = (wins + CFG.KELLY_PRIOR_WIN_RATE * k) / (n + k) if (n + k) > 0 else CFG.KELLY_PRIOR_WIN_RATE
    return float(p), int(n), int(wins)


def get_dollar_targets(equity: float) -> dict:
    """أهداف الدولار: وقف MAX_LOSS_USDT وهدف صافٍ NET_TARGET_USDT، مُحجَّمان بنمو مركب
    (equity/CAPITAL_USDT). بعد صفقة خاسرة يُقرَّب هدف الربح بنسبة RECOVERY_TP_REDUCTION_PCT."""
    scale = 1.0
    if CFG.COMPOUND_DOLLAR_TARGETS and CFG.CAPITAL_USDT > 0 and equity > 0:
        scale = min(max(equity / CFG.CAPITAL_USDT, CFG.TARGET_SCALE_MIN), CFG.TARGET_SCALE_MAX)
    loss = CFG.MAX_LOSS_USDT * scale
    net = CFG.NET_TARGET_USDT * scale
    recovery = False
    try:
        recovery = STORE.last_trade_was_loss()
    except Exception:
        recovery = False
    if recovery:
        net *= (1.0 - CFG.RECOVERY_TP_REDUCTION_PCT)
    return {"loss_usdt": loss, "net_target_usdt": net, "recovery": recovery, "scale": scale}


def calculate_position_size(filters: SymbolFilters, equity: float, available_balance: float,
                             entry_price: float, effective_stop_loss_pct: float,
                             leverage: int = None, risk_pct_override: float = None) -> dict:
    """المصدر الوحيد لحساب حجم الصفقة + مسافتي SL/TP (Glama 2).

    1) الأهداف بالدولار: خسارة L = MAX_LOSS_USDT ، ربح صافٍ T = NET_TARGET_USDT (مُحجَّمة بالنمو المركب)
       ب) نسبة الفوز الحية p ← كيلي الكامل f* = p - (1-p)/b ، حيث b = T/L
       ج) المخاطرة بالدولار = min(L ، Equity×max(f*×KELLY_FRACTION ، الحد الأدنى) ، Equity×MAX_RISK ، override)
    2) الحجم: N = المخاطرة ÷ (SL السوقي + تكلفة الرحلة) ، بسقف الهامش MAX_MARGIN_PCT×الرصيد المتاح×الرافعة.
       لو الحجم اضطُر للتقييد بالسقف يتّسع الوقف ليبقى الخسارة = المخاطرة بالضبط (لا تتجاوز أبداً).
    3) TP = b×(SL+تكلفة)+تكلفة ← الربح الصافي = b × الخسارة الفعلية (0.60$ مقابل 0.40$ في الحالة الطبيعية)
    يُرجع dict (valid, qty, notional, margin_used, sl_pct, tp_pct, min_rr, ...)."""
    lev = min(int(leverage or CFG.LEVERAGE), CFG.MAX_ALLOWED_LEVERAGE)
    if entry_price <= 0 or effective_stop_loss_pct <= 0 or equity <= 0 or available_balance <= 0:
        return {"valid": False, "reason": "REJECT_INVALID_SIZING_INPUT", "qty": 0.0}

    cost = (CFG.TAKER_FEE_RATE * 2.0) + CFG.SLIPPAGE_BUFFER_PCT
    tg = get_dollar_targets(equity)
    loss_t, net_t = tg["loss_usdt"], tg["net_target_usdt"]
    b = net_t / loss_t if loss_t > 0 else 0.0
    if b <= 0:
        return {"valid": False, "reason": "REJECT_INVALID_DOLLAR_TARGETS", "qty": 0.0}

    p, n_trades, wins = live_win_rate()
    kelly_full = p - (1.0 - p) / b
    kelly_frac = max(kelly_full, 0.0) * CFG.KELLY_FRACTION
    kelly_risk_pct = max(kelly_frac, CFG.KELLY_MIN_RISK_PCT_EQUITY)
    cap_pct = CFG.MAX_RISK_PER_TRADE_EQUITY_PCT
    if risk_pct_override is not None:
        cap_pct = min(cap_pct, risk_pct_override)
    risk_usdt = min(loss_t, equity * kelly_risk_pct, equity * cap_pct)
    if risk_usdt <= 0:
        return {"valid": False, "reason": "REJECT_INVALID_SIZING_INPUT", "qty": 0.0}

    margin_cap = available_balance * CFG.MAX_MARGIN_PCT
    notional_cap = margin_cap * lev
    notional_risk = risk_usdt / (effective_stop_loss_pct + cost)
    notional = min(notional_risk, notional_cap)

    qty = filters.clamp_qty(notional / entry_price, entry_price, respect_min_notional=False)
    if qty <= 0:
        return {"valid": False, "reason": "REJECT_QTY_ROUNDED_TO_ZERO", "qty": 0.0}
    actual_notional = qty * entry_price

    if actual_notional + max(entry_price * 1e-12, 1e-12) < filters.min_notional:
        if filters.min_notional / lev > margin_cap:
            log_event("info", "signal_rejected", reason="REJECT_ACCOUNT_TOO_SMALL_FOR_RISK_MODEL",
                      reason_detail="min_notional_exceeds_margin_cap", min_notional=filters.min_notional,
                      max_allowed_margin=round(margin_cap, 6))
            return {"valid": False, "reason": "REJECT_ACCOUNT_TOO_SMALL_FOR_RISK_MODEL", "qty": 0.0}
        qty = filters.clamp_qty(filters.min_notional / entry_price * 1.001, entry_price, respect_min_notional=True)
        if qty <= 0:
            return {"valid": False, "reason": "REJECT_MIN_NOTIONAL", "qty": 0.0}
        actual_notional = qty * entry_price

    actual_margin = actual_notional / lev
    if actual_margin > margin_cap * 1.0005:
        log_event("info", "signal_rejected", reason="REJECT_ACCOUNT_TOO_SMALL_FOR_RISK_MODEL",
                  reason_detail="margin_over_cap_after_rounding", margin=round(actual_margin, 6),
                  max_allowed_margin=round(margin_cap, 6))
        return {"valid": False, "reason": "REJECT_ACCOUNT_TOO_SMALL_FOR_RISK_MODEL", "qty": 0.0}

    # الوقف النهائي: لا يقل عن الوقف السوقي (structure/ATR)، ويتّسع لو الحجم قُيِّد بالسقف
    sl_pct = max(effective_stop_loss_pct, risk_usdt / actual_notional - cost)
    if sl_pct > CFG.MAX_STOP_LOSS_PCT:
        log_event("info", "signal_rejected", reason="REJECT_STOP_TOO_WIDE", reason_detail="dollar_stop_exceeds_cap",
                  sl_pct=round(sl_pct, 5), max_allowed=CFG.MAX_STOP_LOSS_PCT, notional=round(actual_notional, 4))
        return {"valid": False, "reason": "REJECT_STOP_TOO_WIDE", "qty": 0.0}
    loss_est = actual_notional * (sl_pct + cost)
    if loss_est > equity * CFG.MAX_RISK_PER_TRADE_EQUITY_PCT * 1.0005:
        log_event("info", "signal_rejected", reason="REJECT_ACCOUNT_TOO_SMALL_FOR_RISK_MODEL",
                  reason_detail="min_notional_forces_risk_above_cap", loss_est=round(loss_est, 4),
                  cap=round(equity * CFG.MAX_RISK_PER_TRADE_EQUITY_PCT, 4))
        return {"valid": False, "reason": "REJECT_ACCOUNT_TOO_SMALL_FOR_RISK_MODEL", "qty": 0.0}

    tp_pct = b * (sl_pct + cost) + cost
    net_gain_est = actual_notional * (tp_pct - cost)
    min_rr = CFG.MIN_RISK_REWARD_RATIO
    if tg["recovery"]:
        min_rr = min(min_rr, CFG.RECOVERY_MIN_RR)

    log_event("info", "حجم الصفقة: كيلي جزئي + أهداف دولار (calculate_position_size)",
              equity=round(equity, 4), available_balance=round(available_balance, 4),
              win_rate=round(p, 4), trades=n_trades, kelly_full=round(kelly_full, 4),
              kelly_risk_pct=round(kelly_risk_pct, 4), risk_usdt=round(risk_usdt, 4),
              target_scale=round(tg["scale"], 3), recovery_mode=tg["recovery"],
              leverage=lev, qty=qty, margin_used=round(actual_margin, 4), notional=round(actual_notional, 4),
              sl_pct=round(sl_pct * 100, 4), tp_pct=round(tp_pct * 100, 4),
              est_loss_usdt=round(loss_est, 4), est_net_gain_usdt=round(net_gain_est, 4))

    return {"valid": True, "qty": qty, "margin_used": actual_margin, "notional": actual_notional,
            "leverage": lev, "risk_usdt_estimated": loss_est, "reason": None,
            "sl_pct": sl_pct, "tp_pct": tp_pct, "min_rr": min_rr,
            "net_gain_usdt_estimated": net_gain_est, "recovery": tg["recovery"]}


def calculate_atr(df: pd.DataFrame, length: int = 14) -> float:
    """متوسط المدى الحقيقي (ATR) - يقيس التقلب الفعلي لكل عملة على حدة،
    ليُستخدم في تحديد مسافة وقف الخسارة/جني الربح ديناميكياً بدل نسبة
    ثابتة تفترض نفس مستوى التقلب لكل العملات بالتساوي."""
    if df is None or len(df) < length + 1:
        return 0.0
    high, low, close = df["high"], df["low"], df["close"]
    prev_close = close.shift(1)
    tr = pd.concat([high - low, (high - prev_close).abs(), (low - prev_close).abs()], axis=1).max(axis=1)
    atr = tr.rolling(length).mean().iloc[-1]
    return float(atr) if np.isfinite(atr) and atr > 0 else 0.0


_HTF_TREND_CACHE: dict = {}
_HTF_TREND_CACHE_TTL_SEC = 300  # 5 دقائق - اتجاه الساعة لا يتغيّر معناه خلال هذي المدة القصيرة


def higher_timeframe_trend(client: Client, symbol: str) -> Optional[str]:
    """فلتر اتجاه إلزامي من الإطار الأعلى (CFG.HTF_TIMEFRAME) عبر EMA20/EMA50.
    [إصلاح بند 4 من المواصفة] كانت هذي الدالة تستخدم "1h" مثبَّتاً بالكود
    بينما CFG.HTF_TIMEFRAME = "30m" - أي أن Telegram/الإعدادات كانت تعرض
    30m بينما الفحص الفعلي 1H. الآن تُستخدم CFG.HTF_TIMEFRAME فعلياً:
    30m تعني 30m، و1h تعني 1h، و4h تعني 4h - لا فرق بين المُعلَن والمُنفَّذ.
    القواعد:
    - EMA20 > EMA50 → "BUY" (لا يُسمح إلا بإشارات BUY).
    - EMA20 < EMA50 → "SELL" (لا يُسمح إلا بإشارات SELL).
    - الفرق بين EMA20 وEMA50 أقل من 0.2% من السعر → "NEUTRAL" (تُرفض
      الإشارة في الحالتين - لا اتجاه واضح يكفي للسماح بأي جهة).
    - فشل API/بيانات غير كافية → يُرجع None، والمُستدعي هو من يقرر الرفض
      حسب FAIL_CLOSED_MARKET_CHECKS (وليس هذي الدالة).
    مُخزَّن مؤقتاً 300 ثانية لكل (رمز، فريم) - مفتاح الكاش يتضمن الفريم
    نفسه حتى لا يُعاد استخدام نتيجة فريم سابق لو تغيّر CFG.HTF_TIMEFRAME
    بين نسخة وأخرى من قاعدة بيانات محفوظة."""
    htf_tf = CFG.HTF_TIMEFRAME
    cache_key = f"{symbol}:{htf_tf}"
    cached = _HTF_TREND_CACHE.get(cache_key)
    if cached and (time.time() - cached[0]) < _HTF_TREND_CACHE_TTL_SEC:
        return cached[1]

    try:
        klines = with_retry(client.futures_klines, symbol=symbol, interval=htf_tf, limit=60,
                             description=f"htf_trend_{symbol}_{htf_tf}")
        if not klines or len(klines) < 51:
            return None  # بيانات غير كافية - فشل، وليس NEUTRAL
        closes = pd.Series([float(k[4]) for k in klines])
        ema20 = closes.ewm(span=20, adjust=False).mean().iloc[-1]
        ema50 = closes.ewm(span=50, adjust=False).mean().iloc[-1]
        last_price = float(closes.iloc[-1])
        if not (np.isfinite(ema20) and np.isfinite(ema50) and last_price > 0):
            return None  # بيانات غير صالحة لحظياً - فشل، لا نكاش شيئاً

        diff_pct = abs(ema20 - ema50) / last_price
        if diff_pct < 0.002:  # أقل من 0.2% من السعر = اتجاه غير واضح فعلياً
            result = "NEUTRAL"
        elif ema20 > ema50:
            result = "BUY"
        else:
            result = "SELL"

        _HTF_TREND_CACHE[cache_key] = (time.time(), result)
        return result
    except Exception as e:
        log_event("warning", f"تعذر جلب اتجاه الإطار الأعلى ({htf_tf})", symbol=symbol, msg=str(e))
        return None  # فشل API - لا نكاش الفشل، نحاول من جديد بالدورة القادمة مباشرة


def calculate_dynamic_stop_pct(df: pd.DataFrame, side: str, entry_price: float, atr: float) -> Optional[float]:
    """SL ديناميكي = max(مسافة هيكلية حقيقية إلى أقرب دعم/مقاومة, ATR*0.8)
    بحد أقصى مطلق MAX_STOP_LOSS_PCT (بطلب صريح - بند 14/15 من ملف
    المواصفات): SL قريب جداً يُضرب بضجيج طبيعي، وSL بلا سقف يفتح لخسارة
    غير محدودة. يُرجع None لو المسافة المطلوبة تتجاوز السقف (الصفقة تُرفض)."""
    if entry_price <= 0:
        return None
    try:
        support, resistance = find_support_resistance(df, CFG.SWING_LOOKBACK)
    except Exception:
        support, resistance = None, None

    atr_pct = (atr * 0.8 / entry_price) if (atr and atr > 0) else 0.0
    structural_pct = 0.0
    if side == "BUY" and support:
        structural_pct = max((entry_price - support) / entry_price, 0.0)
    elif side == "SELL" and resistance:
        structural_pct = max((resistance - entry_price) / entry_price, 0.0)

    stop_pct = max(structural_pct, atr_pct)
    if stop_pct <= 0:
        stop_pct = CFG.FIXED_STOP_LOSS_PCT  # احتياطي لو تعذّر حساب أي من الاثنين (بيانات غير كافية)
    if stop_pct > CFG.MAX_STOP_LOSS_PCT:
        log_event("info", "signal_rejected", reason="REJECT_STOP_TOO_WIDE", reason_detail="dynamic_stop_exceeds_cap",
                  side=side, structural_pct=round(structural_pct, 5), atr_pct=round(atr_pct, 5),
                  stop_pct=round(stop_pct, 5), max_allowed=CFG.MAX_STOP_LOSS_PCT)
        return None
    return stop_pct


def calculate_protection_prices(
    entry_price: float,
    side: str,
    sl_distance_pct: float,
    tp_distance_pct: float,
    min_rr: float,
    fee_rate: float,
    slippage_buffer_pct: float,
) -> dict:
    """حساب موحّد للحماية مع مصدر واحد صريح لجميع المدخلات.
    لا توجد CFG defaults في signature.
    """
    if entry_price <= 0 or sl_distance_pct <= 0 or tp_distance_pct <= 0:
        return {"sl_price": 0.0, "tp_price": 0.0, "gross_rr": 0.0, "net_rr": 0.0, "valid": False}

    if side == SIDE_BUY:
        sl_price = entry_price * (1.0 - sl_distance_pct)
        tp_price = entry_price * (1.0 + tp_distance_pct)
    else:
        sl_price = entry_price * (1.0 + sl_distance_pct)
        tp_price = entry_price * (1.0 - tp_distance_pct)

    sl_distance = abs(entry_price - sl_price)
    tp_distance = abs(tp_price - entry_price)
    gross_rr = tp_distance / sl_distance if sl_distance > 0 else 0.0

    total_cost_pct = (fee_rate * 2.0) + slippage_buffer_pct
    net_tp_distance = max(tp_distance - (entry_price * total_cost_pct), 0.0)
    net_rr = net_tp_distance / sl_distance if sl_distance > 0 else 0.0

    return {
        "sl_price": sl_price,
        "tp_price": tp_price,
        "gross_rr": gross_rr,
        "net_rr": net_rr,
        "valid": gross_rr >= min_rr and net_rr >= min_rr,
    }


def _verify_protective_order(client: Client, symbol: str, order_id: int, expected_type: str,
                              expected_side: str, expected_stop_price: float = None, tolerance_ticks: int = 1) -> bool:
    """يتحقق فعلياً من حالة أمر حماية (SL أو TP) على المنصة بعد إنشائه -
    لا يكتفي البوت باستجابة create_order وحدها كدليل نجاح كافٍ (قد تكون
    الاستجابة غير محدَّثة أو الأمر رُفض لاحقاً/فوراً من طرف Binance)."""
    try:
        order = with_retry(client.futures_get_order, symbol=symbol, orderId=order_id,
                            description="verify_protective_order")
    except Exception as e:
        log_event("error", "تعذر التحقق من أمر الحماية بعد إنشائه", order_id=order_id, symbol=symbol, msg=str(e))
        return False
    if not order or order.get("status") in ("CANCELED", "REJECTED", "EXPIRED"):
        log_event("error", "أمر الحماية غير موجود فعلياً أو أُلغي/رُفض عند التحقق المستقل",
                  order_id=order_id, symbol=symbol, status=order.get("status") if order else None)
        return False
    if order.get("type") != expected_type or order.get("side") != expected_side:
        log_event("error", "أمر الحماية له type/side غير متوقَّع عند التحقق المستقل", order_id=order_id,
                  symbol=symbol, actual_type=order.get("type"), actual_side=order.get("side"),
                  expected_type=expected_type, expected_side=expected_side)
        return False
    if not is_own_order(order):
        log_event("error", "أمر الحماية لا يحمل بادئة هذه النسخة من البوت (clientOrderId)",
                  order_id=order_id, symbol=symbol)
        return False
    if expected_stop_price is not None:
        actual_stop = float(order.get("stopPrice", 0) or 0)
        if actual_stop <= 0:
            return False
        # Caller already rounded expected_stop_price to the symbol tick. A tiny absolute
        # tolerance avoids false negatives from float serialization.
        if abs(actual_stop - expected_stop_price) > max(abs(expected_stop_price) * 1e-9, 1e-12):
            log_event("error", "سعر أمر الحماية لا يطابق السعر المطلوب", order_id=order_id,
                      symbol=symbol, actual_stop=actual_stop, expected_stop=expected_stop_price)
            return False
    if expected_type in (ORDER_TYPE_STOP_MARKET, ORDER_TYPE_TAKE_PROFIT_MARKET):
        if order.get("closePosition") not in (True, "true", "True"):
            log_event("error", "أمر الحماية لا يحمل closePosition=true", order_id=order_id, symbol=symbol)
            return False
    return True


def _emergency_close_unprotected_position(client: Client, symbol: str, close_side: str, reason: str):
    """إجراء طوارئ موحّد لحالة "مركز حقيقي بلا SL".
    [ملاحظة تحقق - بطلب صريح من تقرير مراجعة ثالث] هذي الدالة **غير
    مُستدعاة فعلياً من أي مكان بالملف حالياً** (كود ميت). تحققت من السبب:
    manage_trailing_stop لا يحتاجها فعلياً لأنها تتبع نمط create-verify-
    cancel بصرامة (تُبقي SL القديم فعّالاً دائماً حتى يُتحقَّق من الجديد
    بنجاح، ولا تُلغيه إلا بعدها) - فلا تصل الصفقة عملياً لحالة "بلا SL
    إطلاقاً" عبر هذا المسار. أُبقيها كما هي (بلا حذف أو ربط قسري بمسار لا
    يحتاجها فعلياً) تحوطاً لأي استخدام مستقبلي مقصود، لا لأنها تعمل الآن."""
    try:
        emergency = get_live_position(client, symbol=symbol)
        if emergency:
            create_order_idempotent(
                client, f"emergency_close_{reason}", symbol=symbol, side=close_side,
                type=ORDER_TYPE_MARKET, quantity=emergency["qty"], reduceOnly=True,
            )
        STORE.clear_open_position(symbol)
        notify_telegram(f"[ALERT] {symbol}: فقد الحماية (SL) أثناء الوقف المتحرك ({reason}) - تم إغلاق المركز طارئاً")
    except Exception as close_err:
        log_event("error", "[ALERT][ALERT] فشل الإغلاق الطارئ بعد فقدان SL أثناء الوقف المتحرك",
                  symbol=symbol, reason=reason, msg=str(close_err))
        notify_telegram(f"[ALERT][ALERT] {symbol}: فقد SL وفشل الإغلاق الطارئ - تدخل يدوي فوري!")
        raise FatalBotError(
            f"فقد SL أثناء الوقف المتحرك على {symbol} ({reason}) وفشل الإغلاق الطارئ. أغلق المركز يدوياً فوراً."
        ) from close_err


def open_trade(client: Client, filters: SymbolFilters, side: str, ref_price: float, symbol: str = None,
                df: pd.DataFrame = None, tp_pct_override: float = None, signal_source: str = None,
                volatility_regime: str = "normal", signal_grade: str = "A",
                quality_score: float = None) -> bool:
    """يحاول فتح صفقة جديدة بكل فحوصات الأمان. يُرجع True فقط لو نجح فتح
    المركز فعلياً (أو DRY_RUN)، و False في أي مسار فشل - حتى لو المركز فُتح
    مؤقتاً ثم أُغلق طارئاً بسبب فشل SL. القيمة المُرجعة تحدد هل تُحتسب هذي
    المحاولة ضمن MAX_SIGNALS_PER_SCAN أم لا - محاولة فاشلة يجب ألا تستهلك
    مقعداً كان يمكن أن يذهب لمرشح آخر جيد بنفس دورة الفحص.

    tp_pct_override: [مُهمَل - لم يعد مستخدَماً] SL/TP يُحسبان الآن ديناميكياً
    داخل هذي الدالة (structure/ATR عبر calculate_dynamic_stop_pct) - أُبقي
    البارامتر في التوقيع فقط توافقاً مع نقطة الاستدعاء القديمة في run_bot."""
    symbol = symbol or CFG.SYMBOL
    # حارس ضد "إشارة قديمة" (stale signal): المرشح تم جمعه بمرحلة الفحص
    # الأولى، وقد يفتح مركزاً على نفس الرمز بين ذلك الوقت وتنفيذ هذا
    # الاستدعاء تحديداً (صفقة أخرى بنفس الدورة على نفس الرمز، أو دورة فحص
    # متوازية). إعادة تحقق مباشرة قبل الالتزام بأي API فعلي.
    if STORE.get_open_position(symbol) is not None:
        log_event("info", "signal_rejected", symbol=symbol, side=side, reason="REJECT_DUPLICATE_POSITION", reason_detail="duplicate_position")
        return False
    # available_balance_before: القيمة الخام availableBalance من Binance وقت
    # محاولة فتح هذي الصفقة تحديداً (تُقرأ من جديد في كل استدعاء - لا كاش) -
    # تُستخدم في calculate_position_size أدناه (المصدر الوحيد لحساب الحجم).
    try:
        available_balance_before = get_available_balance(client)
    except Exception:
        available_balance_before = 0.0
    if available_balance_before <= 0:
        log_event("warning", "availableBalance غير متاح أو صفر - منع الدخول", reason="REJECT_INSUFFICIENT_MARGIN", reason_detail="unavailable_balance", symbol=symbol)
        return False
    capital = available_balance_before
    position_number = len(STORE.get_all_open_positions()) + 1
    try:
        equity_for_sizing = get_account_equity(client)
    except Exception:
        equity_for_sizing = available_balance_before  # احتياطي متحفظ لو فشلت القراءة
    if equity_for_sizing <= 0:
        equity_for_sizing = available_balance_before
    # === تقسيم رأس المال على عدد العملات المتداولة بالتوازي (بطلب صريح:
    # "راس مال تقسمه على نصفين") - كل عملة من العملتين تحسب حجمها من
    # نصيبها المخصَّص فقط (equity/2)، وليس من الرصيد الكامل، حتى لو كانت
    # العملة الأخرى مغلقة حالياً بلا مركز - تقسيم ثابت، وليس ديناميكياً
    # حسب عدد المراكز المفتوحة فعلاً في هذي اللحظة.
    split_n = max(int(CFG.CAPITAL_SPLIT_COUNT), 1)
    equity_share = equity_for_sizing / split_n
    available_balance_share = available_balance_before / split_n

    if not get_book_quality(client, ref_price, symbol=symbol):
        return False

    open_orders_count = len(with_retry(client.futures_get_open_orders, symbol=symbol,
                                        description="count_open_orders"))
    if open_orders_count >= filters.max_orders - 2:  # نترك هامش أمان أمرين (SL+TP القادمين)
        log_event("error", "قريب من حد الأوامر المفتوحة المسموح به على هذا الرمز - تخطي الصفقة",
                  reason="exchange_filter_rejection",
                  open_orders=open_orders_count, max_orders=filters.max_orders)
        return False

    # SL/TP ديناميكيان (structure/ATR) بدل نسبة ثابتة صرفة - بحد أقصى
    # MAX_STOP_LOSS_PCT ونسبة مخاطرة:عائد لا تقل عن MIN_RISK_REWARD_RATIO
    # (بطلب صريح - بند 14/15). لا مسار بديل آخر يحسب SL/TP في كل الملف.
    atr_for_stop = calculate_atr(df, length=14) if df is not None else 0.0
    sl_pct = calculate_dynamic_stop_pct(df, side, ref_price, atr_for_stop) if df is not None else None
    if sl_pct is None:
        log_event("info", "entry_blocked", symbol=symbol, reason="REJECT_STOP_TOO_WIDE_OR_UNAVAILABLE")
        return False
    # [Glama 2] الترتيب: (1) الحجم بكيلي الجزئي المركّب ← (2) SL/TP بالدولار من الحجم الفعلي ← (3) تحقق RR.
    # sl_pct هنا = الوقف السوقي (structure/ATR) كحد أدنى فقط؛ الوقف/الهدف النهائيان يخرجان من calculate_position_size.
    recent_losses = 0
    try:
        recent_losses = STORE.recent_consecutive_losses()
    except Exception:
        recent_losses = 0
    # [Glama 4 - بند 13/14 من تقرير التطوير] تدرّج أنعم للخسائر المتتالية
    # بدل قفزة واحدة فقط بعد REDUCED_RISK_AFTER_LOSSES (2): خسارة واحدة =
    # تخفيض بسيط (استمرار البحث بحذر)، خسارتان = تخفيض أكبر (الإعداد
    # الأصلي)، ثلاث = cooldown/circuit breaker (تُدار أصلاً عبر
    # MAX_CONSECUTIVE_LOSSES في check_circuit_breaker قبل الوصول هنا أصلاً).
    risk_override = None
    if volatility_regime == "extreme":
        risk_override = min(CFG.MAX_RISK_PER_TRADE_EQUITY_PCT, 0.02)
    elif recent_losses >= CFG.REDUCED_RISK_AFTER_LOSSES:
        risk_override = CFG.REDUCED_RISK_PCT
    elif recent_losses >= 1:
        risk_override = min(CFG.MAX_RISK_PER_TRADE_EQUITY_PCT, CFG.REDUCED_RISK_PCT * 1.6)

    # [Glama 4 - بند 13] Position sizing واعٍ بدرجة جودة الإشارة: Grade A
    # (أعلى 0.75 فأكثر) يحصل على الحجم الكامل المسموح؛ Grade B (اجتاز
    # العتبة لكن دون 0.75) يُخفَّض قليلاً - جودة أدنى تستحق رأس مال أقل،
    # وليس رفضاً كاملاً (الرفض الكامل يحدث أصلاً قبل الوصول هنا لو كانت
    # الجودة أقل من العتبة الحالية).
    if signal_grade == "B":
        grade_cap = CFG.MAX_RISK_PER_TRADE_EQUITY_PCT * 0.8
        risk_override = min(risk_override, grade_cap) if risk_override is not None else grade_cap

    sizing = calculate_position_size(filters, equity_share, available_balance_share, ref_price,
                                      sl_pct, leverage=CFG.LEVERAGE, risk_pct_override=risk_override)
    if not sizing["valid"]:
        log_event("warning", "حجم الصفقة غير صالح - تخطي هذا الرمز",
                  reason=sizing["reason"], symbol=symbol, side=side,
                  available_balance_before=round(available_balance_before, 4),
                  available_balance_share=round(available_balance_share, 4),
                  equity=round(equity_for_sizing, 4), equity_share=round(equity_share, 4),
                  position_number=position_number)
        return False
    qty = sizing["qty"]
    estimated_notional = qty * ref_price
    sl_market_pct = sl_pct
    sl_pct, tp_pct, min_rr = sizing["sl_pct"], sizing["tp_pct"], sizing["min_rr"]
    log_event("info", "مسافات SL/TP بالدولار", symbol=symbol, sl_market_pct=round(sl_market_pct * 100, 3),
              sl_pct=round(sl_pct * 100, 3), tp_pct=round(tp_pct * 100, 3), atr=round(atr_for_stop, 6),
              est_loss_usdt=round(sizing["risk_usdt_estimated"], 4),
              est_net_gain_usdt=round(sizing["net_gain_usdt_estimated"], 4), recovery_mode=sizing["recovery"])

    protection = calculate_protection_prices(
        entry_price=ref_price,
        side=side,
        sl_distance_pct=sl_pct,
        tp_distance_pct=tp_pct,
        min_rr=min_rr,
        fee_rate=CFG.TAKER_FEE_RATE,
        slippage_buffer_pct=CFG.SLIPPAGE_BUFFER_PCT,
    )
    if not protection["valid"]:
        log_event("info", "entry_blocked", symbol=symbol, reason="rr_invalid",
                  gross_rr=round(protection["gross_rr"], 3), min_required=min_rr)
        return False

    # BUG-02: محاكاة التقريب الفعلي (tick_size) قبل إرسال أمر السوق.
    # لو التقريب يضعف RR تحت الحد الأدنى، نمدّد TP افتراضياً ونتحقق مجدداً.
    # لا نفتح مركزاً حقيقياً ثم نغلقه طارئاً ونخسر رسوم الدخول+الخروج بلا مبرر.
    if side == "BUY":
        pre_sl = filters.round_price(ref_price * (1.0 - sl_pct))
        pre_tp = filters.round_price_up(ref_price * (1.0 + tp_pct))
    else:
        pre_sl = filters.round_price_up(ref_price * (1.0 + sl_pct))
        pre_tp = filters.round_price(ref_price * (1.0 - tp_pct))
    pre_sl_dist = abs(ref_price - pre_sl)
    pre_tp_dist = abs(pre_tp - ref_price)
    pre_cost = (CFG.TAKER_FEE_RATE * 2.0) + CFG.SLIPPAGE_BUFFER_PCT
    pre_net_tp = max(pre_tp_dist - ref_price * pre_cost, 0.0)
    pre_net_rr = pre_net_tp / pre_sl_dist if pre_sl_dist > 0 else 0.0
    if pre_net_rr < min_rr and pre_sl_dist > 0:
        required_net = pre_sl_dist * min_rr + ref_price * pre_cost
        if side == "BUY":
            pre_tp = filters.round_price_up(ref_price + required_net)
        else:
            pre_tp = filters.round_price(ref_price - required_net)
        pre_tp_dist = abs(pre_tp - ref_price)
        pre_net_tp = max(pre_tp_dist - ref_price * pre_cost, 0.0)
        pre_net_rr = pre_net_tp / pre_sl_dist if pre_sl_dist > 0 else 0.0
    pre_ok = (
        pre_sl_dist > 0 and pre_tp_dist > 0 and
        ((pre_sl < ref_price < pre_tp) if side == "BUY" else (pre_tp < ref_price < pre_sl)) and
        pre_net_rr >= min_rr
    )
    if not pre_ok:
        log_event("info", "entry_blocked", symbol=symbol, reason="rr_invalid_after_tick_rounding_precheck",
                  net_rr=round(pre_net_rr, 3), min_required=min_rr,
                  pre_sl=pre_sl, pre_tp=pre_tp)
        return False

    if side == "BUY":
        entry_side, close_side = SIDE_BUY, SIDE_SELL
    else:
        entry_side, close_side = SIDE_SELL, SIDE_BUY

    # ملاحظة: SL/TP النهائيان لا يُحسبان هنا من ref_price - هذا مجرد تقدير
    # لحظة الإشارة. الحساب الفعلي الملزم يتم بعد تأكيد avgPrice الحقيقي
    # من Binance أدناه (بعد _confirm_entry_fill) تحديداً لتفادي أن ينزلق
    # سعر التنفيذ الفعلي عن ref_price ويجعل SL/TP المُنشأين غير متوافقين
    # مع نسب 2.3%/7.7% [تصحيح توثيق] المطلوبة فعلياً من سعر الدخول الحقيقي.
    log_event("info", "فتح صفقة (تقديري قبل تأكيد avgPrice)", side=side, qty=qty, ref_price=ref_price)

    if CFG.DRY_RUN:
        return True

    # Binance is source of truth immediately before entry: prevent a duplicate
    # same-symbol position and enforce the global maximum against live state.
    live_positions_snapshot = with_retry(client.futures_position_information, description="pre_entry_positions")
    live_nonzero = [p for p in live_positions_snapshot if float(p.get("positionAmt", 0) or 0) != 0]
    if any(p.get("symbol") == symbol for p in live_nonzero):
        log_event("info", "signal_rejected", symbol=symbol, side=side, reason="duplicate_position_live")
        return False
    if len(live_nonzero) >= CFG.MAX_OPEN_POSITIONS:
        log_event("info", "signal_rejected", symbol=symbol, side=side, reason="max_positions_live",
                  live_open_positions=len(live_nonzero), max_open_positions=CFG.MAX_OPEN_POSITIONS)
        return False

    leverage_result = with_retry(client.futures_change_leverage, symbol=symbol, leverage=CFG.LEVERAGE,
                                  description="set_leverage")
    actual_leverage = int(leverage_result.get("leverage", 0))
    if actual_leverage != CFG.LEVERAGE:
        log_event("error", "فشل تعيين الرافعة بالقيمة المطلوبة - تخطي الصفقة لتفادي حجم مركز خاطئ",
                  requested=CFG.LEVERAGE, actual=actual_leverage)
        notify_telegram(f"[BLOCKED] تعذر ضبط الرافعة على {CFG.LEVERAGE}x (الفعلي={actual_leverage}x) - تخطي الصفقة")
        return False

    # === حارس "إشارة قديمة" قبل إرسال أمر السوق مباشرة (بند 13) - نعيد
    # قراءة السعر الحالي؛ لو تحرك السعر ضد الدخول أكثر من MAX_ENTRY_DRIFT_PCT
    # منذ لحظة توليد الإشارة، نرفض بدل الدخول بسعر لم تعد الإشارة تصفه فعلياً.
    try:
        fresh_book = with_retry(client.futures_order_book, symbol=symbol, limit=5,
                                 description="pre_entry_drift_check")
        fresh_bid = float(fresh_book["bids"][0][0])
        fresh_ask = float(fresh_book["asks"][0][0])
        fresh_mid = (fresh_bid + fresh_ask) / 2
    except Exception:
        fresh_mid = None
    if fresh_mid and ref_price > 0:
        drift_pct = (fresh_mid - ref_price) / ref_price
        adverse_drift = drift_pct < 0 if side == "BUY" else drift_pct > 0
        if adverse_drift and abs(drift_pct) > CFG.MAX_ENTRY_DRIFT_PCT:
            log_event("info", "signal_rejected", symbol=symbol, side=side, reason="REJECT_STALE_SIGNAL",
                      reason_detail="price_drifted_against_entry_since_signal",
                      signal_price=ref_price, current_price=fresh_mid, drift_pct=round(drift_pct, 5),
                      max_allowed=CFG.MAX_ENTRY_DRIFT_PCT)
            return False

    # [إصلاح - بند 12/13 من "Final Gate" في المواصفة، بطلب صريح]
    # الفحص المبكر بسطر 4311 (STORE.get_open_position) يعتمد فقط على
    # الكاش المحلي (SQLite) - لو ضاع تزامنه مع Binance الحقيقي (بعد Crash
    # لم يُسجَّل فيه مركز سابق محلياً، أو صفقة يدوية على نفس الحساب/الرمز
    # من تطبيق Binance مباشرة)، هذا الفحص المبكر لا يكتشف ذلك، والبوت قد
    # يفتح مركزاً ثانياً متعارضاً فوق مركز حقيقي موجود أصلاً. هذي آخر
    # لحظة ممكنة قبل الالتزام الفعلي برأس المال - نتحقق من حالة Binance
    # الحقيقية مباشرة (وليس الكاش المحلي) قبل إرسال أمر الدخول.
    try:
        existing_live_position = get_live_position(client, symbol=symbol)
    except Exception as e:
        log_event("warning", "تعذر التحقق من حالة Binance الحقيقية قبل الدخول - إلغاء هذي المحاولة تحوطياً",
                  symbol=symbol, msg=str(e))
        return False
    if existing_live_position:
        log_event("error", "[ALERT] مركز حقيقي موجود فعلاً على Binance لهذا الرمز رغم عدم ظهوره بالكاش "
                  "المحلي - إلغاء محاولة الدخول لمنع تعارض/مضاعفة التعرّض، ومزامنة الكاش المحلي فوراً",
                  symbol=symbol, reason="REJECT_UNTRACKED_LIVE_POSITION",
                  live_qty=existing_live_position.get("qty"), live_side=existing_live_position.get("side"))
        notify_telegram(f"[ALERT] {symbol}: مركز حقيقي موجود على Binance ولم يكن مُسجَّلاً محلياً - "
                          "أُلغيت محاولة دخول جديدة لتفادي تعارض. راجع /positions يدوياً.")
        return False

    entry_order = _place_entry_order(client, filters, entry_side, close_side, qty, ref_price, symbol=symbol)
    if entry_order is None:
        log_event("error", "تعذر فتح المركز (أمر الدخول لم يُنفَّذ) - لا صفقة مفتوحة")
        return False
    filled_qty, entry_price = _confirm_entry_fill(client, entry_order, fallback_price=ref_price, symbol=symbol)
    # لا نفترض أبداً أن الطلب نُفّذ لمجرد أن API أعاد استجابة.
    # الحفظ المحلي لا يبدأ إلا بعد وجود تنفيذ فعلي موجب مؤكَّد من نفس المصدر.
    if filled_qty <= 0 or entry_price <= 0:
        log_event("error", "أمر الدخول أعاد استجابة بدون تنفيذ فعلي صالح - لن تُسجّل صفقة محلياً")
        return False

    # حفظ مؤقت فوري بمجرد تأكد الدخول، قبل حتى محاولة وضع SL/TP - لو انقطع
    # البرنامج في اللحظة التالية مباشرة، نعرف على الأقل أن مركزاً مفتوحاً
    # موجوداً محلياً (بدل أن يكتشفه recover_state_on_startup كمركز "غريب"
    # غير محفوظ إطلاقاً ويوقف البوت عن الدخول تحوطاً)
    STORE.save_open_position(symbol, side, filled_qty, entry_price, None, None, None,
                              signal_source=signal_source, quality_score=quality_score)
    STORE.increment_today_opened_count()  # يُحتسب فور فتح المركز فعلياً، مو فقط عند إغلاقه لاحقاً

    # === الحماية النهائية من avgPrice الحقيقي المؤكد ===
    # SL/TP الديناميكيان (structure/ATR) المحسوبان أعلاه قبل التنفيذ - نفس
    # القيم بالضبط، مُعاد تطبيقهما على avgPrice الفعلي بعد التأكد من التنفيذ،
    # ثم تقريب اتجاهي حسب tickSize، ثم إعادة حساب RR من الأسعار الفعلية.
    if side == "BUY":
        sl_price = filters.round_price(entry_price * (1.0 - sl_pct))
        tp_price = filters.round_price_up(entry_price * (1.0 + tp_pct))
    else:
        sl_price = filters.round_price_up(entry_price * (1.0 + sl_pct))
        tp_price = filters.round_price(entry_price * (1.0 - tp_pct))

    # تحقق نهائي من الاتجاه والمسافة وR:R بعد التقريب. إذا أضعف tickSize الـRR،
    # نمدد TP للخارج إلى مسافة تحقق الحد الأدنى بدل الدخول بحماية غير صالحة.
    sl_distance_final = abs(entry_price - sl_price)
    tp_distance_final = abs(tp_price - entry_price)
    total_cost_pct = (CFG.TAKER_FEE_RATE * 2.0) + CFG.SLIPPAGE_BUFFER_PCT
    net_tp_distance_final = max(tp_distance_final - entry_price * total_cost_pct, 0.0)
    gross_rr_final = tp_distance_final / sl_distance_final if sl_distance_final > 0 else 0.0
    net_rr_final = net_tp_distance_final / sl_distance_final if sl_distance_final > 0 else 0.0

    required_net_distance = sl_distance_final * min_rr + entry_price * total_cost_pct
    if net_rr_final < min_rr and side == "BUY":
        tp_price = filters.round_price_up(entry_price + required_net_distance)
        tp_distance_final = abs(tp_price - entry_price)
        net_tp_distance_final = max(tp_distance_final - entry_price * total_cost_pct, 0.0)
        gross_rr_final = tp_distance_final / sl_distance_final if sl_distance_final > 0 else 0.0
        net_rr_final = net_tp_distance_final / sl_distance_final if sl_distance_final > 0 else 0.0
    elif net_rr_final < min_rr and side == "SELL":
        tp_price = filters.round_price(entry_price - required_net_distance)
        tp_distance_final = abs(tp_price - entry_price)
        net_tp_distance_final = max(tp_distance_final - entry_price * total_cost_pct, 0.0)
        gross_rr_final = tp_distance_final / sl_distance_final if sl_distance_final > 0 else 0.0
        net_rr_final = net_tp_distance_final / sl_distance_final if sl_distance_final > 0 else 0.0

    protection_ok = (
        sl_distance_final > 0 and tp_distance_final > 0 and
        ((sl_price < entry_price < tp_price) if side == "BUY" else (tp_price < entry_price < sl_price)) and
        gross_rr_final >= min_rr and
        net_rr_final >= min_rr
    )
    if not protection_ok:
        log_event("error", "[ALERT] حماية غير صالحة بعد إعادة الحساب من avgPrice الحقيقي - إغلاق طارئ فوري",
                  reason="invalid_protection", symbol=symbol, side=side, entry_price=entry_price,
                  sl_price=sl_price, tp_price=tp_price, gross_rr=round(gross_rr_final, 3),
                  net_rr=round(net_rr_final, 3), min_rr=min_rr)
        try:
            emergency = get_live_position(client, symbol=symbol)
            if emergency:
                create_order_idempotent(
                    client, "emergency_close_invalid_protection", symbol=symbol, side=close_side,
                    type=ORDER_TYPE_MARKET, quantity=emergency["qty"], reduceOnly=True,
                )
            STORE.clear_open_position(symbol)
            notify_telegram("[ALERT] حماية غير صالحة بعد التنفيذ الفعلي (avgPrice) - تم إغلاق المركز طارئاً")
        except Exception as close_err:
            log_event("error", "فشل الإغلاق الطارئ بعد حماية غير صالحة - تدخل يدوي فوري مطلوب", msg=str(close_err))
            notify_telegram("[ALERT][ALERT] حماية غير صالحة وفشل الإغلاق الطارئ - المركز قد يكون بلا حماية")
            raise FatalBotError(
                "حماية غير صالحة بعد التنفيذ الفعلي (avgPrice) وفشل الإغلاق الطارئ. أغلق المركز يدوياً فوراً."
            ) from close_err
        return False

    log_event("info", "SL/TP أُعيدا حسابهما من avgPrice الحقيقي", symbol=symbol, side=side,
              entry_price=entry_price, sl=sl_price, tp=tp_price, gross_rr=round(gross_rr_final, 3), net_rr=round(net_rr_final, 3))

    # SL و TP كأمرين منفصلين (Binance Futures ما فيها OCO حقيقي مثل Spot).
    # closePosition=True على الاثنين = كل واحد يغلق كامل المركز بمفرده.
    # لما يتنفذ أحدهما لازم نلغي الثاني يدوياً (يصير في run_bot بعد اكتشاف الإغلاق).
    try:
        sl_order = create_order_idempotent(
            client, "place_stop_loss", symbol=symbol, side=close_side,
            type=ORDER_TYPE_STOP_MARKET, stopPrice=sl_price, closePosition=True,
        )
    except Exception as e:
        err_txt = str(e)
        is_algo_migration_error = ("-4120" in err_txt) or ("Algo Order" in err_txt)
        if is_algo_migration_error:
            log_event("error", "[ALERT] فشل إنشاء SL بسبب ترحيل Binance للأوامر الشرطية إلى Algo Order API "
                      "(اعتباراً من 2025-12-09) - مكتبة python-binance المُثبَّتة على جهازك على الأرجح "
                      "قديمة ولا تدعم إعادة التوجيه التلقائي لهذا النوع من الأوامر. الحل: "
                      "pip install --upgrade python-binance --break-system-packages - محاولة إغلاق طارئ فوراً",
                      msg=err_txt)
        else:
            log_event("error", "فشل إنشاء SL بعد فتح المركز - محاولة إغلاق طارئ فوراً", msg=err_txt)
        try:
            emergency = get_live_position(client, symbol=symbol)
            if emergency:
                create_order_idempotent(
                    client, "emergency_close_no_sl", symbol=symbol, side=close_side,
                    type=ORDER_TYPE_MARKET, quantity=emergency["qty"], reduceOnly=True,
                )
                STORE.clear_open_position(symbol)
                if is_algo_migration_error:
                    notify_telegram("[ALERT] فشل إنشاء SL بسبب ترحيل Binance للأوامر الشرطية (Algo Order API) - "
                                     "حدّث المكتبة: pip install --upgrade python-binance --break-system-packages\n"
                                     "تم إغلاق المركز طارئاً حمايةً لرأس المال.")
                else:
                    notify_telegram("[ALERT] فشل إنشاء SL بعد الدخول - تم إغلاق المركز طارئاً")
                return False
        except Exception as close_err:
            log_event("error", "فشل الإغلاق الطارئ بعد فشل SL - تدخل يدوي فوري مطلوب", msg=str(close_err))
            notify_telegram("[ALERT][ALERT] فشل SL والإغلاق الطارئ - المركز قد يكون بلا حماية")
            raise FatalBotError(
                "فشل إنشاء SL وفشل الإغلاق الطارئ بعد فتح المركز. أغلق المركز يدوياً فوراً."
            ) from close_err
        return False

    # نتحقق من نجاح أمر SL نفسه أيضاً - لو رُفض أو لم يستقر بحالة NEW، لا نترك المركز مكشوفاً.
    if sl_order.get("status") not in (None, "NEW") or sl_order.get("status") == "REJECTED":
        log_event("error", "[ALERT] أمر وقف الخسارة رُفض - إغلاق الصفقة فوراً بأمر سوق للحماية")
        try:
            create_order_idempotent(client, "emergency_close_no_sl", symbol=symbol, side=close_side,
                                     type=ORDER_TYPE_MARKET, quantity=filled_qty, reduceOnly=True)
        except Exception as e:
            log_event("error", "[ALERT][ALERT] فشل الإغلاق الطارئ أيضاً - تدخل يدوي فوري مطلوب!", msg=str(e))
            notify_telegram("[ALERT][ALERT] فشل SL وفشل الإغلاق الطارئ - المركز مفتوح بلا حماية، تدخل يدوي فوري!")
            # هذه أخطر حالة ممكنة بالبوت كله: مركز حقيقي مفتوح بلا أي حماية،
            # وحتى محاولة الإغلاق الطارئ فشلت. الاستمرار بالتداول أو فتح
            # صفقات جديدة بهذا الوضع غير مقبول إطلاقاً - نوقف البوت نهائياً
            raise FatalBotError(
                "فشل SL وفشل الإغلاق الطارئ على التوالي - مركز حقيقي بلا حماية. "
                "أغلق المركز يدوياً من Binance فوراً قبل أي إعادة تشغيل."
            ) from e
        else:
            side_ar = "ش" if side == "BUY" else "ب"
            notify_telegram(f"[ALERT] تحذير: رُفض أمر SL لصفقة {side_ar} - تم إغلاقها فوراً كإجراء طارئ")
            STORE.clear_open_position(symbol)
        return False

    # تحقق مستقل فعلي من وجود SL على المنصة (لا نكتفي بحالة استجابة
    # create_order وحدها - قد تكون غير محدَّثة أو الأمر يُرفض بعد جزء من
    # الثانية من طرف Binance رغم استجابة أولية تبدو ناجحة).
    if not _verify_protective_order(client, symbol, sl_order["orderId"], ORDER_TYPE_STOP_MARKET, close_side, expected_stop_price=sl_price):
        log_event("error", "[ALERT] فشل التحقق المستقل من وجود SL فعلياً - إغلاق طارئ فوري")
        try:
            emergency = get_live_position(client, symbol=symbol)
            if emergency:
                create_order_idempotent(client, "emergency_close_sl_verify_failed", symbol=symbol,
                                         side=close_side, type=ORDER_TYPE_MARKET,
                                         quantity=emergency["qty"], reduceOnly=True)
            STORE.clear_open_position(symbol)
            notify_telegram("[ALERT] فشل التحقق المستقل من SL بعد إنشائه - تم إغلاق المركز طارئاً")
        except Exception as e:
            log_event("error", "[ALERT][ALERT] فشل الإغلاق الطارئ بعد فشل التحقق من SL", msg=str(e))
            notify_telegram("[ALERT][ALERT] فشل التحقق من SL وفشل الإغلاق الطارئ - تدخل يدوي فوري!")
            raise FatalBotError(
                "فشل التحقق المستقل من SL بعد إنشائه وفشل الإغلاق الطارئ. أغلق المركز يدوياً فوراً."
            ) from e
        return False

    try:
        tp_order = create_order_idempotent(
            client, "place_take_profit", symbol=symbol, side=close_side,
            type=ORDER_TYPE_TAKE_PROFIT_MARKET, stopPrice=tp_price, closePosition=True,
        )
    except Exception as e:
        # بعكس فشل SL، فشل TP ليس طارئاً: المركز يبقى محمياً بـ SL أصلاً.
        # لا نرفع الاستثناء (كان بلا أي try/except من قبل - ثغرة حقيقية
        # كانت قادرة على إسقاط حلقة الفحص كلها من صفقة TP واحدة فاشلة).
        err_txt = str(e)
        if "-4120" in err_txt or "Algo Order" in err_txt:
            log_event("error", "فشل إنشاء TP بسبب ترحيل Binance لـAlgo Order API - "
                      "حدّث المكتبة: pip install --upgrade python-binance --break-system-packages. "
                      "الصفقة تستمر بحماية SL فقط", msg=err_txt)
        else:
            log_event("error", "فشل إنشاء TP - الصفقة ستستمر بحماية SL فقط بدون هدف ربح تلقائي", msg=err_txt)
        side_ar = "ش" if side == "BUY" else "ب"
        notify_telegram(f"[WARN] فشل وضع TP لصفقة {side_ar} - يعمل الآن بـ SL فقط، راقبها يدوياً")
        tp_order = {"orderId": None, "status": "REJECTED"}

    tp_order_id, tp_price_saved = tp_order["orderId"], tp_price
    if tp_order.get("status") == "REJECTED":
        # الصفقة تبقى محمية بـ SL على الأقل - نحاول مرة إضافية واحدة قبل الاستسلام
        log_event("warning", "أمر TP رُفض - محاولة إعادة إنشائه مرة واحدة إضافية")
        time.sleep(1)
        try:
            tp_retry = create_order_idempotent(
                client, "place_take_profit_retry", symbol=symbol, side=close_side,
                type=ORDER_TYPE_TAKE_PROFIT_MARKET, stopPrice=tp_price, closePosition=True,
            )
            if tp_retry.get("status") == "REJECTED":
                raise RuntimeError("رُفض مرة ثانية")
            tp_order_id = tp_retry["orderId"]
        except Exception:
            log_event("error", "أمر TP رُفض مرتين - الصفقة ستستمر بحماية SL فقط بدون هدف ربح تلقائي")
            side_ar = "ش" if side == "BUY" else "ب"
            notify_telegram(f"[WARN] فشل وضع TP لصفقة {side_ar} بعد محاولتين - يعمل الآن بـ SL فقط، راقبها يدوياً")
            tp_order_id, tp_price_saved = None, None

    # تحقق مستقل من TP أيضاً (لو نجح إنشاؤه ظاهرياً) - SL يبقى الأولوية
    # ولا يُمس؛ لو فشل التحقق من TP فقط نعامله كـ"TP مفقود" (تحذير وليس
    # إغلاقاً طارئاً)، تماماً كحالة رفضه المعالجة أعلاه.
    if tp_order_id is not None and not _verify_protective_order(
            client, symbol, tp_order_id, ORDER_TYPE_TAKE_PROFIT_MARKET, close_side, expected_stop_price=tp_price):
        log_event("warning", "فشل التحقق المستقل من وجود TP فعلياً - الصفقة ستستمر بحماية SL فقط",
                  symbol=symbol, tp_order_id=tp_order_id)
        side_ar = "ش" if side == "BUY" else "ب"
        notify_telegram(f"[WARN] فشل التحقق من TP لصفقة {side_ar} - يعمل الآن بـ SL فقط، راقبها يدوياً")
        tp_order_id, tp_price_saved = None, None

    STORE.save_open_position(symbol, side, filled_qty, entry_price, sl_order["orderId"], tp_order_id,
                              tp_price_saved, signal_source=signal_source, quality_score=quality_score)
    notional = filled_qty * entry_price
    margin_used = notional / CFG.LEVERAGE
    actual_risk_usdt_final = filled_qty * entry_price * sl_pct
    actual_risk_pct = (actual_risk_usdt_final / capital * 100) if capital > 0 else 0.0
    # قراءة إضافية لـ availableBalance بعد تنفيذ الدخول - للوج/الشفافية فقط
    # (تأكيد أن الهامش المستخدَم فعلاً انعكس على الرصيد المتاح)، لا تُستخدم
    # في أي قرار حجم لاحق.
    try:
        available_balance_after_entry = get_available_balance(client)
    except Exception:
        available_balance_after_entry = None
    # [بطلب صريح] حقول تشخيصية إضافية لكل صفقة: التقدير الحقيقي للخسارة عند
    # SL كنسبة من Equity الفعلي الكامل للحساب (وليس فقط من هامش هذي الصفقة).
    try:
        equity_now = get_account_equity(client)
    except Exception:
        equity_now = None
    estimated_loss_pct_of_equity = (round(actual_risk_usdt_final / equity_now * 100, 3)
                                     if equity_now and equity_now > 0 else None)
    log_event("info", "صفقة مفتوحة ومحفوظة", symbol=symbol, side=side, qty=filled_qty, entry_price=entry_price,
              sl_order_id=sl_order["orderId"], tp_order_id=tp_order_id,
              sl_price=sl_price, tp_price=tp_price_saved,
              balance=round(capital, 3), margin_used=round(margin_used, 3), notional=round(notional, 3),
              actual_risk_usdt=round(actual_risk_usdt_final, 4), actual_risk_pct=round(actual_risk_pct, 3),
              estimated_loss_at_sl=round(actual_risk_usdt_final, 4),
              estimated_loss_pct_of_equity=estimated_loss_pct_of_equity,
              position_number=position_number,
              available_balance_before=round(available_balance_before, 4),
              target_margin_used=round(sizing["margin_used"], 4),
              estimated_notional=round(estimated_notional, 4),
              actual_entry_price=entry_price, actual_qty=filled_qty,
              actual_margin_after_entry=round(margin_used, 4),
              available_balance_after_entry=(round(available_balance_after_entry, 4)
                                              if available_balance_after_entry is not None else None))
    side_ar = "ش" if side == "BUY" else "ب"
    source_txt = f" | سبب={signal_source}" if signal_source else ""
    notify_telegram(
        f"[OK] إشارة {side_ar} | صفقة مفتوحة | {symbol}{source_txt}\n"
        f"دخول~{entry_price:.6g} | SL={sl_price:.6g} | TP={tp_price:.6g} | كمية={qty}\n"
        f"الرصيد={capital:.2f} | هامش مستخدَم≈{margin_used:.2f} | قيمة المركز≈{notional:.2f} | رافعة={CFG.LEVERAGE}x\n"
        f"مخاطرة فعلية≈{actual_risk_usdt_final:.3f}$ ({actual_risk_pct:.2f}% من الرصيد)"
    )
    return True


def _confirm_entry_fill(client: Client, order: dict, fallback_price: float,
                         symbol: str = None) -> tuple:
    """يؤكد تنفيذ أمر الدخول بقراءة الكمية المنفَّذة وسعر التنفيذ **معاً من
    نفس المصدر** دائماً - سابقاً كانت الكمية تُقرأ من استجابة الإنشاء
    الخام (قد تُظهر 0 مؤقتاً حتى لو الأمر نُفّذ فعلياً خلال أجزاء من
    الثانية على منصة Binance)، بينما السعر يُعاد استعلامه بشكل منفصل -
    هذا التضارب كان يجعل البوت يظن أن الدخول فشل رغم أنه نجح فعلياً على
    المنصة، تاركاً مركزاً حقيقياً بلا أي حماية أو تسجيل محلي.

    يُرجع (filled_qty, entry_price). لو تعذر التأكد حتى بعد إعادة
    الاستعلام، يفحص أخيراً المركز الحي فعلياً على المنصة (دفاع أخير) قبل
    الحكم النهائي بأن الأمر لم يُنفَّذ."""
    symbol = symbol or CFG.SYMBOL
    qty = float(order.get("executedQty", 0) or 0)
    avg = float(order.get("avgPrice", 0) or 0)
    if qty > 0 and avg > 0:
        return qty, avg

    try:
        refreshed = with_retry(client.futures_get_order, symbol=symbol,
                                orderId=order["orderId"], description="refresh_entry_fill")
        r_qty = float(refreshed.get("executedQty", 0) or 0)
        r_avg = float(refreshed.get("avgPrice", 0) or 0)
        if r_qty > 0:
            return r_qty, (r_avg if r_avg > 0 else fallback_price)
    except Exception as e:
        log_event("warning", "تعذر تحديث حالة أمر الدخول - جاري التحقق من المركز الحي مباشرة", msg=str(e))

    # دفاع أخير: الأمر نفسه غامض حتى بعد إعادة الاستعلام - نتحقق من
    # المركز الفعلي على المنصة مباشرة قبل الحكم بأن الدخول فشل تماماً
    try:
        live = get_live_position(client, symbol=symbol)
        if live and live.get("qty", 0) > 0:
            log_event("warning",
                      "استجابة أمر الدخول كانت غامضة لكن وُجد مركز حي فعلي على المنصة - اعتُبر الدخول ناجحاً",
                      symbol=symbol, live_qty=live["qty"], live_entry=live["entry_price"])
            return live["qty"], (live["entry_price"] if live["entry_price"] > 0 else fallback_price)
    except Exception as e:
        log_event("warning", "تعذر أيضاً التحقق من المركز الحي كدفاع أخير", msg=str(e))

    return 0.0, 0.0


def _get_fill_price(client: Client, order: dict, fallback: float, symbol: str = None) -> float:
    """يجلب سعر التنفيذ الفعلي (avgPrice) من الأمر؛ إن لم يكن متاحاً فوراً
    (شائع مع MARKET أحياناً) يستعلم عن الأمر مرة أخرى قبل الرجوع لسعر تقريبي."""
    symbol = symbol or CFG.SYMBOL
    avg = float(order.get("avgPrice", 0) or 0)
    if avg > 0:
        return avg
    try:
        refreshed = with_retry(client.futures_get_order, symbol=symbol,
                                orderId=order["orderId"], description="refresh_fill_price")
        avg = float(refreshed.get("avgPrice", 0) or 0)
        if avg > 0:
            return avg
    except Exception as e:
        log_event("warning", "تعذر جلب سعر التنفيذ الفعلي - استخدام السعر التقريبي", msg=str(e))
    return fallback


def cancel_sibling_order(client: Client, order_id: Optional[int], reason: str, symbol: str = None):
    if not order_id:
        return
    symbol = symbol or CFG.SYMBOL
    try:
        with_retry(client.futures_cancel_order, symbol=symbol, orderId=order_id,
                   description=f"cancel_sibling_{reason}")
        log_event("info", "تم إلغاء الأمر المقابل بعد إغلاق الصفقة", order_id=order_id, reason=reason)
    except BinanceAPIException as e:
        # -2011 = الأمر غير موجود أصلاً (تم تنفيذه أو إلغاؤه مسبقاً) - ليس خطأ حقيقي هنا
        if e.code != -2011:
            log_event("warning", "فشل إلغاء الأمر المقابل", order_id=order_id, msg=str(e))


def cleanup_duplicate_protective_orders(client: Client, saved_position: dict):
    """تنظيف دوري: يجلب الأوامر المفتوحة الفعلية على المنصة، ويحدد أوامر
    STOP_MARKET التابعة لهذا البوت على جهة الإغلاق الصحيحة - لو وُجد أكثر
    من واحد (بقايا من فشل جزئي بتحديث Trailing Stop، مثلاً نجح إنشاء
    الجديد وفشل إلغاء القديم)، نُبقي فقط الأمر المطابق لـ sl_order_id
    المحفوظ حالياً ونلغي الباقي. لا نلمس TP إطلاقاً هنا (تصميم متعمد -
    TP لا يُلمس مطلقاً بعد فتح الصفقة من أي مسار، بما فيه Trailing Stop)."""
    close_side = SIDE_SELL if saved_position["side"] == "BUY" else SIDE_BUY
    saved_sl_id = saved_position.get("sl_order_id")
    symbol = saved_position["symbol"]

    try:
        open_orders = with_retry(client.futures_get_open_orders, symbol=symbol,
                                  description="cleanup_check_open_orders")
    except Exception as e:
        log_event("warning", "تعذر جلب الأوامر المفتوحة لفحص التكرار (غير حرج)", msg=str(e))
        return

    duplicate_sl_orders = [
        o for o in open_orders
        if is_own_order(o) and o.get("type") == ORDER_TYPE_STOP_MARKET and o.get("side") == close_side
    ]

    if len(duplicate_sl_orders) <= 1:
        return  # الوضع الطبيعي - أمر واحد أو لا شيء بعد

    log_event("warning", "[RETRY] وُجدت أوامر SL مكررة على المنصة - تنظيف", count=len(duplicate_sl_orders),
              order_ids=[o["orderId"] for o in duplicate_sl_orders])

    # نحدد "الأمر المُبقى عليه" قبل أي إلغاء - وليس أثناء الحلقة - حتى لا
    # ننتهي بإلغاء الجميع لو saved_sl_id لم يطابق أياً منهم (كان هذا خطأً
    # حقيقياً بمسودة سابقة: الحلقة كانت تُلغي كل شيء ثم "تدّعي" إبقاء الأقدم
    # بعد فوات الأوان، تاركة المركز بلا أي حماية على الإطلاق)
    keeper_id = saved_sl_id if any(o["orderId"] == saved_sl_id for o in duplicate_sl_orders) else \
        duplicate_sl_orders[0]["orderId"]
    if keeper_id != saved_sl_id:
        log_event("warning", "لم يطابق أي أمر SL المحفوظ محلياً - تم اختيار الأقدم كبديل احتياطي قبل الإلغاء",
                  keeper_id=keeper_id)
        # BUG-07: تحديث SQLite فوراً وبشكل حتمي بعد اختيار keeper_id
        # وقبل أي إلغاء — يمنع عدم تطابق الحالة المحلية مع الأمر المبقى عليه
        # لو انقطع التنفيذ أثناء حلقة الإلغاء.
        STORE.update_trailing_state(
            saved_position["symbol"], keeper_id,
            saved_position.get("extreme_price", 0.0),
            saved_position.get("last_sl_price") or 0.0,
        )

    for order in duplicate_sl_orders:
        if order["orderId"] == keeper_id:
            continue  # هذا الأمر المُبقى عليه - لا نلمسه
        try:
            with_retry(client.futures_cancel_order, symbol=symbol, orderId=order["orderId"],
                       description="cancel_duplicate_sl")
            log_event("info", "تم إلغاء أمر SL مكرر", order_id=order["orderId"])
        except BinanceAPIException as e:
            if e.code != -2011:  # الأمر أصلاً غير موجود (نُفّذ/أُلغي قبل وصولنا) - ليس خطأ هنا
                log_event("warning", "فشل إلغاء أمر SL مكرر", order_id=order["orderId"], msg=str(e))


def evaluate_stale_exit(saved_position: dict, current_price: float, held_hours: float) -> tuple:
    """[بطلب صريح - القسم 4: الخروج الذكي من الركود] بدل الاعتماد فقط على
    مؤقّت ثابت (MAX_HOLDING_HOURS)، يُقيَّم هل الصفقة "صحية ومستمرة
    بالتحسّن" (فتُترك) أم "راكدة/فقدت الزخم منذ مدة طويلة" (فتُغلق).
    سقف مطلق منفصل (STALE_EXIT_HARD_CAP_HOURS) يبقى يمنع التجميد الأبدي
    لرأس المال حتى لو بدت الصفقة متحسنة ظاهرياً. يُرجع (should_close, reason)."""
    entry = saved_position.get("entry_price") or 0.0
    side = saved_position.get("side")
    if entry <= 0 or side not in ("BUY", "SELL"):
        return False, "invalid_position_data"

    pnl_pct = (current_price - entry) / entry if side == "BUY" else (entry - current_price) / entry
    tp_price_saved = saved_position.get("tp_price")
    if tp_price_saved and entry > 0 and CFG.TARGET_RISK_REWARD_RATIO > 0:
        sl_unit_pct = (abs(tp_price_saved - entry) / entry) / CFG.TARGET_RISK_REWARD_RATIO
    else:
        sl_unit_pct = CFG.FIXED_STOP_LOSS_PCT  # احتياطي فقط لو tp_price غير محفوظ
    current_r = pnl_pct / sl_unit_pct if sl_unit_pct > 0 else 0.0
    peak_r = float(saved_position.get("peak_r") or 0.0)

    # سقف مطلق: بغض النظر عن أي "تحسّن" ظاهري، لا تبقى صفقة مفتوحة للأبد.
    if held_hours >= CFG.STALE_EXIT_HARD_CAP_HOURS:
        return True, f"hard_cap_{CFG.STALE_EXIT_HARD_CAP_HOURS:.0f}h_exceeded"

    if held_hours < CFG.MAX_HOLDING_HOURS:
        return False, "within_normal_holding_window"

    time_since_peak_hours = None
    peak_time = saved_position.get("peak_time")
    if peak_time:
        try:
            peak_dt = datetime.fromisoformat(peak_time)
            if peak_dt.tzinfo is None:
                peak_dt = peak_dt.replace(tzinfo=timezone.utc)
            time_since_peak_hours = (utc_now() - peak_dt).total_seconds() / 3600.0
        except (ValueError, TypeError):
            time_since_peak_hours = None

    # اتجاه صحي واضح: وصلت لذروة معنوية (>=1R) وما زال الوضع الحالي قريباً
    # منها (لم يفقد نصف مكاسبه) ولم يمرّ وقت طويل منذ آخر تحسّن فعلي -
    # لا تُغلق بسبب المؤقت فقط، اتركها تستمر (لا تقتل اتجاهاً صحياً).
    healthy_trend = (
        peak_r >= 1.0 and current_r >= peak_r * 0.5 and
        (time_since_peak_hours is None or time_since_peak_hours <= CFG.STALE_EXIT_TIME_SINCE_PEAK_HOURS)
    )
    if healthy_trend:
        return False, "healthy_trend_still_progressing"

    # راكدة تماماً: لم تصل يوماً لذروة تُذكر، وما زالت قريبة من التعادل.
    stagnant = (
        peak_r < CFG.STALE_EXIT_STAGNANT_R_THRESHOLD and
        -0.015 <= pnl_pct <= 0.005
    )
    if stagnant:
        return True, "stagnant_no_meaningful_progress"

    # حقّقت ربحاً معقولاً سابقاً لكنها فقدت الزخم منذ مدة طويلة جداً ولم
    # تُغلق بعد عبر حماية الأرباح (خط الدفاع الأول) - أغلقها بدل انتظار
    # عودة قد لا تأتي أبداً.
    lost_momentum_too_long = (
        peak_r >= CFG.STALE_EXIT_STAGNANT_R_THRESHOLD and
        time_since_peak_hours is not None and
        time_since_peak_hours >= CFG.STALE_EXIT_TIME_SINCE_PEAK_HOURS * 2
    )
    if lost_momentum_too_long:
        return True, "lost_momentum_since_peak_too_long"

    return False, "still_evaluating_not_yet_conclusive"


def manage_trailing_stop(client: Client, filters: SymbolFilters, position: dict, current_price: float):
    """يحرّك وقف الخسارة يدوياً (إلغاء + إعادة إنشاء) بدل استخدام أمر
    Trailing منفصل يتعارض مع STOP_MARKET الموجود أصلاً (يحل ثغرة #4).

    [مُحدَّث - محرك حماية أرباح متدرّج حسب R، القسم 3 من ملف الإصلاح]
    بدل مسافة تتبع ثابتة واحدة فقط، تُحسب أرضية حماية (floor) تتصاعد مع
    ذروة R التي وصلتها الصفقة (peak_r):
      peak_r >= 1.0  → أرضية = التعادل + هامش رسوم (لا تتحول لخسارة كاملة)
      peak_r >= 1.5  → أرضية = قفل 0.5R من الربح على الأقل
      peak_r >= 2.0  → أرضية = قفل 1.0R + مسافة تتبع أوسع (مساحة أكبر للاتجاه)
      peak_r >= 3.0  → أرضية = قفل 1.5R + مسافة تتبع أوسع أكثر
    الأرضية والتتبع الكلاسيكي (خلف الذروة) يُقارَنان، والأكثر حماية يفوز -
    ولا يُسمح أبداً بتخفيف الحماية عن آخر SL محفوظ (improved-only).
    الذروة (extreme/MFE) وأسوأ سعر (MAE) وذروة الربح بالدولار وذروة R
    تُحدَّث هنا كل دورة بغض النظر عن التفعيل، لتبقى دقيقة من أول تحرّك
    إيجابي للصفقة - ولتغذية الخروج الذكي من الركود (القسم 4) وتشخيصات
    تيليجرام (القسم 13)."""
    side = position["side"]
    entry = position["entry_price"]
    extreme = position.get("extreme_price") or entry
    qty = position.get("qty") or 0.0
    symbol = position["symbol"]

    if entry <= 0:
        return

    # --- تحديث الذروة (MFE) وأسوأ سعر (MAE) - كل دورة، بلا شرط تفعيل ---
    if side == "BUY":
        new_extreme = max(extreme, current_price)
        new_mae = min(position.get("mae_price") or entry, current_price)
    else:
        new_extreme = min(extreme, current_price)
        new_mae = max(position.get("mae_price") or entry, current_price)

    profit_pct = (current_price - entry) / entry if side == "BUY" else (entry - current_price) / entry
    peak_profit_pct = (new_extreme - entry) / entry if side == "BUY" else (entry - new_extreme) / entry

    # sl_unit_pct = مسافة SL الفعلية لهذي الصفقة تحديداً (ديناميكية لكل صفقة
    # الآن - structure/ATR)، لا القيمة الثابتة العامة. لا عمود DB مخصص لها،
    # فتُشتق من tp_price المحفوظ فعلياً لحظة الفتح: tp_distance = sl_distance
    # × TARGET_RISK_REWARD_RATIO (نفس المعادلة المستخدمة في open_trade) -
    # هذا أدق بكثير من افتراض FIXED_STOP_LOSS_PCT لكل الصفقات بالتساوي.
    tp_price_saved = position.get("tp_price")
    if tp_price_saved and entry > 0 and CFG.TARGET_RISK_REWARD_RATIO > 0:
        sl_unit_pct = (abs(tp_price_saved - entry) / entry) / CFG.TARGET_RISK_REWARD_RATIO
    else:
        sl_unit_pct = CFG.FIXED_STOP_LOSS_PCT  # احتياطي فقط لو tp_price غير محفوظ (مركز يتيم مُتبنّى مثلاً)
    peak_r = peak_profit_pct / sl_unit_pct if sl_unit_pct > 0 else 0.0
    peak_pnl_usdt = qty * entry * peak_profit_pct

    prev_peak_r = float(position.get("peak_r") or 0.0)
    peak_time = position.get("peak_time")
    if peak_r > prev_peak_r + 1e-9:
        peak_time = utc_iso()  # ذروة جديدة فعلية - سجّل وقتها لأجل "الزمن منذ آخر ذروة"

    STORE.update_position_extremes(symbol, mae_price=new_mae, peak_pnl_usdt=peak_pnl_usdt,
                                    peak_r=max(peak_r, prev_peak_r), peak_time=peak_time)

    # --- تنبيه تشخيصي (لا يُغلق صفقة بذاته) لو حدث تراجع كبير عن الذروة ---
    current_pnl_usdt = qty * entry * profit_pct
    if peak_pnl_usdt >= CFG.MIN_PEAK_USDT_FOR_GIVEBACK_WARNING:
        giveback_usdt = peak_pnl_usdt - current_pnl_usdt
        giveback_ratio = giveback_usdt / peak_pnl_usdt if peak_pnl_usdt > 0 else 0.0
        if giveback_ratio >= CFG.LARGE_GIVEBACK_WARN_RATIO:
            log_event("warning", "تراجع كبير عن ذروة الربح (giveback) - راقب حماية الصفقة",
                      reason="LARGE_PROFIT_GIVEBACK", symbol=symbol, side=side,
                      peak_pnl_usdt=round(peak_pnl_usdt, 4), current_pnl_usdt=round(current_pnl_usdt, 4),
                      giveback_usdt=round(giveback_usdt, 4), giveback_ratio=round(giveback_ratio, 3),
                      peak_r=round(peak_r, 2))

    # --- أرضية الحماية المتدرّجة حسب ذروة R ---
    fee_buffer_pct = (CFG.TAKER_FEE_RATE * 2.0) + CFG.SLIPPAGE_BUFFER_PCT
    floor_r = None
    wide_trail_mult = 1.0
    if peak_r >= CFG.PROFIT_PROTECT_R3:
        floor_r, wide_trail_mult = CFG.PROFIT_PROTECT_LOCK_AT_R3, CFG.PROFIT_PROTECT_TRAIL_MULT_R3
    elif peak_r >= CFG.PROFIT_PROTECT_R2:
        floor_r, wide_trail_mult = CFG.PROFIT_PROTECT_LOCK_AT_R2, CFG.PROFIT_PROTECT_TRAIL_MULT_R2
    elif peak_r >= CFG.PROFIT_PROTECT_R1_5:
        floor_r = CFG.PROFIT_PROTECT_LOCK_AT_R1_5
    elif peak_r >= CFG.PROFIT_PROTECT_R1:
        floor_r = 0.0  # تعادل فقط - مع هامش رسوم أدناه، وليس صفر خسارة صافية

    floor_price = None
    if floor_r is not None:
        floor_distance = floor_r * sl_unit_pct * entry
        buffer_amt = entry * fee_buffer_pct if floor_r == 0.0 else 0.0
        floor_price = (entry + floor_distance + buffer_amt) if side == "BUY" else (entry - floor_distance - buffer_amt)

    # نشتق مسافة الوقف الفعلية لهذي الصفقة تحديداً من tp_price المحفوظ
    # نشتق مسافة التتبع من الحماية المحفوظة مع fallback ثابت وآمن، ثم
    # نوسّعها بمضاعِف الذروة (wide_trail_mult) عند 2R/3R+ فأكثر.
    tp_price_for_scale = position.get("tp_price")
    if tp_price_for_scale:
        implied_stop_pct = abs(tp_price_for_scale - entry) / entry / 2.0
        activation_pct = max(implied_stop_pct * 0.6, CFG.TRAILING_ACTIVATION_PROFIT_PCT * 0.5)
        base_trail_distance_pct = max(implied_stop_pct * 0.3, CFG.TRAILING_DISTANCE_PCT * 0.5)
    else:
        activation_pct = CFG.TRAILING_ACTIVATION_PROFIT_PCT
        base_trail_distance_pct = CFG.TRAILING_DISTANCE_PCT
    trail_distance_pct = base_trail_distance_pct * wide_trail_mult

    trailing_sl_price = None
    if profit_pct >= activation_pct:
        if side == "BUY":
            trailing_sl_price = new_extreme * (1 - trail_distance_pct)
        else:
            trailing_sl_price = new_extreme * (1 + trail_distance_pct)

    candidates = [p for p in (floor_price, trailing_sl_price) if p is not None]
    if not candidates:
        return  # لا تفعيل تتبع ولا أرضية بعد - الذروة/MAE تحدّثا أعلاه فقط، بدون أمر جديد

    new_sl_raw = max(candidates) if side == "BUY" else min(candidates)
    new_sl = filters.round_price(new_sl_raw)

    # احترام الحد الأدنى بين تحديثات الوقف المتحرك (يحمي من Rate Limit)
    global _LAST_TRAIL_UPDATE_TS
    now_mono = time.monotonic()
    if now_mono - _LAST_TRAIL_UPDATE_TS < CFG.TRAIL_UPDATE_MIN_INTERVAL_SEC:
        return

    last_sl = position.get("last_sl_price")  # يُقرأ من قاعدة البيانات (كان مفقوداً سابقاً)

    if side == "BUY":
        improved = last_sl is None or new_sl > last_sl
    else:
        improved = last_sl is None or new_sl < last_sl

    if not improved:
        return

    close_side = SIDE_SELL if side == "BUY" else SIDE_BUY
    trade_symbol = position["symbol"]

    # أمان إضافي: لا تدع الوقف المتحرك يتجاوز سعر جني الربح (يصبح SL > TP وهذا غير منطقي)
    tp_price = position.get("tp_price")
    if tp_price:
        if side == "BUY":
            new_sl = min(new_sl, tp_price - filters.tick_size * 2)
        else:
            new_sl = max(new_sl, tp_price + filters.tick_size * 2)

    # [Glama 4 - إصلاح خلل حلقة إعادة المحاولة اللانهائية] السبب الجذري
    # الشائع لفشل إنشاء SL المتحرك بشكل متكرر بلا توقف هو -2021
    # (ORDER_WOULD_IMMEDIATELY_TRIGGER): السعر السوقي يتحرك (خصوصاً على
    # عملات متقلبة صغيرة مثل 1000SATSUSDT) بين لحظة حساب new_sl هنا
    # ولحظة وصول الطلب فعلياً إلى Binance، فيصبح new_sl قد عبره السعر
    # فعلاً وقت التنفيذ - وبما أن الدورة التالية تُعيد نفس الحساب تقريباً
    # (السعر استمر بنفس الاتجاه)، كانت النتيجة حلقة فشل مطابقة كل دورة
    # للأبد بلا أي تصحيح. الإصلاح: نجلب السعر الحي مباشرة قبل الإرسال،
    # ونفرض هامش أمان (عدة تكات) بين new_sl وذاك السعر الحي في الاتجاه
    # الصحيح - فلا يُرسَل طلب نعرف مسبقاً أنه سيُرفض بنفس السبب.
    try:
        fresh_positions = with_retry(client.futures_position_information, symbol=trade_symbol,
                                      description="trailing_fresh_price_check")
        fresh_mark = float(next((p.get("markPrice", 0) for p in fresh_positions), 0) or 0)
    except Exception:
        fresh_mark = 0.0
    if fresh_mark > 0:
        safety_buffer = max(filters.tick_size * 3, fresh_mark * 0.0005)
        if side == "BUY":
            max_allowed_sl = fresh_mark - safety_buffer
            if new_sl >= max_allowed_sl:
                new_sl = filters.round_price(max_allowed_sl)
        else:
            min_allowed_sl = fresh_mark + safety_buffer
            if new_sl <= min_allowed_sl:
                new_sl = filters.round_price_up(min_allowed_sl)
        # بعد الهامش، تأكد أن new_sl ما زال "تحسيناً" فعلياً - وإلا فالسعر
        # يتحرك بسرعة تفوق قدرتنا على تتبعه بأمان هذي اللحظة تحديداً،
        # فالأفضل الانتظار للدورة القادمة بدل إرسال طلب سيُرفض حتماً.
        still_improved = (new_sl > last_sl) if side == "BUY" else (new_sl < last_sl)
        if last_sl is not None and not still_improved:
            log_event("info", "trailing_sl_skipped_market_too_fast", symbol=trade_symbol,
                      reason="fresh_price_invalidated_improvement", fresh_mark=fresh_mark, last_sl=last_sl)
            return

    try:
        # SAFE REPLACEMENT ONLY: create new SL first, verify it, then cancel old.
        # If Binance rejects the new order while the old one exists, DO NOT cancel
        # the old order just to force the update. Keeping the old SL is safer than
        # opening an unprotected window. The next cycle may retry the improvement.
        try:
            new_sl_order = create_order_idempotent(
                client, "place_trailing_sl_before_cancel", symbol=trade_symbol, side=close_side,
                type=ORDER_TYPE_STOP_MARKET, stopPrice=new_sl, closePosition=True,
            )
        except Exception as create_err:
            # [Glama 4 - إصلاح خلل حلقة السجل اللانهائية] تخفيف السجل: لا
            # نطبع نفس رسالة الفشل كل دورة للأبد - فقط أول مرة، ثم كل 10
            # محاولات فاشلة متتالية (يبقى دليل التشخيص موجوداً بلا إغراق
            # الملف)، ونُنبّه المستخدم عبر Telegram مرة واحدة فقط لو استمر
            # الفشل فترة كافية (يعني الحماية المتحركة عالقة فعلياً).
            streak = _TRAIL_FAIL_STREAK.get(trade_symbol, 0) + 1
            _TRAIL_FAIL_STREAK[trade_symbol] = streak
            if streak == 1 or streak % 10 == 0:
                log_event("warning", "تعذر إنشاء SL المتحرك الجديد - تم الإبقاء على SL القديم بدون إلغائه",
                          symbol=trade_symbol, reason="trailing_new_sl_failed", msg=str(create_err),
                          consecutive_failures=streak)
            if streak == _TRAIL_FAIL_ALERT_THRESHOLD:
                notify_telegram(f"[WARN] {trade_symbol}: فشل تحديث الوقف المتحرك {streak} مرات متتالية - "
                                 f"الصفقة تبقى محمية بـSL القديم، لكن حماية الأرباح المتقدمة عالقة. راقبها يدوياً.")
            return

        # نجح إنشاء SL المتحرك - صفّر عدّاد الفشل المتتالي لهذا الرمز
        _TRAIL_FAIL_STREAK[trade_symbol] = 0

        if not _verify_protective_order(client, trade_symbol, new_sl_order["orderId"],
                                         ORDER_TYPE_STOP_MARKET, close_side, expected_stop_price=new_sl):
            log_event("error", "فشل التحقق من SL الجديد - تم الإبقاء على الحماية القديمة وعدم إلغائها",
                      symbol=trade_symbol, reason="trailing_new_sl_verify_failed")
            return

        old_sl_id = position.get("sl_order_id")
        if old_sl_id and old_sl_id != new_sl_order.get("orderId"):
            try:
                cancel_sibling_order(client, old_sl_id, reason="old_trailing_sl_after_new_confirmed", symbol=trade_symbol)
            except Exception as cancel_err:
                log_event("warning", "تعذر إلغاء SL القديم بعد تأكيد الجديد - ستوجد حمايتان مؤقتاً",
                          symbol=trade_symbol, old_sl_id=old_sl_id, msg=str(cancel_err))

        # TP لا يُلمس إطلاقاً هنا بعد الآن (إصلاح جوهري): كان يُلغى ويُعاد
        # إنشاؤه بنفس السعر مع كل تحديث للوقف المتحرك بلا أي داعٍ فعلي -
        # استهلاك زائد لطلبات API، ونافذة زمنية قصيرة بلا حماية TP بين
        # الإلغاء والإنشاء، لصفر فائدة حقيقية (السعر نفسه لم يتغيّر أصلاً).
        # الوقف المتحرك يُدير SL فقط - TP يبقى كما وُضع عند فتح الصفقة تماماً.
        STORE.update_trailing_state(position["symbol"], new_sl_order["orderId"], new_extreme, new_sl,
                                     tp_order_id=position.get("tp_order_id"), tp_price=position.get("tp_price"))
        _LAST_TRAIL_UPDATE_TS = time.monotonic()
        log_event("info", "تحديث وقف الخسارة المتحرك", new_sl=new_sl, peak_r=round(peak_r, 2),
                  floor_r=floor_r, floor_price=floor_price, trailing_sl_price=trailing_sl_price)
    except Exception as e:
        log_event("error", "فشل تحديث الوقف المتحرك - الوقف القديم يُفترض أنه ما زال فعالاً (لم يُلغَ في هذا المسار)",
                  msg=str(e))


# ==============================================================================
# 10) استعادة الحالة عند بدء التشغيل (Recovery)
# ==============================================================================

def _fresh_price_safety_adjust(filters: "SymbolFilters", pos_side: str, is_stop_loss: bool,
                                raw_price: float, live_price: float) -> float:
    """[Glama 5 - إصلاح ثغرة -2021 المتكررة] عند بناء SL/TP طارئ (استعادة
    بعد إعادة تشغيل، أو تبنّي مركز يتيم) كان يُحسَب من نسبة ثابتة عن
    entry_price المحفوظ/الحقيقي فقط - بلا أي تحقق أنه ما زال على الجهة
    الصحيحة من السعر الحي وقت الإرسال. لو السعر تحرك أكثر من النسبة
    الثابتة منذ الدخول (شائع بعد انقطاع Termux لفترة، أو لمركز يتيم قديم)
    يُرفَض الطلب فوراً بخطأ -2021 (ORDER_WOULD_IMMEDIATELY_TRIGGER) - وبما
    أن كل إعادة تشغيل تالية تُعيد نفس الحساب الخاطئ، كانت النتيجة فشلاً
    متكرراً في كل عملية استعادة/تبنٍّ لاحقة بلا أي تصحيح تلقائي. هذي
    الدالة تسحب السعر نحو الجهة الآمنة بهامش قبل إرساله، فلا يُرسَل طلب
    نعرف مسبقاً أنه سيُرفض."""
    if not live_price or live_price <= 0:
        return raw_price
    is_buy = pos_side == "BUY"
    buffer = max(filters.tick_size * 3, live_price * 0.0008)
    if is_stop_loss:
        if is_buy and raw_price >= live_price - buffer:
            return live_price - buffer
        if not is_buy and raw_price <= live_price + buffer:
            return live_price + buffer
    else:
        if is_buy and raw_price <= live_price + buffer:
            return live_price + buffer
        if not is_buy and raw_price >= live_price - buffer:
            return live_price - buffer
    return raw_price


def recover_state_on_startup_for_symbol(client: Client, filters: SymbolFilters, symbol: str):
    """استعادة حالة رمز واحد."""
    recover_state_on_startup(client, filters, symbol)

def recover_state_on_startup(client: Client, filters: SymbolFilters, symbol: str):

    saved = STORE.get_open_position(symbol)
    if not saved:
        return
    positions = with_retry(client.futures_position_information, symbol=symbol,
                            description="check_recovery_position")
    live_qty = next((float(p["positionAmt"]) for p in positions), 0.0)

    if live_qty == 0:
        log_event("warning", "صفقة محفوظة محلياً لكن غير موجودة فعلياً على المنصة - تنظيف الحالة")
        STORE.clear_open_position(symbol)
        return

    # تحقق إن اتجاه المركز الفعلي على المنصة يطابق الاتجاه المحفوظ محلياً
    # (positionAmt موجب = LONG/BUY، سالب = SHORT/SELL)
    live_side = "BUY" if live_qty > 0 else "SELL"
    live_entry_price = float(next((p.get("entryPrice", 0) for p in positions), 0) or 0)
    if live_side != saved["side"]:
        log_event("warning", "تعارض اتجاه الصفقة - تصحيح محلي بدل الإيقاف",
                  saved_side=saved["side"], live_side=live_side, symbol=symbol)
        notify_telegram(f"[WARN] تعارض اتجاه على {symbol}: محفوظ={saved['side']} / فعلي={live_side} — تصحيح محلي")
        # نحدّث الحالة بالاتجاه الفعلي ونكمل بدل إيقاف البوت
        saved["side"] = live_side
        saved["qty"] = abs(live_qty)

    # Binance is source of truth for current size/entry/side.
    saved["qty"] = abs(live_qty)
    if live_entry_price > 0:
        saved["entry_price"] = live_entry_price

    # تحقق من أن أوامر SL/TP المحفوظة ما زالت فعلاً معلّقة على المنصة (لم تُنفَّذ أو تُلغَ
    # أثناء توقف البوت). هذا فحص حرج: صفقة مفتوحة بدون SL فعلي = خطر تصفية بلا حماية.
    open_orders = with_retry(client.futures_get_open_orders, symbol=symbol,
                              description="check_recovery_open_orders")
    open_order_ids = {o["orderId"] for o in open_orders}

    sl_id, tp_id = saved.get("sl_order_id"), saved.get("tp_order_id")
    # [WARN] sl_id قد يكون None بشكل شرعي (الحالة المؤقتة المحفوظة فوراً بعد الدخول
    # قبل إنشاء SL بعد) - "غير موجود في الأوامر المفتوحة" لازم تُفحص بصراحة،
    # لأن `sl_id and ...` كانت تُقيَّم False خطأً عندما sl_id=None فتخفي الخطر
    sl_missing = sl_id not in open_order_ids  # True أيضاً لو sl_id=None (لا يوجد شيء بالأصل)
    tp_missing = tp_id is not None and tp_id not in open_order_ids

    close_side = SIDE_SELL if saved["side"] == "BUY" else SIDE_BUY
    current_price = None

    # [WARN] وجود orderId بقائمة الأوامر المفتوحة لا يكفي وحده - orderId فريد
    # فعلاً على مستوى الرمز فلا التباس بمطابقته، لكن نتحقق أيضاً من تفاصيل
    # الأمر نفسه (النوع، الاتجاه، موقع stopPrice من السعر الحالي) لضمان أنه
    # فعلاً "وقف خسارة صالح يحمي هذا المركز تحديداً" وليس حالة بيانات فاسدة
    if not sl_missing:
        sl_order_details = next((o for o in open_orders if o["orderId"] == sl_id), None)
        if sl_order_details is None or sl_order_details.get("type") != ORDER_TYPE_STOP_MARKET \
                or sl_order_details.get("side") != close_side:
            log_event("error", "[ALERT] الأمر المحفوظ كـ SL لا يطابق مواصفات وقف خسارة صالح - يُعتبر مفقوداً",
                      order_id=sl_id, details=sl_order_details)
            sl_missing = True
            current_price = float(next((p.get("markPrice", 0) for p in positions), 0) or 0)
        else:
            stop_price = float(sl_order_details.get("stopPrice", 0) or 0)
            current_price = float(next((p.get("markPrice", 0) for p in positions), 0) or 0)
            if current_price > 0 and stop_price > 0:
                # لصفقة BUY، الوقف يجب أن يكون تحت السعر الحالي (يحمي من هبوط) - والعكس لـ SELL
                wrong_side_of_market = (
                    (saved["side"] == "BUY" and stop_price >= current_price) or
                    (saved["side"] == "SELL" and stop_price <= current_price)
                )
                if wrong_side_of_market:
                    log_event("error", "[ALERT] stopPrice للـ SL المحفوظ بالجهة الخاطئة من السعر الحالي - لن يحمي فعلياً",
                              stop_price=stop_price, current_price=current_price, side=saved["side"])
                    sl_missing = True

    for order in open_orders:
        if order["orderId"] not in (sl_id, tp_id):
            belongs_to_bot = is_own_order(order)
            log_event("warning", "أمر معلّق غير متطابق مع الحالة المحفوظة - راجعه يدوياً",
                      order_id=order["orderId"], type=order.get("type"),
                      belongs_to_this_bot=belongs_to_bot,
                      note="بقايا من هذا البوت (نسخة سابقة فقدت حالتها)" if belongs_to_bot
                           else "على الأغلب أمر يدوي أو من نسخة/بوت آخر - لا تلمسه تلقائياً")

    if sl_missing:
        log_event("error", "[ALERT] أمر وقف الخسارة المحفوظ غير موجود أو غير صالح على المنصة - المركز بلا حماية! إنشاء SL طارئ")
        entry = saved["entry_price"]
        sl_pct = CFG.FIXED_STOP_LOSS_PCT
        if not current_price or current_price <= 0:
            # [Glama 5] قد لا يكون current_price قد جُلب أعلاه (حالة sl_id=None
            # من الأساس) - نجلبه الآن بدل ترك الحساب يعتمد على entry فقط
            try:
                fresh_positions = with_retry(client.futures_position_information, symbol=symbol,
                                              description="recovery_fresh_price_check")
                current_price = float(next((p.get("markPrice", 0) for p in fresh_positions), 0) or 0)
            except Exception:
                current_price = 0.0
        emergency_sl_raw = entry * (1 - sl_pct) if saved["side"] == "BUY" else entry * (1 + sl_pct)
        emergency_sl_raw = _fresh_price_safety_adjust(filters, saved["side"], True, emergency_sl_raw, current_price)
        emergency_sl = filters.round_price(emergency_sl_raw)
        try:
            new_sl = create_order_idempotent(
                client, "emergency_recovery_sl", symbol=symbol, side=close_side,
                type=ORDER_TYPE_STOP_MARKET, stopPrice=emergency_sl, closePosition=True,
            )
            # لا نكتفي بعدم ظهور استثناء - نستعلم عن الأمر فعلياً ونتأكد أن حالته
            # NEW (مقبول وفعّال على المنصة) قبل اعتبار الصفقة محمية من جديد
            confirmed = with_retry(client.futures_get_order, symbol=symbol,
                                    orderId=new_sl["orderId"], description="confirm_emergency_sl")
            if confirmed.get("status") != "NEW":
                raise RuntimeError(f"أمر SL الطارئ لم يستقر بحالة NEW (الحالة الفعلية: {confirmed.get('status')})")
            STORE.update_trailing_state(saved["symbol"], new_sl["orderId"], entry, emergency_sl)
            notify_telegram("[ALERT] تم اكتشاف صفقة بدون وقف خسارة عند إعادة التشغيل - أُضيف SL طارئ")
        except Exception as e:
            log_event("error", "فشل إنشاء SL الطارئ - إغلاق المركز فوراً بدل إيقاف البوت", msg=str(e))
            try:
                create_order_idempotent(
                    client, "emergency_close_recovery_no_sl", symbol=symbol, side=close_side,
                    type=ORDER_TYPE_MARKET, quantity=abs(live_qty), reduceOnly=True,
                )
                STORE.clear_open_position(symbol)
                notify_telegram(f"[ALERT] فشل SL طارئ على {symbol} — تم إغلاق المركز تلقائياً للحماية")
            except Exception as close_err:
                log_event("error", "فشل الإغلاق الطارئ أيضاً", msg=str(close_err))
                notify_telegram(f"[ALERT][ALERT] {symbol} بلا حماية وفشل الإغلاق — تدخل يدوي فوري!")
                # نبقي Fatal فقط إذا فشل الإغلاق أيضاً
                raise FatalBotError(
                    f"فشل SL الطارئ وفشل الإغلاق على {symbol}. أغلق يدوياً من Binance."
                ) from close_err

    if tp_missing or saved.get("tp_order_id") is None:
        # Rebuild TP from the authoritative live entry price after SL is confirmed.
        entry_for_tp = saved.get("entry_price")
        if entry_for_tp and entry_for_tp > 0:
            # [Glama 5] نفس إصلاح -2021: نتحقق من السعر الحي قبل بناء TP الطارئ
            tp_live_price = current_price
            if not tp_live_price or tp_live_price <= 0:
                try:
                    fresh_positions_tp = with_retry(client.futures_position_information, symbol=symbol,
                                                      description="recovery_tp_fresh_price_check")
                    tp_live_price = float(next((p.get("markPrice", 0) for p in fresh_positions_tp), 0) or 0)
                except Exception:
                    tp_live_price = 0.0
            tp_raw = (entry_for_tp * (1.0 - CFG.FIXED_TAKE_PROFIT_PCT) if saved["side"] == "SELL"
                      else entry_for_tp * (1.0 + CFG.FIXED_TAKE_PROFIT_PCT))
            tp_raw = _fresh_price_safety_adjust(filters, saved["side"], False, tp_raw, tp_live_price)
            tp_price_recovery = (filters.round_price(tp_raw) if saved["side"] == "SELL"
                                  else filters.round_price_up(tp_raw))
            try:
                rebuilt_tp = create_order_idempotent(
                    client, "recovery_take_profit", symbol=symbol, side=close_side,
                    type=ORDER_TYPE_TAKE_PROFIT_MARKET, stopPrice=tp_price_recovery, closePosition=True,
                )
                if _verify_protective_order(client, symbol, rebuilt_tp["orderId"],
                                             ORDER_TYPE_TAKE_PROFIT_MARKET, close_side,
                                             expected_stop_price=tp_price_recovery):
                    saved["tp_order_id"] = rebuilt_tp["orderId"]
                    saved["tp_price"] = tp_price_recovery
                    log_event("info", "تمت استعادة TP المفقود من سعر الدخول الحقيقي",
                              symbol=symbol, tp_price=tp_price_recovery)
                else:
                    raise RuntimeError("TP recovery verification failed")
            except Exception as e:
                log_event("warning", "تعذر استعادة TP - يستمر المركز محمياً بـSL فقط", symbol=symbol, msg=str(e))

    # فحص معلوماتي فقط لنسبة المخاطرة:العائد للصفقة المستعادة - لا يُغلق
    # الصفقة أبداً حتى لو كانت النسبة أقل من الحد الأدنى، فقط يُسجَّل تحذير
    stored_tp_price = saved.get("tp_price")
    stored_entry_price = saved.get("entry_price")
    stored_side = saved.get("side")
    stored_sl_price = saved.get("last_sl_price")

    if stored_tp_price and stored_entry_price and stored_side and stored_sl_price:
        protection = calculate_protection_prices(
            entry_price=stored_entry_price,
            side=stored_side,
            sl_distance_pct=abs(stored_entry_price - stored_sl_price) / stored_entry_price,
            tp_distance_pct=abs(stored_tp_price - stored_entry_price) / stored_entry_price,
            min_rr=CFG.MIN_RISK_REWARD_RATIO,
            fee_rate=CFG.TAKER_FEE_RATE,
            slippage_buffer_pct=CFG.SLIPPAGE_BUFFER_PCT,
        )
        if not protection["valid"]:
            log_event("warning", "stored_position_low_rr", symbol=symbol,
                      gross_rr=round(protection["gross_rr"], 3), net_rr=round(protection["net_rr"], 3))
            # لا تغلق الصفقة، فقط سجّل

    log_event("info", "تم استرجاع صفقة مفتوحة من قبل التوقف", saved=saved)


# ==============================================================================
# 10ب) User Data Stream - طبقة مراقبة إضافية (وليست بديلة) عبر أحداث الحساب
# ==============================================================================


class UserDataStream:
    """معطّل عمداً على Termux لتجنب تعارض asyncio.
    البوت يعتمد على REST فقط وهو أكثر استقراراً."""
    def __init__(self, client: Client):
        self.started = False
        log_event("info", "User Data Stream معطّل (وضع REST المستقر)")

    def keepalive_if_needed(self):
        pass

    def stop(self):
        pass



_LEVERAGE_CHECK_CACHE: dict = {}  # {symbol: last_checked_unix_ts} - يُخفَّف فحص انجراف الرافعة (بند 52)


def check_leverage_drift(client: Client, symbol: str):
    """يتحقق أن الرافعة الفعلية على المنصة ما زالت مطابقة للإعدادات - لو غيّرها
    المستخدم يدوياً من تطبيق Binance، حساب حجم الصفقة القادم سيصبح غير دقيق.
    [إصلاح - بند 52 من المواصفة] symbol أصبح إلزامياً صراحة (بلا CFG.SYMBOL
    كاحتياطي صامت) لأن البوت يتداول أكثر من رمز بالتوازي فعلياً - الشكل
    القديم كان يفحص رافعة رمز واحد فقط دائماً بغض النظر عن أي رمز فعلياً
    قيد الفحص، وكان أيضاً غير مُستدعى من أي مكان بالملف (كود ميت فعلياً)."""
    try:
        positions = with_retry(client.futures_position_information, symbol=symbol,
                                description=f"check_leverage_{symbol}")
        if not positions:
            return
        current_leverage = int(float(positions[0].get("leverage", 0)))
        if current_leverage and current_leverage != CFG.LEVERAGE:
            log_event("warning", "[WARN] الرافعة الفعلية على المنصة تختلف عن الإعدادات",
                      symbol=symbol, configured=CFG.LEVERAGE, actual=current_leverage)
            notify_telegram(f"[WARN] {symbol}: الرافعة على Binance ({current_leverage}x) تختلف عن "
                             f"إعدادات البوت ({CFG.LEVERAGE}x)")
    except Exception as e:
        log_event("warning", "تعذر التحقق من الرافعة الحالية", symbol=symbol, msg=str(e))


def safe_telegram_html(message: str) -> str:
    """يهرّب < > & الحرفية داخل محتوى الرسالة (بيانات ديناميكية: أرقام،
    رموز عملات، رسائل استثناء) بحيث لا يرفض Telegram الرسالة كلها إذا
    ظهر فيها < أو > أو & بالصدفة - بينما يُبقي وسوم <b>/</b> و<code>/</code>
    و<i>/</i> المقصودة فعلياً في القوالب الثابتة تعمل كما هي (بند 4 من
    تقرير التشخيص)."""
    import html as _html_mod
    escaped = _html_mod.escape(message, quote=False)
    for tag in ("b", "i", "code", "pre", "u", "s"):
        escaped = escaped.replace(f"&lt;{tag}&gt;", f"<{tag}>").replace(f"&lt;/{tag}&gt;", f"</{tag}>")
    return escaped


def notify_telegram(message: str):
    """إشعار Telegram - أي فشل هنا لا يوقف البوت أبداً."""
    token = os.getenv("TELEGRAM_BOT_TOKEN")
    chat_id = os.getenv("TELEGRAM_CHAT_ID")
    if not token or not chat_id:
        return
    try:
        response = requests.post(
            f"https://api.telegram.org/bot{token}/sendMessage",
            json={"chat_id": chat_id, "text": safe_telegram_html(sanitize_text(message)), "parse_mode": "HTML"},
            timeout=8,
        )
        if response.status_code != 200 or not response.json().get("ok", False):
            log_event("error", "Telegram رفض الرسالة - تحقق من التوكن و Chat ID",
                      status_code=response.status_code, body=str(response.text)[:150])
    except Exception as e:
        log_event("warning", "فشل إرسال إشعار Telegram (غير حرج)", msg=str(e))


def send_telegram_dashboard(text: str, buttons: list = None, edit_message_id: int = None) -> Optional[int]:
    """يرسل (أو يعدّل) رسالة بلوحة أزرار Inline Keyboard احترافية عبر
    Telegram Bot API الرسمي (inline_keyboard) - القسم 10 من المواصفات.
    buttons: قائمة صفوف، كل صف قائمة (label, callback_data). يُرجع
    message_id للرسالة (يُستخدم لاحقاً للتعديل عند الضغط على 'تحديث')."""
    token = os.getenv("TELEGRAM_BOT_TOKEN")
    chat_id = os.getenv("TELEGRAM_CHAT_ID")
    if not token or not chat_id:
        return None
    payload = {"chat_id": chat_id, "text": safe_telegram_html(sanitize_text(text)), "parse_mode": "HTML"}
    if buttons:
        payload["reply_markup"] = {
            "inline_keyboard": [[{"text": label, "callback_data": data} for (label, data) in row] for row in buttons]
        }
    try:
        if edit_message_id:
            payload["message_id"] = edit_message_id
            r = requests.post(f"https://api.telegram.org/bot{token}/editMessageText", json=payload, timeout=8)
        else:
            r = requests.post(f"https://api.telegram.org/bot{token}/sendMessage", json=payload, timeout=8)
        data = r.json()
        if not data.get("ok"):
            # لو التعديل فشل (مثلاً الرسالة الأصلية قديمة جداً)، نرسل رسالة جديدة بدل الفشل الصامت
            if edit_message_id:
                return send_telegram_dashboard(text, buttons, edit_message_id=None)
            log_event("warning", "Telegram رفض رسالة اللوحة", body=str(r.text)[:150])
            return None
        return data.get("result", {}).get("message_id")
    except Exception as e:
        log_event("warning", "فشل إرسال/تعديل لوحة Telegram (غير حرج)", msg=str(e))
        return None


def answer_telegram_callback(callback_query_id: str, text: str = None):
    """يجب استدعاؤها لكل ضغطة زر (answerCallbackQuery) وإلا يبقى الزر
    'يُحمّل' في واجهة Telegram عند المستخدم - إشعار قصير منبثق اختياري."""
    token = os.getenv("TELEGRAM_BOT_TOKEN")
    if not token:
        return
    try:
        payload = {"callback_query_id": callback_query_id}
        if text:
            payload["text"] = text[:200]
        requests.post(f"https://api.telegram.org/bot{token}/answerCallbackQuery", json=payload, timeout=8)
    except Exception:
        pass


def _main_dashboard_buttons() -> list:
    return [
        [("▶️ START TRADING", "dash:starttrading")],
        [("⛔ STOP TRADING", "dash:pause"), ("▶️ استئناف", "dash:resume")],
        [("🔄 تحديث", "dash:refresh"), ("📊 المراكز", "dash:positions")],
        [("💰 الرصيد", "dash:balance"), ("📈 صفقات اليوم", "dash:trades")],
        [("🪙 العملات", "dash:symbols"), ("🔍 إحصائيات الإشارات", "dash:signalstats")],
        [("🛡 قاطع التيار", "dash:breaker")],
        [("💀 إيقاف نهائي (يُنهي العملية)", "dash:stop_confirm")],
    ]


def build_dashboard_text(client) -> str:
    """يبني نص لوحة /start و/status الرئيسية - كل القيم من الحالة الحقيقية
    الآن (لا أرقام ثابتة قديمة)، مطابق للقسم 10 من المواصفات."""
    positions = STORE.get_all_open_positions()
    bal_txt = "غير متاح"
    if client:
        try:
            available = get_available_balance(client)
            wallet = get_wallet_balance(client)
            equity = get_account_equity(client)
            bal_txt = (f"محفظة: {wallet:.4f} | متاح: {available:.4f} | Equity: {equity:.4f} | "
                       f"غير محقق: {(equity - wallet):+.4f} USDT")
        except Exception:
            pass
    paused = "نعم" if _TELEGRAM_PAUSED else "لا"
    metrics = STORE.get_performance_metrics()
    return (
        f"<b>{CFG.BOT_NAME}</b> (v{CFG.SOFTWARE_VERSION})\n"
        f"الوضع: {'TESTNET' if CFG.USE_TESTNET else ('DRY_RUN' if CFG.DRY_RUN else 'LIVE')} | "
        f"محرك: نشط | متوقف مؤقتاً: {paused}\n"
        f"────────────\n"
        f"<b>الرصيد</b>\n{bal_txt}\n"
        f"────────────\n"
        f"<b>التداول</b>\n"
        f"المراكز: {len(positions)}/{CFG.MAX_OPEN_POSITIONS} | "
        f"صفقات اليوم: {STORE.get_today_opened_count()}" + (f"/{CFG.TARGET_TRADES_PER_DAY}" if CFG.TARGET_TRADES_PER_DAY > 0 else " (لا هدف عدد محدَّد)") + "\n"
        f"رابحة: {metrics.get('wins', 0)} | خاسرة: {metrics.get('losses', 0)} | "
        f"Winrate: {metrics.get('win_rate_pct', 0)}%\n"
        f"────────────\n"
        f"<b>الجودة</b>\n"
        f"العتبة الحالية: {adaptive_quality_threshold():.2f} (الأساس={CFG.MIN_QUALITY_SCORE_THRESHOLD:.2f}, "
        f"الحد الأدنى={CFG.MIN_QUALITY_FLOOR:.2f})\n"
        f"────────────\n"
        f"<b>الحماية</b>\n"
        f"{format_breaker_status()}"
    )


def build_positions_text(client) -> str:
    positions = STORE.get_all_open_positions()
    if not positions:
        return "لا توجد صفقات مفتوحة حالياً"
    lines = ["<b>الصفقات المفتوحة</b>"]
    for p in positions:
        sym = p["symbol"]
        side_ar = "طويل (Long)" if p.get("side") == "BUY" else "قصير (Short)"
        entry = p.get("entry_price")
        pnl_txt = ""
        if client:
            try:
                live = with_retry(client.futures_position_information, symbol=sym, description="dash_pos_pnl")
                if live:
                    mark = float(live[0].get("markPrice", 0))
                    upnl = float(live[0].get("unRealizedProfit", 0))
                    pnl_pct = ((mark - entry) / entry * 100) if p.get("side") == "BUY" else ((entry - mark) / entry * 100)
                    pnl_txt = f"\n  الحالي={mark:.6g} | PnL={upnl:+.4f} USDT ({pnl_pct:+.2f}%)"
            except Exception:
                pass
        prot = "SL+TP" if p.get("sl_order_id") and p.get("tp_order_id") else ("SL فقط" if p.get("sl_order_id") else "[ALERT] بلا حماية!")
        age_txt = ""
        try:
            opened_at = datetime.fromisoformat(p.get("opened_at"))
            age_h = (utc_now() - opened_at).total_seconds() / 3600.0
            age_txt = f" | العمر={age_h:.1f}س"
        except Exception:
            pass
        lines.append(
            f"\n• <b>{sym}</b> | {side_ar}\n  دخول={entry} | SL={p.get('last_sl_price')} | TP={p.get('tp_price')}"
            f"{pnl_txt}\n  الحماية={prot}{age_txt}"
        )
    return "\n".join(lines)


def check_server_time_drift(client: Client, warn_threshold_ms: int = 3000):
    """فحص صحي عند الإقلاع (وليس مؤشر تداول): يقيس الفرق بين وقت جهازك
    ووقت سيرفر Binance. فرق كبير سبب شائع لرفض الطلبات لاحقاً برسالة
    'Timestamp for this request is outside of the recvWindow'. تحذير فقط،
    لا يوقف التشغيل - python-binance تصحح الفرق تلقائياً غالباً."""
    try:
        local_before = int(time.time() * 1000)
        server_time = with_retry(client.futures_time, description="check_server_time")["serverTime"]
        local_after = int(time.time() * 1000)
        diff_ms = server_time - (local_before + local_after) // 2
        if abs(diff_ms) > warn_threshold_ms:
            log_event("warning", f"[WARN] فرق ساعة كبير مع سيرفر Binance ({diff_ms}ms) - "
                      "تأكد من ضبط ساعة جهازك تلقائياً (NTP) لتفادي رفض الطلبات لاحقاً")
        else:
            log_event("info", "فحص الساعة مع سيرفر Binance سليم", diff_ms=diff_ms)
    except Exception as e:
        log_event("warning", "تعذر فحص فرق الساعة مع السيرفر (غير حرج)", msg=str(e))


def check_position_mode(client: Client):
    """يتحقق أن الحساب في One-way Mode قبل أي تشغيل حقيقي. كل أوامر
    SL/TP/الإغلاق الطارئ بهذا البوت (8 مواضع مختلفة) مبنية على
    closePosition=True بافتراض مركز واحد لكل رمز - وهذا سلوكه غير مضمون
    في Hedge Mode (يتطلب positionSide محدد صراحة لكل أمر، ودعم مركزين
    متزامنين LONG/SHORT). دعم Hedge Mode الكامل يحتاج إعادة هيكلة كل
    مسارات الأوامر تقريباً، فهذا خارج نطاق هذا الإصلاح عمداً - البوت يرفض
    التشغيل بوضوح بدل التصرف بسلوك غير مُختبر وغير مضمون في Hedge Mode."""
    try:
        mode = with_retry(client.futures_get_position_mode, description="check_position_mode")
    except Exception as e:
        # لا نستطيع التأكد - الأسلم رفض التشغيل بدل افتراض One-way بصمت
        raise FatalBotError(
            f"تعذر التحقق من وضع الحساب (One-way/Hedge) قبل التشغيل: {e}. "
            "لا يمكن ضمان سلامة أوامر SL/TP بدون هذا التحقق - التشغيل مرفوض."
        ) from e

    if mode.get("dualSidePosition", False):
        raise FatalBotError(
            "[BLOCKED] حسابك مضبوط على Hedge Mode (مراكز مزدوجة LONG/SHORT). هذا البوت "
            "مبني على افتراض One-way Mode فقط ولا يدعم Hedge Mode حالياً. "
            "غيّر الوضع من تطبيق/موقع Binance Futures: الإعدادات > Position Mode > "
            "One-way Mode، ثم أعد تشغيل البوت. (لا يمكن تغيير هذا تلقائياً من الكود "
            "لأنه إعداد على مستوى الحساب كله، قد يؤثر على صفقات أخرى غير هذا البوت)."
        )
    log_event("info", "تم التحقق: الحساب في One-way Mode - آمن للمتابعة")


def check_api_ip_restriction(client: Client):
    """يتحقق إن كان مفتاح API مقيّداً بعنوان IP، وإن كانت صلاحية السحب
    مفعّلة عليه (يجب أن تكون مُعطَّلة دائماً على مفتاح تداول آلي - لا حاجة
    له للسحب إطلاقاً، وتفعيلها يضاعف الضرر لو تسرّب المفتاح). كلا الفحصين
    يوقفان التشغيل فعلياً حسب الإعدادات، وليس تحذيراً فقط."""
    try:
        perms = client.get_account_api_permissions()

        if perms.get("enableWithdrawals", False):
            raise RuntimeError(
                "[BLOCKED] صلاحية السحب (enableWithdrawals) مفعّلة على مفتاح API - التشغيل مرفوض. "
                "عطّل صلاحية السحب نهائياً من إعدادات Binance؛ لا حاجة لها في بوت تداول آلي."
            )

        ip_restricted = perms.get("ipRestrict", False)
        if not ip_restricted:
            if CFG.REQUIRE_IP_RESTRICTION:
                raise RuntimeError(
                    "[BLOCKED] مفتاح API غير مقيّد بعنوان IP و CFG.REQUIRE_IP_RESTRICTION=True - "
                    "التشغيل مرفوض. قيّد المفتاح بـ IP من إعدادات Binance أولاً."
                )
            log_event("warning",
                      "[WARN] مفتاح API غير مقيّد بعنوان IP - يُنصح بتفعيل قيد IP من إعدادات Binance للحماية")
    except RuntimeError:
        raise
    except Exception as e:
        log_event("info", "تعذر التحقق من قيود IP/صلاحيات المفتاح (غير حرج)", msg=str(e))


def position_still_open(client: Client, symbol: str = None) -> bool:
    symbol = symbol or CFG.SYMBOL
    positions = with_retry(client.futures_position_information, symbol=symbol,
                            description="check_position")
    return any(float(p["positionAmt"]) != 0 for p in positions)


def _infer_close_reason_from_recent_orders(client: Client, symbol: str) -> tuple:
    """[إصلاح - مُضاف بطلب صريح بعد رصد صفقات تُغلَق بسبب "unclear"]
    resolve_closed_trade كانت تعتمد حصرياً على sl_order_id/tp_order_id
    المحفوظين محلياً؛ أي إغلاق يحدث عبر مسار آخر (قاطع التيار، فقد
    الحماية بعد افتح المركز، مركز يتيم بلا حماية، ...) لا يُكتشف فهناك،
    فتُسجَّل الصفقة "غير واضح" رغم أن البوت نفسه يعرف بالضبط لماذا أغلقها
    (الوسم موجود فعلياً داخل newClientOrderId لكل أمر، عبر
    generate_client_order_id). هذي الدالة تجلب آخر الأوامر الفعلية لهذا
    الرمز من Binance مباشرة (وليس تخميناً)، وتستخرج السبب الحقيقي من
    الأمر الذي أغلق المركز فعلياً، حتى لو لم يكن sl_order_id/tp_order_id
    المحفوظين محلياً. تُرجع (reason, avg_price) أو (None, None)."""
    try:
        orders = with_retry(client.futures_get_all_orders, symbol=symbol, limit=20,
                             description=f"recent_orders_{symbol}")
    except Exception as e:
        log_event("warning", "تعذر جلب سجل الأوامر الأخيرة لتحديد سبب الإغلاق الحقيقي",
                  symbol=symbol, msg=str(e))
        return None, None
    if not orders:
        return None, None

    import re
    bot_tag = _get_safe_bot_tag()
    # الأحدث أولاً
    for order in sorted(orders, key=lambda o: o.get("updateTime", 0) or o.get("time", 0), reverse=True):
        if order.get("status") != "FILLED":
            continue
        if not (order.get("reduceOnly") or order.get("closePosition")):
            continue
        if not is_own_order(order):
            continue
        cid = order.get("clientOrderId", "") or ""
        prefix = f"{bot_tag}_"
        if not cid.startswith(prefix):
            continue
        safe_tag = cid[len(prefix):].rsplit("_", 1)[0]  # يزيل لاحقة الوقت/uuid العشوائية
        avg = float(order.get("avgPrice", 0) or 0)
        reason_map = {
            "staleexitc": "خروج_ذكي_من_الركود",
            "closeorpha": "orphan_protection_failed",
            "circuiteme": "circuit_breaker_emergency",
        }
        if safe_tag in reason_map:
            return reason_map[safe_tag], (avg if avg > 0 else None)
        if safe_tag.startswith("emergencyc"):
            # يغطي emergency_close_no_sl / invalid_protection / sl_verify_failed /
            # liquidation_risk / recovery_no_sl / أي emergency_close_{reason} ديناميكي -
            # كلها تشترك بنفس أول 10 حروف بعد إزالة "_" فتتصادم بادئتها،
            # لكنها جميعاً تندرج تحت فئة واحدة واضحة: إغلاق طارئ لفقد الحماية.
            return "protection_lost_emergency", (avg if avg > 0 else None)
        if safe_tag.startswith("verifiedcl"):
            return "manual", (avg if avg > 0 else None)
    return None, None


def resolve_closed_trade(client: Client, saved_position: dict, fallback_price: float,
                          known_reason: str = None) -> tuple:
    """يحدد أي أمر (SL أو TP) هو اللي نفّذ فعلياً، يجلب سعر تنفيذه الحقيقي
    (avgPrice) بدل الاعتماد على سعر آخر شمعة، ويلغي الأمر الآخر المعلّق.
    يُرجع (exit_price, reason) - reason من "SL"/"TP"/known_reason/"unclear"،
    تُستخدم لاحقاً برسالة الإغلاق عشان يعرف المستخدم فوراً سبب الإغلاق
    الحقيقي دون الحاجة للبحث باللوج يدوياً في كل مرة.

    [WARN] ملاحظة معمارية: هذه الدالة تُستدعى فقط بعد ما get_live_position()
    تأكدت فعلاً (عبر REST طازج) أن positionAmt == 0 - يعني "هل المركز صفر
    فعلاً" محسوم مسبقاً قبل الوصول هنا، وليس مسؤولية هذه الدالة. رغم هذا،
    نضيف تحققاً أخيراً دفاعياً (Defense in Depth) قبل التأكيد النهائي، لأن
    ثوانٍ قليلة تمر بين ذاك التحقق وهذه النقطة (عدة طلبات REST متتالية) -
    لو تبيّن أن المركز أعاد الظهور (نادر جداً لكن ممكن نظرياً)، نرجع None
    بدل سعر، ويجب على المُستدعي عدم مسح الحالة المحلية في هذه الحالة."""
    symbol = saved_position.get("symbol")
    if not symbol:
        # [تدقيق أمان الرمز]: هذا يعني بيانات محفوظة تالفة (سطر بلا رمز أصلاً) -
        # لا نُخمّن الرمز أبداً (لا نستخدم CFG.SYMBOL كاحتياطي صامت هنا) لأن
        # ذلك قد يُطبّق منطق إغلاق BTCUSDT على مركز رمز مختلف تماماً.
        log_event("error", "[ALERT] سجل مركز محفوظ بلا حقل symbol - رفض المعالجة بدل التخمين",
                  saved_position=str(saved_position)[:200])
        return None, "unclear"
    sl_id = saved_position.get("sl_order_id")
    tp_id = saved_position.get("tp_order_id")
    exit_price = fallback_price

    for order_id, other_id, label in ((sl_id, tp_id, "SL"), (tp_id, sl_id, "TP")):
        if not order_id:
            continue
        try:
            order = with_retry(client.futures_get_order, symbol=symbol, orderId=order_id,
                                description=f"check_{label}_status")
        except Exception as e:
            log_event("warning", "تعذر التحقق من حالة الأمر", order_id=order_id, msg=str(e))
            continue

        status = order.get("status")
        if status in ("FILLED", "PARTIALLY_FILLED"):
            avg = float(order.get("avgPrice", 0) or 0)
            exit_price = avg if avg > 0 else fallback_price
            if status == "PARTIALLY_FILLED":
                log_event("warning", "أمر الإغلاق كان منفّذاً جزئياً فقط - السعر تقريبي جزئياً",
                          order_id=order_id, executed_qty=order.get("executedQty"))
            cancel_sibling_order(client, other_id, reason=label, symbol=symbol)
            confirmed = _confirm_flat_or_abort(client, exit_price, symbol=symbol)
            return (confirmed, label) if confirmed is not None else (None, None)

    # لم نجد أي أمر بحالة FILLED بوضوح عبر sl_order_id/tp_order_id المحفوظين
    # محلياً - قبل الاستسلام لـ"unclear"، نحاول تحديد السبب الحقيقي من سجل
    # الأوامر الفعلية على Binance مباشرة (يغطي قاطع التيار، فقد الحماية،
    # المركز اليتيم، وأي مسار إغلاق طارئ آخر لم يُمرَّر له known_reason).
    inferred_reason, inferred_price = _infer_close_reason_from_recent_orders(client, symbol)
    if inferred_reason:
        exit_price = inferred_price if inferred_price is not None else exit_price
        cancel_sibling_order(client, sl_id, reason="cleanup", symbol=symbol)
        cancel_sibling_order(client, tp_id, reason="cleanup", symbol=symbol)
        confirmed = _confirm_flat_or_abort(client, exit_price, symbol=symbol)
        return (confirmed, inferred_reason) if confirmed is not None else (None, None)

    log_event("warning", "لم يتضح أي أمر نفّذ فعلياً - استخدام سعر تقريبي وإلغاء الأوامر المتبقية")
    cancel_sibling_order(client, sl_id, reason="cleanup", symbol=symbol)
    cancel_sibling_order(client, tp_id, reason="cleanup", symbol=symbol)
    confirmed = _confirm_flat_or_abort(client, exit_price, symbol=symbol)
    reason = known_reason or "unclear"
    return (confirmed, reason) if confirmed is not None else (None, None)


def _confirm_flat_or_abort(client: Client, exit_price: float, symbol: str = None) -> Optional[float]:
    """تحقق دفاعي أخير: يستعلم عن المركز الفعلي (حتى 3 محاولات بفاصل قصير)
    قبل تأكيد الإغلاق نهائياً. لو المركز ما زال مفتوحاً بأي كمية، نرفض
    التأكيد ونرجع None - المُستدعي يجب ألا يمسح الحالة المحلية في هذه
    الحالة (سيُعاد فحصه بالدورة القادمة بدل تسجيله كمغلق خطأً)."""
    for attempt in range(3):
        live = get_live_position(client, symbol=symbol)
        if live is None:
            return exit_price
        if attempt < 2:
            time.sleep(1)
    log_event("error", "[ALERT] المركز ما زال مفتوحاً رغم تنفيذ أمر إغلاق - الحالة المحلية لن تُمسح",
              remaining_qty=live.get("qty") if live else None)
    notify_telegram("[ALERT] تحذير: مركز متبقٍّ بعد إغلاق متوقع - راجع الحساب يدوياً، البوت لن يمسح حالته تلقائياً")
    return None


def load_client() -> Client:
    """يحمّل العميل من متغيرات البيئة (محمَّلة من .env) مع معالجة Timestamp."""
    api_key = os.getenv("BINANCE_API_KEY", "").strip()
    api_secret = os.getenv("BINANCE_API_SECRET", "").strip()

    if not api_key or not api_secret:
        raise RuntimeError("[FAIL] BINANCE_API_KEY و BINANCE_API_SECRET مطلوبان في .env")

    if CFG.REQUIRE_TESTNET_FIRST and not CFG.USE_TESTNET:
        raise RuntimeError(
            "[BLOCKED] التشغيل الحقيقي مرفوض أثناء CFG.REQUIRE_TESTNET_FIRST=True. "
            "اختبر على Testnet أولاً، ثم عطّل هذا الخيار عمداً."
        )

    client = Client(api_key, api_secret, testnet=CFG.USE_TESTNET, requests_params={"timeout": 15})
    # معالجة فرق الوقت مع سيرفر Binance تلقائياً + recvWindow أوسع
    try:
        client.API_URL = client.API_URL  # ensure
        server_time = client.futures_time()["serverTime"]
        local_time = int(time.time() * 1000)
        offset = server_time - local_time
        client.timestamp_offset = offset
        log_event("info", "مزامنة الوقت مع Binance", offset_ms=offset)
    except Exception as e:
        log_event("warning", "تعذر مزامنة الوقت الأولي", msg=str(e))
    return client


def get_live_position(client: Client, symbol: str = None) -> Optional[dict]:
    """مصدر واحد موحّد لحالة المركز الفعلي على المنصة - يُستدعى مرة واحدة
    فقط لكل دورة بدل تكرار futures_position_information عدة مرات."""
    symbol = symbol or CFG.SYMBOL
    positions = with_retry(client.futures_position_information, symbol=symbol,
                            description="get_live_position")
    for p in positions:
        qty = float(p.get("positionAmt", 0))
        if qty != 0:
            return {
                "qty": abs(qty),
                "side": "BUY" if qty > 0 else "SELL",
                "entry_price": float(p.get("entryPrice", 0)),
                "mark_price": float(p.get("markPrice", 0)),
                "liquidation_price": float(p.get("liquidationPrice", 0)),
                "leverage": int(float(p.get("leverage", 0))),
            }
    return None



# ==============================================================================
# مستمع أوامر التليجرام البسيط (مع last_update_id لمنع الرسائل القديمة)
# ==============================================================================

_TELEGRAM_LAST_UPDATE_ID = 0
_TELEGRAM_STOP_REQUESTED = False


# ==============================================================================
# مستمع أوامر التليجرام المتقدم (تحكم مباشر + last_update_id)
# ==============================================================================

_TELEGRAM_PAUSED = False
_LAST_SCAN_STATS: dict = {}  # آخر لقطة إحصائيات فحص (القسم 23) - يقرؤها /signalstats من ثريد منفصل
_MANUAL_SCAN_REQUESTED = False  # زر "بدء التداول الآن" (القسم 21) - يُقرأ من الحلقة الرئيسية فقط
_MANUAL_SCAN_PENDING_SINCE = 0.0


def build_expectancy_text() -> str:
    """[Glama 4 - بند 15/16/18 من تقرير التطوير الهجومي] Expectancy =
    (Win Rate × متوسط الربح) − (Loss Rate × متوسط الخسارة) حسب الرمز/
    الاتجاه/مصدر الإشارة/الساعة/نطاق الجودة - بدل الاعتماد على Win Rate
    منفرداً. يُعلِّم كل تجميع تحت الحد الأدنى للعينة (5 صفقات) بـ'⚠عينة
    صغيرة' بدل عرضه كدليل قاطع (بند 15: 'استخدم minimum sample')."""
    stats = STORE.get_expectancy_stats()
    min_sample = stats.get("min_sample", 5)

    def _fmt_group(title: str, group: dict, limit: int = 8) -> list:
        if not group:
            return [f"<b>{title}</b>: لا توجد بيانات بعد"]
        lines = [f"<b>{title}</b>"]
        # الأكثر صفقات أولاً (دليل أوثق)، ثم الأعلى Expectancy
        items = sorted(group.items(), key=lambda kv: (-kv[1].get("trades", 0)))[:limit]
        for key, s in items:
            if s.get("trades", 0) == 0:
                continue
            flag = "" if s.get("reliable") else " ⚠عينة صغيرة"
            lines.append(
                f"  {key}: {s['trades']} صفقة | Win%={s['win_rate_pct']} | "
                f"AvgWin={s['avg_win_usdt']}$ AvgLoss={s['avg_loss_usdt']}$ | "
                f"Expectancy={s['expectancy_usdt']:+.4f}${flag}"
            )
        return lines

    lines = [f"<b>[EXPECTANCY]</b> (حد أدنى للعينة الموثوقة={min_sample} صفقة، وإلا ⚠)"]
    lines += _fmt_group("حسب الرمز", stats.get("by_symbol", {}))
    lines += _fmt_group("حسب الاتجاه", stats.get("by_side", {}))
    lines += _fmt_group("حسب مصدر الإشارة", stats.get("by_signal_source", {}))
    lines += _fmt_group("حسب نطاق الجودة (A>=0.75 / B<0.75)", stats.get("by_quality_band", {}))
    hour_group = {f"{k:02d}:00 UTC": v for k, v in stats.get("by_hour_utc", {}).items()}
    lines += _fmt_group("حسب الساعة (UTC)", hour_group, limit=24)
    return "\n".join(lines)


def build_signal_stats_text() -> str:
    """القسم 12: يُظهر بالضبط أين اختفت كل فرصة في آخر دورة فحص - لتشخيص
    'البوت نايم' بدون تخمين."""
    s = _LAST_SCAN_STATS
    if not s:
        return "لا توجد بيانات فحص بعد (لم تكتمل أي دورة فحص منذ بدء التشغيل)"
    ts = s.get("timestamp", "?")
    return (
        f"<b>إحصائيات آخر دورة فحص</b> ({ts})\n"
        f"تم فحصهم: {s.get('total', 0)}\n"
        f"بلا إشارة: {s.get('no_signal', 0)}\n"
        f"مرفوض HTF: {s.get('htf_conflict', 0)}\n"
        f"مرفوض ATR/رسوم: {s.get('atr_too_small', 0)}\n"
        f"مرفوض Funding: {s.get('funding', 0)}\n"
        f"مرفوض هامش غير كافٍ: {s.get('insufficient_margin', 0)}\n"
        f"مرشحون بعد كل الفلاتر: {s.get('candidates', 0)}\n"
        f"مُحاولة فتح: {s.get('open_trade_attempted', 0)} | فشل فتح: {s.get('open_trade_failed', 0)}\n"
        f"صفقات فُتحت فعلياً: {s.get('opened', 0)}"
    )


def _record_close_before_clear(client: Client, symbol: str, exit_price_hint: float = None,
                                exit_type: str = "manual"):
    """[إصلاح حرِج - بطلب صريح من تقرير مراجعة ثانٍ] عدة مسارات إغلاق (يدوي
    عبر /close، وقاطع التيار الحاسم عبر check_circuit_breaker) كانت تمسح
    open_position مباشرة بعد التأكد من الإغلاق دون استدعاء record_trade_result
    إطلاقاً - فتختفي هذي الصفقات تماماً من trade_history (لا تظهر بـ/stats،
    /expectancy، ولا تُحتسب ضمن bot_pnl_since_baseline). الأخير تحديداً
    يُفسد لاحقاً كشف "تغيير خارجي بالرصيد" لأن الفرق بين الرصيد الفعلي
    والمتوقَّع محلياً يظل بلا تفسير - وتحديداً خطير لمسار قاطع التيار
    الحاسم لأنه يعني الحماية تضعف بعد أول تفعيل لها بالضبط. هذي الدالة
    تُسجَّل الصفقة بشكل موثوق (PnL حقيقي من futures_income_history) قبل
    أي مسح للحالة، لأي مسار إغلاق يستدعيها."""
    saved = STORE.get_open_position(symbol)
    if not saved:
        return  # لا يوجد سجل محلي أصلاً لهذي الصفقة - لا شيء لتسجيله
    try:
        entry_price = float(saved.get("entry_price") or 0)
        qty = abs(float(saved.get("qty") or 0))
        side = saved.get("side")
        opened_at = saved.get("opened_at")
        estimate_fallback = 0.0
        margin_usdt = (entry_price * qty / CFG.LEVERAGE) if (entry_price > 0 and qty > 0 and CFG.LEVERAGE > 0) else 0.0
        if entry_price > 0 and exit_price_hint and side and qty > 0:
            price_diff = (exit_price_hint - entry_price) if side == "BUY" else (entry_price - exit_price_hint)
            estimate_fallback = price_diff * qty
        net_pnl_usdt, _fee, _funding = get_authoritative_pnl_usdt(
            client, since_iso=opened_at, estimate_fallback=estimate_fallback, symbol=symbol)
        pnl_pct = (net_pnl_usdt / margin_usdt) if margin_usdt > 0 else 0.0
        held_minutes = None
        try:
            held_minutes = (utc_now() - datetime.fromisoformat(opened_at)).total_seconds() / 60.0
        except Exception:
            pass
        STORE.record_trade_result(symbol, side, pnl_pct, pnl_usdt=net_pnl_usdt, exit_type=exit_type,
                                   held_minutes=held_minutes, signal_source=saved.get("signal_source"),
                                   quality_score=saved.get("quality_score"))
        log_event("info", "تسجيل إغلاق في trade_history قبل مسح الحالة المحلية",
                  symbol=symbol, exit_type=exit_type, pnl_usdt=round(net_pnl_usdt, 4))
    except Exception as e:
        log_event("warning", "تعذر تسجيل PnL الإغلاق (سيبقى بلا سطر بـtrade_history هذي المرة)",
                  symbol=symbol, exit_type=exit_type, msg=str(e))
    # الأوامر التابعة (SL/TP) لا تُلغى تلقائياً لمجرد إغلاق المركز بأمر آخر -
    # تبقى معلَّقة على المنصة وقد تتنفذ لاحقاً ضد مركز جديد مختلف تماماً على
    # نفس الرمز إن لم تُلغَ الآن صراحة.
    cancel_sibling_order(client, saved.get("sl_order_id"), reason=f"{exit_type}_close_cleanup", symbol=symbol)
    cancel_sibling_order(client, saved.get("tp_order_id"), reason=f"{exit_type}_close_cleanup", symbol=symbol)


def verified_close_position(client: Client, symbol: str, timeout_sec: float = 15.0,
                             poll_interval: float = 1.5) -> tuple:
    """نمط إغلاق آمن مُلزم (القسم 2 من المواصفات): إرسال أمر الإغلاق -> التحقق
    الفعلي من positionAmt==0 على Binance -> فقط بعدها تُمسح الحالة المحلية.
    لو لم يُصبح المركز فعلياً صفراً خلال المهلة، لا تُمسح الحالة المحلية،
    وتُفعَّل حالة إيقاف آمنة (halt) بدل الاستمرار العادي.
    يُرجع (flat: bool, message: str)."""
    try:
        live = with_retry(client.futures_position_information, symbol=symbol,
                           description=f"verify_close_{symbol}")
        qty = float(live[0].get("positionAmt", 0)) if live else 0.0
        mark_price = float(live[0].get("markPrice", 0)) if live else None
    except Exception as e:
        return False, f"تعذر قراءة المركز الحقيقي على {symbol} قبل الإغلاق: {e}"

    if qty == 0:
        _record_close_before_clear(client, symbol, exit_price_hint=mark_price, exit_type="manual")
        STORE.clear_open_position(symbol)
        return True, f"لا توجد صفقة مفتوحة فعلياً على {symbol} (تمت مزامنة الحالة المحلية)"

    try:
        side = SIDE_SELL if qty > 0 else SIDE_BUY
        # [بطلب صريح - القسم 15] نُعلِّم الإغلاق كـ"يدوي" قبل إرسال الأمر مباشرة -
        # حتى تعرف حلقة كشف الإغلاق الرئيسية لاحقاً أن هذا ليس SL/TP/Trailing
        # عادياً، دون تخمين من حالة الأوامر المتبقية.
        STORE.mark_manual_close_pending(symbol)
        create_order_idempotent(client, f"verified_close_{symbol}", symbol=symbol, side=side,
                                 type=ORDER_TYPE_MARKET, quantity=abs(qty), reduceOnly=True)
    except Exception as e:
        # فشل إرسال الأمر نفسه - لم يصل شيء إلى Binance، فالعلم اليدوي هنا
        # خاطئ ويجب تنظيفه (بعكس فشل التحقق من flat بعد الإرسال أدناه).
        STORE.clear_manual_close_pending(symbol)
        return False, f"فشل إرسال أمر إغلاق {symbol}: {e}"

    deadline = time.monotonic() + timeout_sec
    while time.monotonic() < deadline:
        time.sleep(poll_interval)
        try:
            live = with_retry(client.futures_position_information, symbol=symbol,
                               description=f"verify_close_after_{symbol}")
            qty_now = float(live[0].get("positionAmt", 0)) if live else 0.0
            mark_price_now = float(live[0].get("markPrice", 0)) if live else None
        except Exception:
            continue  # نستمر بالمحاولة حتى انتهاء المهلة
        if qty_now == 0:
            _record_close_before_clear(client, symbol, exit_price_hint=mark_price_now, exit_type="manual")
            STORE.clear_open_position(symbol)
            log_event("info", "تحقق فعلي: المركز أصبح صفراً على Binance - تم مسح الحالة المحلية", symbol=symbol)
            return True, f"تم إغلاق {symbol} وتأكيد flat فعلياً على Binance"

    # لم يُصبح flat خلال المهلة - لا نمسح الحالة المحلية إطلاقاً، ندخل حالة
    # إيقاف آمنة ونُنبّه بوضوح (بدل افتراض النجاح بصمت).
    STORE.set_halt_until(datetime.now(timezone.utc) + timedelta(hours=1))
    log_event("error", "[ALERT] لم يتأكد flat على Binance بعد أمر الإغلاق - الحالة المحلية محفوظة، تفعيل إيقاف آمن",
              symbol=symbol, timeout_sec=timeout_sec)
    notify_telegram(f"[ALERT] {symbol}: لم يتأكد الإغلاق فعلياً على Binance خلال {timeout_sec:.0f}ث - "
                     f"الحالة المحلية لم تُمسح، والبوت في وضع إيقاف آمن لمدة ساعة. تحقق يدوياً فوراً.")
    return False, f"لم يتأكد إغلاق {symbol} - تحقق يدوياً من Binance (لم تُمسح الحالة المحلية)"


def request_start_trading(client) -> str:
    """القسم 8 من تدقيق قاطع التيار: زر/أمر 'بدء التداول الآن' - يُفعّل
    التداول الجديد (يُلغي أي إيقاف مؤقت تلقائياً)، يُحدّث بيانات Binance
    الحقيقية، يفحص التغييرات الخارجية والقاطع، ثم يطلب من الحلقة الرئيسية
    فحصاً فورياً حقيقياً لكل العملات LONG وSHORT. لا يفتح أبداً صفقة وهمية
    فقط لأن الزر ضُغط؛ إن لم توجد فرصة مؤهلة سيُبلَّغ المستخدم بذلك صراحة.
    لا يتجاوز أبداً حماية Binance الحقيقية أو الحماية الكارثية الفعلية."""
    global _MANUAL_SCAN_REQUESTED, _MANUAL_SCAN_PENDING_SINCE, _TELEGRAM_PAUSED
    if not client:
        return "العميل غير جاهز (تحقق من مفاتيح Binance)"
    try:
        available = get_available_balance(client)
    except Exception as e:
        return f"تعذر التحقق من الرصيد/الاتصال بـBinance: {e}"
    if available <= 0:
        return f"الرصيد المتاح غير كافٍ حالياً ({available:.4f} USDT)"
    check_external_balance_change(client)  # مطابقة فورية قبل أي قرار
    halt_reason = check_circuit_breaker(client)
    if halt_reason:
        return (f"[!] لا يمكن تفعيل التداول: قاطع التيار مفعّل حالياً - {halt_reason}\n"
                "استخدم /breaker reset إن كنت متأكداً أن السبب تغيير خارجي وليس خسارة بوت فعلية.")
    was_paused = _TELEGRAM_PAUSED
    _TELEGRAM_PAUSED = False  # "بدء التداول" يُلغي أي إيقاف مؤقت تلقائياً
    if _MANUAL_SCAN_REQUESTED:
        return "طلب فحص فوري قيد التنفيذ بالفعل - انتظر النتيجة"
    _MANUAL_SCAN_REQUESTED = True
    _MANUAL_SCAN_PENDING_SINCE = time.time()
    resumed_note = " (كان متوقفاً مؤقتاً - تم إلغاء الإيقاف)" if was_paused else ""
    return (f"✅ تم التحقق: الرصيد المتاح={available:.4f} USDT، القاطع سليم.{resumed_note}\n"
            "جاري إجراء فحص فوري لكل العملات (LONG وSHORT) الآن - سأرسل لك النتيجة خلال لحظات.")


def handle_dashboard_callback(cq: dict, client):
    """يعالج ضغطة زر واحدة من لوحة /start أو /status (القسم 10-11) - كل
    الأزرار تُعدِّل نفس الرسالة (editMessageText) بدل إرسال رسائل جديدة
    متراكمة، وتستدعي answerCallbackQuery دائماً حتى لا يبقى الزر 'يُحمّل'."""
    global _TELEGRAM_PAUSED
    data = cq.get("data", "") or ""
    message_id = cq.get("message", {}).get("message_id")
    cq_id = cq.get("id")

    try:
        if data == "dash:starttrading":
            reply = request_start_trading(client)
            answer_telegram_callback(cq_id, "تم الإرسال" if _MANUAL_SCAN_REQUESTED else "تعذر")
            send_telegram_dashboard(reply, [[("رجوع للوحة", "dash:refresh")]], edit_message_id=message_id)

        elif data == "dash:refresh":
            send_telegram_dashboard(build_dashboard_text(client), _main_dashboard_buttons(), edit_message_id=message_id)
            answer_telegram_callback(cq_id, "تم التحديث")

        elif data == "dash:positions":
            text = build_positions_text(client)
            buttons = []
            open_positions = STORE.get_all_open_positions()
            for p in open_positions:
                buttons.append([(f"إغلاق {p['symbol']}", f"dash:close_confirm:{p['symbol']}")])
            if open_positions:
                buttons.append([("[!] إغلاق الكل", "dash:closeall_confirm")])
            buttons.append([("رجوع للوحة", "dash:refresh")])
            send_telegram_dashboard(text, buttons, edit_message_id=message_id)
            answer_telegram_callback(cq_id)

        elif data.startswith("dash:close_confirm:"):
            sym = data.split(":", 2)[2]
            text = f"[!] هل أنت متأكد من إغلاق صفقة {sym}؟"
            send_telegram_dashboard(text, [[("نعم، أغلق", f"dash:close_yes:{sym}"), ("إلغاء", "dash:positions")]],
                                     edit_message_id=message_id)
            answer_telegram_callback(cq_id)

        elif data.startswith("dash:close_yes:"):
            sym = data.split(":", 2)[2]
            answer_telegram_callback(cq_id, f"جاري إغلاق {sym}...")
            if not client:
                send_telegram_dashboard("العميل غير جاهز", [[("رجوع", "dash:refresh")]], edit_message_id=message_id)
                return
            _, msg = verified_close_position(client, sym)
            send_telegram_dashboard(msg, [[("رجوع للوحة", "dash:refresh")]], edit_message_id=message_id)

        elif data == "dash:balance":
            text = "تعذر جلب الرصيد (تحقق من الاتصال)"
            if client:
                try:
                    wallet = get_wallet_balance(client)
                    available = get_available_balance(client)
                    equity = get_account_equity(client)
                    text = (f"<b>الرصيد</b>\nمحفظة: {wallet:.4f} USDT\nمتاح: {available:.4f} USDT\n"
                            f"Equity: {equity:.4f} USDT\nغير محقق: {(equity - wallet):+.4f} USDT")
                except Exception as e:
                    text = f"تعذر جلب الرصيد: {e}"
            send_telegram_dashboard(text, [[("رجوع للوحة", "dash:refresh")]], edit_message_id=message_id)
            answer_telegram_callback(cq_id)

        elif data == "dash:trades":
            metrics = STORE.get_performance_metrics()
            text = (f"<b>صفقات اليوم</b>\n{STORE.get_today_opened_count()}" + (f"/{CFG.TARGET_TRADES_PER_DAY}" if CFG.TARGET_TRADES_PER_DAY > 0 else " (لا هدف عدد محدَّد)") + "\n\n"
                    f"<b>إجمالي منذ البداية</b>\nصفقات: {metrics.get('total_trades', 0)} | "
                    f"رابحة: {metrics.get('wins', 0)} خاسرة: {metrics.get('losses', 0)}\n"
                    f"Winrate: {metrics.get('win_rate_pct', 0)}% | PnL: {metrics.get('total_pnl_usdt', 0)} USDT")
            send_telegram_dashboard(text, [[("رجوع للوحة", "dash:refresh")]], edit_message_id=message_id)
            answer_telegram_callback(cq_id)

        elif data == "dash:symbols":
            text = f"<b>العملات المُفعّلة ({len(CFG.SYMBOLS)})</b>\n" + ", ".join(CFG.SYMBOLS)
            send_telegram_dashboard(text, [[("رجوع للوحة", "dash:refresh")]], edit_message_id=message_id)
            answer_telegram_callback(cq_id)

        elif data == "dash:signalstats":
            send_telegram_dashboard(build_signal_stats_text(), [[("رجوع للوحة", "dash:refresh")]], edit_message_id=message_id)
            answer_telegram_callback(cq_id)

        elif data == "dash:breaker":
            buttons = [
                [("🟢 BREAKER ON", "dash:breaker_on"), ("🔴 BREAKER OFF", "dash:breaker_off_confirm")],
                [("🔄 RESET BREAKER", "dash:breaker_reset"), ("📊 STATUS", "dash:breaker")],
                [("رجوع للوحة", "dash:refresh")],
            ]
            send_telegram_dashboard(format_breaker_status(), buttons, edit_message_id=message_id)
            answer_telegram_callback(cq_id)

        elif data == "dash:breaker_on":
            reply = handle_breaker_command("/breaker on", "/breaker on", client) or "تعذر التنفيذ"
            answer_telegram_callback(cq_id, "تم التشغيل")
            send_telegram_dashboard(reply, [[("رجوع", "dash:breaker")]], edit_message_id=message_id)

        elif data == "dash:breaker_off_confirm":
            text = ("⚠️ [!] BREAKER OFF إجراء إداري عالي الخطورة.\n"
                    "سيُعطَّل فقط إيقاف البرنامج الآلي (الخسائر المتتالية/التراجع اليومي) - "
                    "لن يُعطَّل: التحقق من Binance، minNotional، منع التكرار، حماية SL/TP، "
                    "أو الحماية الكارثية للحساب كله.\n"
                    "هل أنت متأكد؟")
            send_telegram_dashboard(text, [[("نعم، عطّل القاطع العادي", "dash:breaker_off_yes"), ("إلغاء", "dash:breaker")]],
                                     edit_message_id=message_id)
            answer_telegram_callback(cq_id)

        elif data == "dash:breaker_off_yes":
            reply = handle_breaker_command("/breaker off", "/breaker off", client) or "تعذر التنفيذ"
            answer_telegram_callback(cq_id, "تم التعطيل")
            send_telegram_dashboard(reply, [[("رجوع", "dash:breaker")]], edit_message_id=message_id)

        elif data == "dash:breaker_reset":
            reply = handle_breaker_command("/breaker reset", "/breaker reset", client) or "تعذر التنفيذ"
            answer_telegram_callback(cq_id, "تمت إعادة الضبط")
            send_telegram_dashboard(reply, [[("رجوع", "dash:breaker")]], edit_message_id=message_id)

        elif data == "dash:pause":
            _TELEGRAM_PAUSED = True
            answer_telegram_callback(cq_id, "تم الإيقاف المؤقت")
            send_telegram_dashboard(build_dashboard_text(client), _main_dashboard_buttons(), edit_message_id=message_id)

        elif data == "dash:resume":
            _TELEGRAM_PAUSED = False
            answer_telegram_callback(cq_id, "تم الاستئناف")
            send_telegram_dashboard(build_dashboard_text(client), _main_dashboard_buttons(), edit_message_id=message_id)

        elif data == "dash:closeall_confirm":
            text = "[!] هل أنت متأكد من إغلاق كل الصفقات المفتوحة؟\nهذا الإجراء لا يمكن التراجع عنه."
            send_telegram_dashboard(text, [[("نعم، أغلق الكل", "dash:closeall_yes"), ("إلغاء", "dash:refresh")]],
                                     edit_message_id=message_id)
            answer_telegram_callback(cq_id)

        elif data == "dash:closeall_yes":
            answer_telegram_callback(cq_id, "جاري الإغلاق...")
            if not client:
                send_telegram_dashboard("العميل غير جاهز", [[("رجوع", "dash:refresh")]], edit_message_id=message_id)
                return
            results = []
            for p in STORE.get_all_open_positions():
                _, msg = verified_close_position(client, p["symbol"])
                results.append(msg)
            text = "<b>[CLOSE ALL]</b>\n" + ("\n".join(results) if results else "لا توجد صفقات مفتوحة")
            send_telegram_dashboard(text, [[("رجوع للوحة", "dash:refresh")]], edit_message_id=message_id)

        elif data == "dash:stop_confirm":
            text = "⛔ هل أنت متأكد من إيقاف البوت نهائياً؟ سيتوقف حتى تُعيد تشغيله يدوياً من الجهاز."
            send_telegram_dashboard(text, [[("نعم، أوقف نهائياً", "dash:stop_yes"), ("إلغاء", "dash:refresh")]],
                                     edit_message_id=message_id)
            answer_telegram_callback(cq_id)

        elif data == "dash:stop_yes":
            global _TELEGRAM_STOP_REQUESTED
            _TELEGRAM_STOP_REQUESTED = True
            answer_telegram_callback(cq_id, "تم الإيقاف")
            send_telegram_dashboard("⛔ تم إرسال أمر الإيقاف النهائي.", None, edit_message_id=message_id)

        else:
            answer_telegram_callback(cq_id)
    except Exception as e:
        log_event("warning", "خطأ أثناء معالجة زر لوحة Telegram", data=data, msg=str(e))
        answer_telegram_callback(cq_id, "حدث خطأ - جرّب مجدداً")


def telegram_listener_loop(client=None):
    """حلقة استماع أوامر التليجرام مع حماية من الرسائل القديمة."""
    global _TELEGRAM_LAST_UPDATE_ID, _TELEGRAM_STOP_REQUESTED, _TELEGRAM_PAUSED
    token = os.getenv("TELEGRAM_BOT_TOKEN")
    chat_id = os.getenv("TELEGRAM_CHAT_ID")
    if not token or not chat_id:
        log_event("warning", "تليجرام غير مُعدّ - المستمع معطّل")
        return

    # تجاهل كل الرسائل القديمة عند البدء
    try:
        r = requests.get(f"https://api.telegram.org/bot{token}/getUpdates", timeout=10)
        if r.ok:
            data = r.json()
            if data.get("ok") and data.get("result"):
                _TELEGRAM_LAST_UPDATE_ID = data["result"][-1]["update_id"]
                log_event("info", "Telegram: تم تجاهل الرسائل القديمة", last_id=_TELEGRAM_LAST_UPDATE_ID)
    except Exception as e:
        log_event("warning", "فشل تهيئة last_update_id", msg=str(e))

    help_text = (
        "أوامر التحكم:\n"
        "/status أو حالة - حالة البوت والصفقات (رصيد/Equity/مراكز/جودة/قاطع)\n"
        "/stats أو إحصائيات - Winrate وProfit Factor وأفضل/أسوأ رمز\n"
        "/signalstats أو إحصائيات_الإشارات - أين اختفت كل فرصة في آخر فحص\n"
        "/symbol أو العملة - يعرض العملة/العملات التي يتداول عليها البوت الآن\n"
        "/setsymbol 1000SATSUSDT - يغيّر العملة حياً بلا إعادة تشغيل (أو /setsymbol 1000SATSUSDT,ZECUSDT لعملتين)\n"
        "/rejectstats أو إحصائيات_الرفض - إجمالي أسباب الرفض التراكمي اليوم\n"
        "/testreport أو تقرير_الاختبار - تقرير اختبار الـ3 أيام المباشر\n"
        "/balance أو رصيد - الرصيد الحالي\n"
        "/positions أو صفقات - الصفقات المفتوحة\n"
        "/symbols أو عملات - قائمة العملات المُفعّلة\n"
        "/trades أو صفقات_اليوم - عدد صفقات اليوم مقابل هدف 30\n"
        "/symbolstats [SYMBOL] أو احصاء [SYMBOL] - إحصاء لكل رمز/اتجاه (فوز/خسارة/MFE/MAE/مدة)\n"
        "/expectancy أو التوقع - Expectancy/Profit Factor حسب الرمز والاتجاه ومصدر الإشارة والساعة ونطاق الجودة\n"
        "/close SYMBOL - إغلاق صفقة رمز معين (مثال: /close BTCUSDT)\n"
        "/closeall - إغلاق كل الصفقات\n"
        "/pause أو إيقاف_مؤقت - إيقاف فتح صفقات جديدة\n"
        "/resume أو استئناف - استئناف التداول\n"
        "/breaker أو قاطع - حالة قاطع التيار\n"
        "/breaker on|off - تشغيل/إيقاف القاطع\n"
        "/breaker reset - إلغاء الإيقاف ومتابعة التداول\n"
        "/breaker pause 2 - إيقاف يدوي لساعتين\n"
        "/breaker losses 8 - حد الخسائر المتتالية\n"
        "/breaker drawdown 12 - حد التراجع اليومي %\n"
        "/breaker hours 4 - ساعات التوقف بعد القاطع\n"
        "/breaker hard on|off|20 - الحماية الحاسمة\n"
        "/stop أو إيقاف - إيقاف البوت نهائياً\n"
        "/help أو مساعدة - هذه القائمة\n"
        "/start - لوحة تحكم تفاعلية بأزرار (لوحة القيادة الاحترافية)\n"
        "/starttrading أو بدء_التداول - فحص فوري لكل العملات الآن"
    )

    while not _TELEGRAM_STOP_REQUESTED:
        try:
            params = {"offset": _TELEGRAM_LAST_UPDATE_ID + 1, "timeout": 25}
            r = requests.get(f"https://api.telegram.org/bot{token}/getUpdates", params=params, timeout=35)
            if not r.ok:
                time.sleep(5)
                continue
            data = r.json()
            if not data.get("ok"):
                time.sleep(5)
                continue

            for upd in data.get("result", []):
                _TELEGRAM_LAST_UPDATE_ID = max(_TELEGRAM_LAST_UPDATE_ID, upd["update_id"])

                cq = upd.get("callback_query")
                if cq:
                    if str(cq.get("message", {}).get("chat", {}).get("id")) != str(chat_id):
                        continue  # فقط المستخدم المُخوَّل (نفس TELEGRAM_CHAT_ID) يمكنه الضغط على الأزرار
                    handle_dashboard_callback(cq, client)
                    continue

                msg = upd.get("message") or {}
                if str(msg.get("chat", {}).get("id")) != str(chat_id):
                    continue
                text = (msg.get("text") or "").strip()
                text_lower = text.lower()

                try:
                    breaker_reply = handle_breaker_command(text, text_lower, client)
                    if text_lower in ("/help", "help", "مساعدة"):
                        notify_telegram(help_text)

                    elif text_lower == "/start":
                        send_telegram_dashboard(build_dashboard_text(client), _main_dashboard_buttons())

                    elif breaker_reply:
                        notify_telegram(breaker_reply)

                    elif text_lower in ("/status", "status", "حالة"):
                        send_telegram_dashboard(build_dashboard_text(client), _main_dashboard_buttons())

                    elif text_lower in ("/starttrading", "starttrading", "بدء_التداول"):
                        notify_telegram(request_start_trading(client))

                    elif text_lower in ("/signalstats", "signalstats", "إحصائيات_الإشارات"):
                        notify_telegram(build_signal_stats_text())

                    elif text_lower in ("/symbol", "symbol", "العملة"):
                        current = STORE.get_active_symbols()
                        notify_telegram(f"<b>العملات الحالية:</b> {', '.join(current)}\n"
                                         f"لتغييرها: /setsymbol 1000SATSUSDT أو /setsymbol 1000SATSUSDT,ZECUSDT")

                    elif text_lower.startswith("/setsymbol") or text_lower.startswith("setsymbol"):
                        # يقبل: /setsymbol SOLUSDT  أو  /setsymbol SOLUSDT,WIFUSDT  أو  /setsymbol SOLUSDT WIFUSDT
                        raw_args = text.split(None, 1)
                        if len(raw_args) < 2 or not raw_args[1].strip():
                            notify_telegram("استخدم: /setsymbol 1000SATSUSDT  (عملة واحدة تعمل عليها البوت بلا توقف)\n"
                                             "أو: /setsymbol 1000SATSUSDT,ZECUSDT (عملتان بالتوازي)")
                        else:
                            import re as _re_setsym
                            parts = _re_setsym.split(r"[,\s]+", raw_args[1].strip().upper())
                            new_symbols = tuple(dict.fromkeys(p for p in parts if p))
                            if not new_symbols or len(new_symbols) > CFG.MAX_OPEN_POSITIONS:
                                notify_telegram(f"عدد غير صالح - الحد الأقصى {CFG.MAX_OPEN_POSITIONS} عملة "
                                                 f"(MAX_OPEN_POSITIONS الحالي). أرسل /setsymbol برمز واحد أو أكثر بحد هذا العدد.")
                            else:
                                invalid = [s for s in new_symbols if not s.endswith("USDT")]
                                if invalid:
                                    notify_telegram(f"رموز غير صالحة (يجب أن تنتهي بـUSDT): {', '.join(invalid)}")
                                else:
                                    STORE.set_active_symbols(new_symbols)
                                    notify_telegram(f"✅ تم تحديث العملات إلى: {', '.join(new_symbols)}\n"
                                                     f"سيبدأ البوت بالفحص عليها من الدورة القادمة مباشرة (بلا إعادة تشغيل).")

                    elif text_lower in ("/rejectstats", "rejectstats", "إحصائيات_الرفض"):
                        today = utc_today_str()
                        counts = _DAILY_REJECT_COUNTS.get(today, {})
                        side_counts = _DAILY_SIGNAL_SIDE_COUNTS.get(today, {"BUY": 0, "SELL": 0})
                        side_total = side_counts.get("BUY", 0) + side_counts.get("SELL", 0)
                        # [بند 30] عداد اتجاه الإشارات الخام - منفصل تماماً عن أسباب
                        # الرفض أدناه، يُعرض دائماً حتى لو ما فيه رفوضات اليوم بعد.
                        side_line = (f"<b>[SIDE BIAS] إشارات خام اليوم</b>: BUY={side_counts.get('BUY', 0)} | "
                                     f"SELL={side_counts.get('SELL', 0)}"
                                     + (f" (BUY {side_counts.get('BUY', 0)/side_total*100:.0f}%)" if side_total else ""))
                        if not counts:
                            notify_telegram(f"{side_line}\n\nلا توجد رفوضات مُسجَّلة اليوم ({today}) بعد")
                        else:
                            sorted_counts = sorted(counts.items(), key=lambda kv: -kv[1])
                            total = sum(counts.values())
                            lines = [side_line, "",
                                     f"<b>[REJECT STATS] أسباب الرفض التراكمية اليوم</b> ({today})",
                                     f"الإجمالي: {total}\n"]
                            for reason, cnt in sorted_counts:
                                pct = cnt / total * 100
                                lines.append(f"{reason}: {cnt} ({pct:.1f}%)")
                            notify_telegram("\n".join(lines))

                    elif text_lower in ("/testreport", "testreport", "تقرير_الاختبار"):
                        if not client:
                            notify_telegram("العميل غير جاهز")
                        else:
                            try:
                                t_bal, t_time = STORE.get_or_init_test_baseline(get_wallet_balance(client))
                                current_wallet = get_wallet_balance(client)
                                current_available = get_available_balance(client)
                                current_equity = get_account_equity(client)
                                unrealized = current_equity - current_wallet
                                metrics = STORE.get_performance_metrics() or {}
                                peak = STORE.get_or_update_peak_balance(current_wallet, _PEAK_BALANCE_FLOOR)
                                account_dd_pct = ((peak - current_wallet) / peak * 100) if peak > 0 else 0.0
                                growth_pct = ((current_available - t_bal) / t_bal * 100) if t_bal > 0 else 0.0
                                notify_telegram(
                                    f"<b>[TEST REPORT] اختبار الـ3 أيام المباشر</b>\n"
                                    f"بداية: {t_time}\n"
                                    f"رصيد البداية: {t_bal:.4f} USDT\n"
                                    f"رصيد الآن (محفظة): {current_wallet:.4f} USDT\n"
                                    f"متاح الآن: {current_available:.4f} USDT\n"
                                    f"Equity: {current_equity:.4f} USDT | غير محقق: {unrealized:+.4f} USDT\n"
                                    f"────────────\n"
                                    f"PnL البوت المُحقَّق (إجمالي): {metrics.get('total_pnl_usdt', 0):+.4f} USDT\n"
                                    f"عدد الصفقات: {metrics.get('total_trades', 0)} "
                                    f"(رابحة={metrics.get('wins', 0)} خاسرة={metrics.get('losses', 0)})\n"
                                    f"Winrate: {metrics.get('win_rate_pct', 0)}%\n"
                                    f"إجمالي الرسوم: غير متاح كرقم منفصل (مُدمجة ضمن PnL المُحقَّق)\n"
                                    f"أقصى تراجع للبوت (من صفقاته فقط): {metrics.get('max_drawdown_usdt', 0)} USDT\n"
                                    f"تراجع الحساب الكامل (من أعلى رصيد شُوهد): {account_dd_pct:.2f}%\n"
                                    f"نمو رأس المال (Compound): {growth_pct:+.2f}%\n"
                                    f"────────────\n"
                                    f"ملاحظة: أي تغييرات خارجية/يدوية مسجَّلة تظهر برسائل [EXTERNAL] منفصلة "
                                    f"ولم تُحتسَب ضمن PnL البوت أعلاه."
                                )
                            except Exception as e:
                                notify_telegram(f"تعذر بناء تقرير الاختبار: {e}")

                    # [إصلاح حرِج - بطلب صريح من تقرير مراجعة ثانٍ] كانت كتلة
                    # STATS التالية بأكملها متداخلة صامتاً داخل فرع /testreport
                    # (خطأ مسافة بادئة) بدل ما تكون فرع elif مستقل - يعني أمر
                    # /stats لم يكن يعمل إطلاقاً رغم ظهوره في /help، وأمر
                    # /testreport كان يُخرج تقرير الاختبار + STATS معاً كل مرة.
                    elif text_lower in ("/stats", "stats", "إحصائيات"):
                        metrics = STORE.get_performance_metrics()
                        if not metrics:
                            notify_telegram("[STATS]\nلا توجد صفقات مغلقة بعد")
                        else:
                            best = metrics.get("best_symbol")
                            worst = metrics.get("worst_symbol")
                            best_txt = f"{best[0]} ({best[1]:+.4f} USDT)" if best else "-"
                            worst_txt = f"{worst[0]} ({worst[1]:+.4f} USDT)" if worst else "-"
                            pf = metrics.get("profit_factor")
                            pf_txt = f"{pf}" if pf is not None else "∞ (لا خسائر بعد)"
                            notify_telegram(
                                f"[STATS]\n"
                                f"إجمالي الصفقات: {metrics.get('total_trades', 0)} "
                                f"(رابحة={metrics.get('wins', 0)} خاسرة={metrics.get('losses', 0)})\n"
                                f"Winrate: {metrics.get('win_rate_pct', 0)}%\n"
                                f"Profit Factor: {pf_txt}\n"
                                f"إجمالي PnL: {metrics.get('total_pnl_usdt', 0)} USDT\n"
                                f"أقصى تراجع: {metrics.get('max_drawdown_usdt', 0)} USDT\n"
                                f"أفضل رمز: {best_txt}\n"
                                f"أسوأ رمز: {worst_txt}"
                            )

                    elif text_lower in ("/balance", "balance", "رصيد"):
                        if client:
                            try:
                                bal = get_available_balance(client)
                                eq = get_account_equity(client)
                                notify_telegram(f"[BALANCE]\nالرصيد المتاح: {bal:.4f} USDT\nEquity: {eq:.4f} USDT")
                            except Exception as e:
                                notify_telegram(f"خطأ في جلب الرصيد: {e}")
                        else:
                            notify_telegram("العميل غير جاهز بعد")

                    elif text_lower in ("/positions", "positions", "صفقات"):
                        open_positions = STORE.get_all_open_positions()
                        if open_positions:
                            buttons = [[(f"إغلاق {p['symbol']}", f"dash:close_confirm:{p['symbol']}")] for p in open_positions]
                            buttons.append([("[!] إغلاق الكل", "dash:closeall_confirm")])
                            send_telegram_dashboard(build_positions_text(client), buttons)
                        else:
                            notify_telegram(build_positions_text(client))

                    elif text_lower in ("/symbols", "symbols", "عملات"):
                        notify_telegram("العملات المُفعّلة:\n" + "\n".join(f"• {s}" for s in CFG.SYMBOLS))

                    elif text_lower in ("/trades", "trades", "صفقات_اليوم"):
                        opened = STORE.get_today_opened_count()
                        closed = STORE.get_today_trade_count()
                        q = adaptive_quality_threshold()
                        notify_telegram(
                            f"[TRADES] اليوم\n"
                            f"فُتحت: {opened}/{CFG.TARGET_TRADES_PER_DAY}\n"
                            f"أُغلقت: {closed}\n"
                            f"عتبة الجودة الآن: {q:.2f} (الأساس {CFG.MIN_QUALITY_SCORE_THRESHOLD:.2f} / الأرضية {CFG.MIN_QUALITY_FLOOR:.2f})\n"
                            f"مراكز مفتوحة: {len(STORE.get_all_open_positions())}/{CFG.MAX_OPEN_POSITIONS}"
                        )

                    elif text_lower.startswith("/symbolstats") or text_lower.startswith("احصاء"):
                        # [بطلب صريح - القسم 11] إحصاء لكل رمز/اتجاه: عدد
                        # الصفقات، الفوز/الخسارة، متوسط الربح، متوسط MFE/MAE،
                        # متوسط مدة الاحتفاظ - بلا أي حظر/حذف تلقائي لأي رمز.
                        parts = text.split()
                        target_sym = parts[1].upper() if len(parts) >= 2 else None
                        rows = STORE.get_symbol_stats(target_sym)
                        if not rows:
                            notify_telegram("لا توجد صفقات مُغلَقة مسجَّلة بعد لهذا الرمز/عموماً.")
                        else:
                            lines = [f"[SYMBOL STATS]" + (f" — {target_sym}" if target_sym else " — كل الرموز")]
                            for r in rows:
                                wr = (r["wins"] / r["trades"] * 100.0) if r["trades"] else 0.0
                                lines.append(
                                    f"{r['symbol']} {r['side']}: {r['trades']} صفقة "
                                    f"(فوز {r['wins']}/خسارة {r['losses']}, {wr:.0f}%) | "
                                    f"متوسط PnL={r['avg_pnl_usdt']:.3f}$ | "
                                    f"MFE≈{(r['avg_mfe_pct'] or 0)*100:.2f}% MAE≈{(r['avg_mae_pct'] or 0)*100:.2f}% | "
                                    f"مدة≈{(r['avg_held_minutes'] or 0):.0f}د"
                                )
                            notify_telegram("\n".join(lines))

                    elif text_lower in ("/expectancy", "expectancy", "التوقع"):
                        notify_telegram(build_expectancy_text())

                    elif text_lower.startswith("/close ") or text_lower.startswith("close "):
                        parts = text.split()
                        if len(parts) >= 2:
                            sym = parts[1].upper()
                            if client:
                                flat, msg = verified_close_position(client, sym)
                                notify_telegram(msg)
                            else:
                                notify_telegram("العميل غير جاهز")
                        else:
                            notify_telegram("استخدم: /close BTCUSDT")

                    elif text_lower in ("/closeall", "closeall", "إغلاق_الكل"):
                        if client:
                            results = []
                            any_failed = False
                            for p in STORE.get_all_open_positions():
                                sym = p["symbol"]
                                flat, msg = verified_close_position(client, sym)
                                results.append(msg)
                                any_failed = any_failed or not flat
                            if not results:
                                notify_telegram("لا توجد صفقات مفتوحة محلياً")
                            else:
                                notify_telegram("[CLOSE ALL]\n" + "\n".join(results) +
                                                 ("\n\n[ALERT] بعضها لم يتأكد flat - راجع الرسائل أعلاه" if any_failed else ""))
                        else:
                            notify_telegram("العميل غير جاهز")

                    elif text_lower in ("/pause", "pause", "إيقاف_مؤقت", "/stoptrading", "stoptrading", "إيقاف_التداول"):
                        _TELEGRAM_PAUSED = True
                        notify_telegram("⛔ [STOP TRADING] تم إيقاف فتح صفقات جديدة فقط.\n"
                                        "الصفقات المفتوحة حالياً تبقى محمية ومُدارة بالكامل (SL/TP/Trailing/مطابقة).\n"
                                        "استخدم ▶️ بدء التداول أو /resume للاستئناف")

                    elif text_lower in ("/resume", "resume", "استئناف"):
                        _TELEGRAM_PAUSED = False
                        notify_telegram("▶️ [RESUME] تم استئناف فتح الصفقات الجديدة والفحص")

                    elif text_lower in ("/stop", "stop", "إيقاف"):
                        _TELEGRAM_STOP_REQUESTED = True
                        notify_telegram("[STOP] جاري إيقاف البوت نهائياً...")
                        log_event("info", "إيقاف مطلوب من التليجرام")

                except Exception as cmd_err:
                    log_event("warning", "خطأ أثناء معالجة أمر تليجرام", msg=str(cmd_err))
                    notify_telegram(f"خطأ في تنفيذ الأمر: {cmd_err}")

        except Exception as e:
            log_event("warning", "خطأ في حلقة Telegram Listener", msg=str(e))
            time.sleep(8)

def _check_python_binance_algo_support():
    """فحص إقلاع (بند مُكتشَف عبر بحث حقيقي - Binance رحَّلت أوامر SL/TP
    الشرطية STOP_MARKET/TAKE_PROFIT_MARKET إلى Algo Order API اعتباراً من
    2025-12-09؛ الأوامر عبر المسار القديم /fapi/v1/order ترفض بخطأ -4120).
    مكتبة python-binance الحديثة تعيد التوجيه تلقائياً لأوامر futures_create_order
    من هذا النوع، لكن نسخة قديمة مثبَّتة قد لا تدعم ذلك.
    [تشديد - بطلب صريح من تقرير مراجعة ثالث] كان تحذيراً فقط بلا إيقاف -
    صحيح أن open_trade يحوي حماية (إغلاق طارئ + FatalBotError لو فشل SL)،
    لكن هذا يعني أول صفقة حقيقية ستُفتح فعلياً برأس مال حقيقي ثم تُغلق
    طارئاً فوراً لمجرد اختبار عطل معروف مسبقاً - رسوم/انزلاق حقيقي بلا
    داعٍ. الآن يرفض الإقلاع من الأساس لو المكتبة ناقصة، قبل أي التزام برأس
    المال إطلاقاً."""
    try:
        import binance as _binance_pkg
        version = getattr(_binance_pkg, "__version__", None)
        has_algo_method = hasattr(Client, "futures_create_algo_order")
        if not has_algo_method:
            msg = ("مكتبة python-binance المُثبَّتة (v" + str(version) + ") لا تحتوي "
                   "futures_create_algo_order - ستُرفض أوامر SL/TP الشرطية بخطأ -4120 (Binance رحَّلت "
                   "STOP_MARKET/TAKE_PROFIT_MARKET إلى Algo Order API في 2025-12-09). "
                   "رُفض الإقلاع تحوطاً قبل أي التزام برأس مال حقيقي. "
                   "نفّذ: pip install --upgrade python-binance --break-system-packages")
            log_event("error", "[تحذير إقلاع] " + msg, installed_version=version)
            raise FatalBotError(msg)
    except FatalBotError:
        raise
    except Exception:
        pass  # فحص تشخيصي فقط - أي فشل غير متوقَّع بالفحص نفسه (لا بنتيجته) لا يوقف الإقلاع


def run_bot():
    global _MANUAL_SCAN_REQUESTED, _MANUAL_SCAN_PENDING_SINCE, _LAST_SCAN_STATS
    log_event("info", f"[START] بدء تشغيل {CFG.BOT_NAME} v{CFG.SOFTWARE_VERSION}", symbols=CFG.SYMBOLS,
              leverage=CFG.LEVERAGE, testnet=CFG.USE_TESTNET, dry_run=CFG.DRY_RUN)
    _check_python_binance_algo_support()
    if not CFG.SYMBOLS:
        raise FatalBotError("لا توجد رموز تداول مفعّلة - التشغيل مرفوض")
    mode = "TESTNET" if CFG.USE_TESTNET else ("DRY_RUN" if CFG.DRY_RUN else "LIVE")
    notify_telegram(
        f"[START] {CFG.BOT_NAME} v{CFG.SOFTWARE_VERSION} يعمل | الوضع={mode}\n"
        f"مرشحو العملات ({len(CFG.SYMBOLS)}): {', '.join(CFG.SYMBOLS)} | مفضّلة: {CFG.PREFERRED_SYMBOL}\n"
        f"الإطار الزمني={CFG.TIMEFRAME} (تأكيد {CFG.HTF_TIMEFRAME}) | رافعة={CFG.LEVERAGE}x (سقف {CFG.MAX_ALLOWED_LEVERAGE}x)\n"
        f"هدف صافٍ={CFG.NET_TARGET_USDT}$ | وقف={CFG.MAX_LOSS_USDT}$ | سقف مخاطرة={CFG.MAX_RISK_PER_TRADE_EQUITY_PCT*100:.0f}% | هامش أقصى={CFG.MAX_MARGIN_PCT*100:.0f}%\n"
        f"SL/TP ديناميكي (structure/ATR) | RR أدنى={CFG.MIN_RISK_REWARD_RATIO} | مركز واحد فقط={CFG.MAX_OPEN_POSITIONS}\n"
        f"جودة دنيا={CFG.MIN_QUALITY_SCORE_THRESHOLD:.2f} (أرضية صارمة={CFG.MIN_QUALITY_FLOOR:.2f}، لا هدف عدد يومي يُجبر التداول)\n"
        f"{format_breaker_status()}\n"
        f"أرسل /help لكل الأوامر"
    )

    LOCK.acquire()

    client = load_client()
    force_config_over_db(client)
    apply_breaker_overrides()
    check_server_time_drift(client)
    check_position_mode(client)
    check_api_ip_restriction(client)

    # القسم 17: تسجيل نقطة أساس اختبار الـ3 أيام مرة واحدة فقط - لا تُستخدم
    # كأساس لحجم الصفقات إطلاقاً (ذاك دائماً 50% من availableBalance الطازجة)
    try:
        t_bal, t_time = STORE.get_or_init_test_baseline(get_wallet_balance(client))
        log_event("info", "أساس اختبار 3 أيام", test_start_balance=t_bal, test_start_time=t_time)
    except Exception as e:
        log_event("warning", "تعذر تسجيل أساس اختبار الـ3 أيام", msg=str(e))

    # بدء مستمع التليجرام مع تمرير العميل للتحكم المباشر
    t_listener = threading.Thread(target=telegram_listener_loop, args=(client,), daemon=True)
    t_listener.start()


    # filters and recovery will be per-symbol inside the loop
    # [إصلاح حرج]: تحميل فلاتر أي رمز لم يكن محمياً بـtry/except من قبل -
    # رمز واحد غير موجود فعلياً على Binance Futures (أو استجابة شبكة سيئة
    # لحظياً) كان سيرفع استثناء غير مُمسوك يوقف الإقلاع بالكامل قبل فحص أي
    # رمز آخر إطلاقاً. الآن: رمز فاشل يُسجَّل ويُستبعد وحده، والبقية تكمل.
    filters_cache = {}
    active_symbols = []
    # نحمّل فلاتر كل رموز CANDIDATE_SYMBOLS الافتراضية + أي رمز اختاره
    # المستخدم مسبقاً عبر /setsymbol (قد يكون خارج القائمة الافتراضية) -
    # حتى يعمل تبديل العملة حياً بلا إعادة تشغيل.
    startup_symbol_set = list(dict.fromkeys(
        list(CFG.CANDIDATE_SYMBOLS) + list(STORE.get_active_symbols())
        + [p["symbol"] for p in STORE.get_all_open_positions() if p.get("symbol")]))  # رموز الماسح الديناميكي التي فيها صفقة محفوظة
    for sym in startup_symbol_set:
        try:
            filters_cache[sym] = SymbolFilters(client, sym)
            active_symbols.append(sym)
        except Exception as e:
            log_event("error", "signal_rejected", symbol=sym, reason="REJECT_INVALID_SYMBOL",
                      reason_detail="تعذر تحميل فلاتر الرمز - سيُستبعد من الفحص (لا يوقف بقية الرموز)", msg=str(e))
            notify_telegram(f"[WARN] الرمز {sym} غير متاح/غير قابل للتداول على Binance Futures حالياً - سيُتجاهَل")
            continue
        try:
            recover_state_on_startup_for_symbol(client, filters_cache[sym], sym)
        except Exception as e:
            log_event("warning", f"فشل استعادة حالة {sym}", msg=str(e))

    if not active_symbols:
        raise FatalBotError("فشل تحميل فلاتر أي رمز على الإطلاق - تحقق من الاتصال بـBinance. التشغيل مرفوض.")
    if len(active_symbols) < len(CFG.SYMBOLS):
        skipped = [s for s in CFG.SYMBOLS if s not in active_symbols]
        log_event("warning", "بعض الرموز استُبعدت من هذي الجلسة", skipped=skipped, active_count=len(active_symbols))

    # فحص إضافي حاسم: امسح كل المراكز الحقيقية على المنصة (وليس فقط
    # الرموز التي لها سجل محلي محفوظ) - يعالج حالة مركز حقيقي مفتوح
    # بلا أي سجل محلي إطلاقاً (مثلاً بسبب استجابة أمر دخول غامضة سابقاً)،
    # والتي كانت ستبقى غير مكتشَفة للأبد بالاعتماد فقط على recover_state_on_startup
    # لأنها تتحقق فقط من الرموز المحفوظة محلياً مسبقاً.
    try:
        all_live_positions = with_retry(client.futures_position_information,
                                         description="startup_orphan_scan")
        for p in all_live_positions:
            live_qty = float(p.get("positionAmt", 0))
            if live_qty == 0:
                continue
            psym = p.get("symbol")
            if psym not in filters_cache:
                log_event("warning", "مركز حقيقي مفتوح على رمز خارج قائمة عملات البوت - لا يمكن إدارته تلقائياً",
                          symbol=psym, qty=live_qty)
                notify_telegram(f"[ALERT] مركز حقيقي مفتوح على {psym} (خارج قائمة عملات البوت) — راجعه يدوياً")
                continue
            if STORE.get_open_position(psym) is not None:
                continue  # هذا الرمز مُدار بالفعل عبر recover_state_on_startup أعلاه
            live_side = "BUY" if live_qty > 0 else "SELL"
            entry_price = float(p.get("entryPrice", 0) or 0)
            log_event("error", "[ALERT] مركز يتيم مكتشَف عند الإقلاع - لا سجل محلي له إطلاقاً - جاري تبنّيه وحمايته",
                      symbol=psym, side=live_side, qty=abs(live_qty), entry_price=entry_price)
            close_side = SIDE_SELL if live_side == "BUY" else SIDE_BUY
            sl_pct = CFG.FIXED_STOP_LOSS_PCT
            orphan_live_price = float(p.get("markPrice", 0) or 0)
            emergency_sl_raw = entry_price * (1 - sl_pct) if live_side == "BUY" else entry_price * (1 + sl_pct)
            emergency_sl_raw = _fresh_price_safety_adjust(filters_cache[psym], live_side, True,
                                                            emergency_sl_raw, orphan_live_price)
            emergency_sl = filters_cache[psym].round_price(emergency_sl_raw)
            try:
                new_sl = create_order_idempotent(
                    client, "adopt_orphan_sl", symbol=psym, side=close_side,
                    type=ORDER_TYPE_STOP_MARKET, stopPrice=emergency_sl, closePosition=True,
                )
                if not _verify_protective_order(client, psym, new_sl["orderId"], ORDER_TYPE_STOP_MARKET,
                                                 close_side, expected_stop_price=emergency_sl):
                    raise RuntimeError("orphan SL verification failed")

                tp_price_orphan_raw = (entry_price * (1.0 + CFG.FIXED_TAKE_PROFIT_PCT) if live_side == "BUY"
                                       else entry_price * (1.0 - CFG.FIXED_TAKE_PROFIT_PCT))
                tp_price_orphan_raw = _fresh_price_safety_adjust(filters_cache[psym], live_side, False,
                                                                  tp_price_orphan_raw, orphan_live_price)
                tp_price_orphan = (filters_cache[psym].round_price_up(tp_price_orphan_raw)
                                   if live_side == "BUY" else
                                   filters_cache[psym].round_price(tp_price_orphan_raw))
                tp_order_orphan = create_order_idempotent(
                    client, "adopt_orphan_tp", symbol=psym, side=close_side,
                    type=ORDER_TYPE_TAKE_PROFIT_MARKET, stopPrice=tp_price_orphan, closePosition=True,
                )
                tp_id_orphan = tp_order_orphan["orderId"] if _verify_protective_order(
                    client, psym, tp_order_orphan["orderId"], ORDER_TYPE_TAKE_PROFIT_MARKET,
                    close_side, expected_stop_price=tp_price_orphan) else None
                STORE.save_open_position(psym, live_side, abs(live_qty), entry_price,
                                          new_sl["orderId"], tp_id_orphan, tp_price_orphan if tp_id_orphan else None)
                notify_telegram(f"[ALERT] وُجد مركز يتيم على {psym} — تم تبنّيه وإضافة SL/TP")
            except Exception as e:
                log_event("error", "فشل تبني المركز اليتيم وحمايته - إغلاق فوري بدل تركه بلا حماية", msg=str(e))
                try:
                    create_order_idempotent(
                        client, "close_orphan_no_sl", symbol=psym, side=close_side,
                        type=ORDER_TYPE_MARKET, quantity=abs(live_qty), reduceOnly=True,
                    )
                    notify_telegram(f"[ALERT] فشلت حماية المركز اليتيم على {psym} — تم إغلاقه فوراً للحماية")
                except Exception as close_err:
                    notify_telegram(f"[ALERT][ALERT] مركز يتيم بلا حماية على {psym} وفشل إغلاقه — تدخل يدوي فوري الآن!")
                    log_event("error", "فشل إغلاق المركز اليتيم أيضاً", msg=str(close_err))
    except Exception as e:
        log_event("warning", "فشل فحص المراكز اليتيمة عند الإقلاع", msg=str(e))


    stream = KlineStream(client, CFG.SYMBOL, CFG.TIMEFRAME, CFG.LOOKBACK_CANDLES)
    user_stream = UserDataStream(client)  # طبقة مراقبة إضافية - فشلها لا يوقف البوت (انظر التوثيق بالكلاس)
    ws_fail_count = 0
    last_halt_notified = None
    last_metrics_report = time.time()
    last_duplicate_cleanup = 0.0  # يبدأ بصفر عمداً - يفحص فور وجود صفقة مفتوحة أول مرة
    last_successful_scan = time.time()  # شبكة أمان زمنية مستقلة عن صحة بث أي رمز بعينه (انظر أدناه)

    try:
        while True:
            if _TELEGRAM_STOP_REQUESTED:
                log_event("info", "إيقاف بسبب أمر تليجرام")
                break

            try:
                got_candle = stream.wait_for_new_candle(timeout=CFG.POSITION_MONITOR_INTERVAL_SEC)
                if stream.seconds_since_last_message() > CFG.MAX_WS_SILENCE_SEC:
                    raise TimeoutError("WebSocket صامت لفترة طويلة")
                ws_fail_count = 0
            except Exception as ws_err:
                ws_fail_count += 1
                log_event("error", "خطأ في WebSocket - إعادة إنشاء", attempt=ws_fail_count, msg=str(ws_err))
                try:
                    stream.stop()
                except Exception:
                    pass
                time.sleep(min(CFG.RETRY_BASE_DELAY_SEC * (2 ** min(ws_fail_count, 5)), 60))
                stream = KlineStream(client, CFG.SYMBOL, CFG.TIMEFRAME, CFG.LOOKBACK_CANDLES)
                continue

            # [إصلاح حرج - تدقيق قاطع التيار]: الإيقاف المؤقت (Pause) وقاطع
            # التيار (Breaker) يوقفان فتح صفقات جديدة فقط - لا يجوز أبداً أن
            # يوقفا إدارة الصفقات المفتوحة فعلياً (SL/TP/Trailing/المطابقة)،
            # وإلا تفقد أي صفقة مفتوحة إدارتها الحية فقط لأن التداول الجديد
            # مُعطَّل. لذلك لا "continue" هنا إطلاقاً - فقط علامة تُستخدم لاحقاً
            # لمنع فتح صفقات جديدة، بينما يستمر تنفيذ الكود أدناه (إدارة
            # المراكز) بلا أي شرط.
            halt_reason = check_circuit_breaker(client)
            if halt_reason:
                if halt_reason != last_halt_notified:
                    log_event("warning", "قاطع التيار مفعّل - صفقات جديدة مُعطَّلة، إدارة المراكز الحالية مستمرة", reason=halt_reason)
                    notify_telegram(build_halt_diagnostic_message(client, halt_reason))
                    last_halt_notified = halt_reason
            else:
                last_halt_notified = None
            trading_disabled = bool(halt_reason) or _TELEGRAM_PAUSED
            # [إصلاح - بطلب صريح من تقرير مراجعة ثانٍ] لو ضُغط "بدء التداول
            # الآن" ثم تفعّل قاطع التيار قبل الوصول لكتلة إعادة التصفير
            # (المتداخلة داخل `if not trading_disabled:` أدناه)، كان العلم
            # يبقى True للأبد طالما البوت متوقف - وهذا يُبقي أيضاً بوابة
            # "تخطَّ انتظار شمعة جديدة" مفتوحة بشكل دائم وغير مقصود. تصفير
            # بمهلة زمنية هنا (خارج أي شرط) يضمن عدم التعليق أبداً.
            if _MANUAL_SCAN_REQUESTED and time.time() - _MANUAL_SCAN_PENDING_SINCE > 60:
                _MANUAL_SCAN_REQUESTED = False
                _MANUAL_SCAN_PENDING_SINCE = 0.0
                log_event("info", "تصفير تلقائي لعلم 'بدء التداول الآن' المعلَّق (تجاوز المهلة، على الأرجح بسبب قاطع تيار)")
            check_external_balance_change(client)
            user_stream.keepalive_if_needed()

            # ---- إدارة الصفقات المفتوحة لكل الرموز ----
            all_saved = STORE.get_all_open_positions()
            for saved_position in all_saved:
                sym = saved_position["symbol"]
                filters = filters_cache.get(sym) or SymbolFilters(client, sym)
                live_position = None
                try:
                    positions = with_retry(client.futures_position_information, symbol=sym, description="multi_live")
                    for p in positions:
                        qty = float(p.get("positionAmt", 0))
                        if qty != 0:
                            live_position = {
                                "qty": abs(qty),
                                "side": "BUY" if qty > 0 else "SELL",
                                "entry_price": float(p.get("entryPrice", 0)),
                                "mark_price": float(p.get("markPrice", 0)),
                            }
                            break
                except Exception as e:
                    log_event("warning", f"تعذر جلب مركز {sym}", msg=str(e))
                    continue

                forced_close_price = None
                if live_position:
                    current_price = live_position["mark_price"]

                    # حد زمني ذكي للصفقة (القسم 4 - الخروج الذكي من الركود):
                    # لا نغلق فقط لأن المؤقت انتهى - نُقيِّم هل الصفقة ما زالت
                    # "صحية ومتحسنة" (نتركها) أم "راكدة/فقدت الزخم منذ مدة
                    # طويلة" (نغلقها)، مع سقف مطلق منفصل يمنع التجميد الأبدي.
                    opened_at_str = saved_position.get("opened_at")
                    if opened_at_str:
                        try:
                            opened_dt = datetime.fromisoformat(opened_at_str)
                            held_hours = (utc_now() - opened_dt).total_seconds() / 3600.0
                        except (ValueError, TypeError):
                            held_hours = 0.0
                        should_close_stale, stale_reason = evaluate_stale_exit(saved_position, current_price, held_hours)
                        if should_close_stale:
                            entry = saved_position["entry_price"]
                            side = saved_position["side"]
                            pnl_pct = ((current_price - entry) / entry if side == "BUY"
                                       else (entry - current_price) / entry)
                            try:
                                close_side = SIDE_SELL if side == "BUY" else SIDE_BUY
                                create_order_idempotent(
                                    client, "stale_exit_close", symbol=sym, side=close_side,
                                    type=ORDER_TYPE_MARKET, quantity=live_position["qty"], reduceOnly=True,
                                )
                                cancel_sibling_order(client, saved_position.get("sl_order_id"),
                                                      reason="stale_exit", symbol=sym)
                                cancel_sibling_order(client, saved_position.get("tp_order_id"),
                                                      reason="stale_exit", symbol=sym)
                                log_event("info", "إغلاق صفقة راكدة/تجاوزت السقف الزمني (خروج ذكي)",
                                          symbol=sym, held_hours=round(held_hours, 2), pnl_pct=round(pnl_pct * 100, 3),
                                          reason=stale_reason, peak_r=round(float(saved_position.get("peak_r") or 0.0), 2))
                                notify_telegram(f"[TIME] أُغلقت صفقة {sym} بعد {held_hours:.1f} ساعة "
                                                 f"({stale_reason}) - PnL≈{pnl_pct*100:.2f}%")
                                forced_close_price = current_price
                                live_position = None  # سيُكتشف إغلاقها بالدورة القادمة عبر resolve_closed_trade
                            except Exception as e:
                                log_event("warning", "فشل الإغلاق بسبب الركود/السقف الزمني", symbol=sym, msg=str(e))

                    if live_position:
                        try:
                            liquidation_triggered = check_liquidation_risk(client, current_price, sym)
                            if liquidation_triggered:
                                live_position = None  # أُغلق طارئاً داخل الدالة نفسها - سيُكتشف عبر resolve_closed_trade
                        except Exception as e:
                            log_event("warning", f"فشل فحص خطر التصفية لـ {sym}", msg=str(e))

                    if live_position and CFG.USE_TRAILING_STOP:
                        try:
                            manage_trailing_stop(client, filters, saved_position, current_price)
                        except Exception as e:
                            log_event("warning", f"فشل trailing لـ {sym}", msg=str(e))
                if not live_position:
                    # الصفقة أُغلقت (طبيعياً أو بسبب الركود/السقف الزمني أعلاه)
                    fallback_price = forced_close_price if forced_close_price is not None else saved_position.get("entry_price", 0)
                    known_reason = "خروج_ذكي_من_الركود" if forced_close_price is not None else None
                    try:
                        exit_price, close_reason = resolve_closed_trade(client, saved_position, fallback_price,
                                                                          known_reason=known_reason)
                        if exit_price is not None:
                            entry = saved_position["entry_price"]
                            side = saved_position["side"]
                            qty = saved_position.get("qty", 0.0)
                            pnl_pct = (exit_price - entry) / entry if side == "BUY" else (entry - exit_price) / entry
                            estimate = calculate_realized_pnl(side, entry, exit_price, qty, CFG.TAKER_FEE_RATE)
                            since_iso = saved_position.get("opened_at") or utc_iso()
                            pnl_usdt, fee_total, funding_total = get_authoritative_pnl_usdt(
                                client, since_iso, estimate_fallback=estimate, symbol=sym)
                            # [بطلب صريح - القسم 13] MFE/MAE/ذروة الربح/ذروة R/التراجع
                            # عن الذروة (giveback) - تُشتق من الحقول التي حدّثها
                            # manage_trailing_stop كل دورة مراقبة سابقة، وتُحفظ مع
                            # هذي الصفقة في trade_history للتشخيص وإحصاء كل رمز.
                            mfe_price = saved_position.get("extreme_price") or entry
                            mae_price = saved_position.get("mae_price") or entry
                            mfe_pct = (mfe_price - entry) / entry if side == "BUY" else (entry - mfe_price) / entry
                            mae_pct = (mae_price - entry) / entry if side == "BUY" else (entry - mae_price) / entry
                            peak_pnl_usdt_val = saved_position.get("peak_pnl_usdt")
                            peak_r_val = saved_position.get("peak_r")
                            giveback_usdt_val = None
                            giveback_ratio_val = None
                            if peak_pnl_usdt_val is not None and peak_pnl_usdt_val > 0:
                                giveback_usdt_val = peak_pnl_usdt_val - pnl_usdt
                                giveback_ratio_val = giveback_usdt_val / peak_pnl_usdt_val
                            try:
                                held_minutes_val = (utc_now() - datetime.fromisoformat(since_iso)).total_seconds() / 60.0
                            except (ValueError, TypeError):
                                held_minutes_val = None
                            # [بطلب صريح - القسم 15] تصنيف نوع الإغلاق: يدوي (عُلِّم
                            # صراحة عبر verified_close_position) أولاً، وإلا يُشتق
                            # من close_reason المُكتشَف فعلياً (SL/TP/المؤقت الزمني).
                            was_manual = bool(saved_position.get("manual_close_pending"))
                            if was_manual:
                                exit_type = "manual"
                            elif close_reason == "SL":
                                exit_type = "bot_trailing" if saved_position.get("trailing_active") else "bot_sl"
                            elif close_reason == "TP":
                                exit_type = "bot_tp"
                            elif close_reason == "خروج_ذكي_من_الركود":
                                exit_type = "bot_timeout"
                            elif close_reason == "circuit_breaker_emergency":
                                exit_type = "bot_circuit_breaker"
                            elif close_reason == "protection_lost_emergency":
                                exit_type = "bot_emergency_no_protection"
                            elif close_reason == "orphan_protection_failed":
                                exit_type = "bot_emergency_no_protection"
                            elif close_reason == "manual":
                                exit_type = "manual"
                            else:
                                exit_type = "unclear"
                            STORE.record_trade_result(sym, side, pnl_pct, pnl_usdt, exit_type=exit_type,
                                                       mfe_pct=mfe_pct, mae_pct=mae_pct,
                                                       peak_pnl_usdt=peak_pnl_usdt_val, peak_r=peak_r_val,
                                                       giveback_usdt=giveback_usdt_val, giveback_ratio=giveback_ratio_val,
                                                       held_minutes=held_minutes_val,
                                                       signal_source=saved_position.get("signal_source"),
                                                       quality_score=saved_position.get("quality_score"))
                            STORE.clear_open_position(sym)
                            _TRAIL_FAIL_STREAK.pop(sym, None)  # [Glama 4] تنظيف عدّاد فشل الوقف المتحرك بعد إغلاق الصفقة
                            STORE.set_symbol_cooldown(sym, CFG.COOLDOWN_AFTER_CLOSE_MINUTES)
                            log_event("info", "symbol_cooldown_started", symbol=sym,
                                      minutes=CFG.COOLDOWN_AFTER_CLOSE_MINUTES)
                            side_ar = "ش" if side == "BUY" else "ب"
                            emoji = "[OK]" if pnl_usdt >= 0 else "[FAIL]"
                            reason_ar = {"SL": "وقف خسارة", "TP": "جني ربح",
                                         "خروج_ذكي_من_الركود": "خروج ذكي (ركود/سقف زمني)",
                                         "circuit_breaker_emergency": "إغلاق طارئ (قاطع التيار)",
                                         "protection_lost_emergency": "إغلاق طارئ (فقد الحماية/SL)",
                                         "orphan_protection_failed": "إغلاق طارئ (فشل تبني مركز يتيم)",
                                         "manual": "إغلاق يدوي",
                                         "unclear": "غير واضح (راجع اللوج)"}.get(close_reason, close_reason)
                            try:
                                held_str = f"{(utc_now() - datetime.fromisoformat(since_iso)).total_seconds() / 60:.0f} دقيقة"
                            except (ValueError, TypeError):
                                held_str = "؟"
                            # [بطلب صريح] سجل شامل لكل صفقة مُغلَقة: exit_reason،
                            # net_pnl (الحقيقي من Binance)، fee، funding_fee منفصلَين،
                            # بالإضافة إلى MFE/MAE/ذروة الربح/ذروة R/التراجع (giveback).
                            log_event("info", "trade_closed", symbol=sym, side=side, exit_reason=close_reason,
                                      exit_type=exit_type,
                                      entry_price=entry, exit_price=exit_price, pnl_pct=round(pnl_pct * 100, 3),
                                      net_pnl=round(pnl_usdt, 4),
                                      fee=(round(fee_total, 4) if fee_total is not None else None),
                                      funding_fee=(round(funding_total, 4) if funding_total is not None else None),
                                      held_minutes=held_str, mfe_pct=round(mfe_pct * 100, 3), mae_pct=round(mae_pct * 100, 3),
                                      peak_pnl_usdt=(round(peak_pnl_usdt_val, 4) if peak_pnl_usdt_val is not None else None),
                                      peak_r=(round(peak_r_val, 2) if peak_r_val is not None else None),
                                      giveback_usdt=(round(giveback_usdt_val, 4) if giveback_usdt_val is not None else None),
                                      giveback_ratio=(round(giveback_ratio_val, 3) if giveback_ratio_val is not None else None))
                            giveback_line = ""
                            if giveback_ratio_val is not None and giveback_ratio_val >= CFG.LARGE_GIVEBACK_WARN_RATIO:
                                giveback_line = (f"\n[!] تراجع {giveback_ratio_val*100:.0f}% عن ذروة ربح "
                                                  f"{peak_pnl_usdt_val:.3f} USDT (R الذروة={peak_r_val:.2f})")
                            notify_telegram(
                                f"{emoji} أُغلقت صفقة {side_ar} على {sym} — السبب: {reason_ar}\n"
                                f"الدخول: {entry:.6g} | الخروج: {exit_price:.6g} | المدة: {held_str}\n"
                                f"PnL={pnl_pct*100:.2f}% ({pnl_usdt:.3f} USDT){giveback_line}"
                            )
                    except Exception as e:
                        log_event("warning", f"فشل معالجة إغلاق {sym}", msg=str(e))

            # فحص جديد للإشارات يحدث عند إغلاق شمعة BTC (كفاءة API طبيعية -
            # كل الرموز تُغلق شموعها بنفس التوقيت العالمي فعلياً). لكن لو
            # تعطّل بث BTC تحديداً بأي شكل واستمر التعطل لأطول من مدة
            # الفريم بمهلة أمان، لا نسمح لهذا التعطل بمنع فحص كل العملات
            # الأخرى إلى الأبد - نفحص بالتوقيت الفعلي كشبكة أمان مستقلة.
            # BUG-08: حساب ثواني الفريم ديناميكياً من نص CFG.TIMEFRAME بدل قاموس ثابت
            # يفرض 15m كافتراضي لأي صيغة غير مدرجة.
            def _timeframe_to_seconds(tf: str) -> int:
                tf = (tf or "").strip().lower()
                unit_map = {"m": 60, "h": 3600, "d": 86400, "w": 604800}
                if len(tf) >= 2 and tf[-1] in unit_map:
                    try:
                        return int(tf[:-1]) * unit_map[tf[-1]]
                    except ValueError:
                        pass
                # fallback آمن معروف
                return {"1m": 60, "3m": 180, "5m": 300, "15m": 900, "30m": 1800,
                        "1h": 3600, "4h": 14400}.get(tf, 900)

            timeframe_sec = _timeframe_to_seconds(CFG.TIMEFRAME)
            stale_for = time.time() - last_successful_scan
            if not got_candle and not _MANUAL_SCAN_REQUESTED and stale_for < timeframe_sec + 60:
                continue
            if not got_candle and not _MANUAL_SCAN_REQUESTED:
                log_event("warning", "لم يُكتشف إغلاق شمعة BTC خلال مدة أطول من الفريم - فحص احتياطي بالتوقيت الفعلي بدل الانتظار له تحديداً",
                          stale_seconds=round(stale_for))
            last_successful_scan = time.time()

            # ---- فحص الإشارات على كل العملات ----
            if not trading_disabled:
                # المرحلة 1: اجمع كل الإشارات المؤهلة (اجتازت كل الفلاتر) من كل
                # العملات بهذي الدورة أولاً - بدون فتح أي صفقة فوراً - عشان لو
                # أكثر من عملة عندها إشارة قوية بنفس اللحظة، نختار الأفضل بينها
                # بدل أول عملة بترتيب القائمة فقط.
                candidates = []
                remaining_slots = CFG.MAX_OPEN_POSITIONS - len(STORE.get_all_open_positions())
                scan_stats = {"total": 0, "no_signal": 0, "htf_conflict": 0, "insufficient_margin": 0,
                              "funding": 0, "atr_too_small": 0, "candidates": 0, "opened": 0,
                              "quality_failed": 0, "open_trade_attempted": 0, "open_trade_failed": 0}
                quality_now = adaptive_quality_threshold()
                log_event("info", "scan_quality_threshold", threshold=round(quality_now, 3),
                          opened_today=STORE.get_today_opened_count(), target=CFG.TARGET_TRADES_PER_DAY)

                if remaining_slots <= 0:
                    log_event("info", "signal_rejected", reason="REJECT_MAX_POSITIONS",
                              reason_detail="max_open_positions_reached",
                              open_positions=len(STORE.get_all_open_positions()),
                              max_positions=CFG.MAX_OPEN_POSITIONS)

                if remaining_slots > 0:
                    # ---- تفعيل الماسح الديناميكي للعملات لمنع الخمول ----
                    if CFG.ENABLE_DYNAMIC_SCANNER:
                        live_symbols = update_dynamic_active_symbols(client)
                    else:
                        live_symbols = STORE.get_active_symbols()
                    for sym in live_symbols:
                        # تحميل فلاتر أي رمز جديد اختاره المستخدم للتو عبر
                        # /setsymbol ولم يكن محمَّلاً وقت الإقلاع - بلا حاجة لإعادة تشغيل.
                        if sym not in filters_cache:
                            try:
                                filters_cache[sym] = SymbolFilters(client, sym)
                                log_event("info", "تحميل فلاتر رمز جديد حياً (اختيار المستخدم)", symbol=sym)
                            except Exception as e:
                                log_event("error", "signal_rejected", symbol=sym, reason="REJECT_INVALID_SYMBOL",
                                          reason_detail="تعذر تحميل فلاتر الرمز المختار حياً", msg=str(e))
                                continue
                        if STORE.get_open_position(sym) is not None:
                            continue
                        # [إصلاح - بند 52] فحص انجراف الرافعة لكل رمز فعلياً (كان
                        # كوداً ميتاً غير مُستدعى، ولو استُدعي سابقاً كان يفحص رمزاً
                        # واحداً ثابتاً فقط). يُخفَّف بذاكرة مؤقتة (كل 10 دقائق لكل
                        # رمز) تفادياً لإضافة طلب REST إضافي بكل دورة فحص لكل رمز.
                        _last_lev_check = _LEVERAGE_CHECK_CACHE.get(sym, 0.0)
                        if time.time() - _last_lev_check > 600:
                            _LEVERAGE_CHECK_CACHE[sym] = time.time()
                            check_leverage_drift(client, sym)
                        in_cd, cd_until = STORE.is_symbol_in_cooldown(sym)
                        if in_cd:
                            log_event("info", "signal_rejected", symbol=sym,
                                      reason="REJECT_SYMBOL_COOLDOWN",
                                      cooldown_until=cd_until.isoformat() if cd_until else None)
                            continue
                        try:
                            # فلتر السيولة: حجم التداول ربع اليومي (بالعملة المقتبسة)
                            # يجب ألا يقل عن MIN_24H_QUOTE_VOLUME_USDT (بند 3/10) -
                            # يُستبعد الرمز من الفحص هذي الدورة فقط، لا يوقف بقية المرشحين.
                            try:
                                ticker_24h = with_retry(client.futures_ticker, symbol=sym,
                                                         description=f"ticker24h_{sym}")
                                quote_vol_24h = float(ticker_24h.get("quoteVolume", 0) or 0)
                            except Exception:
                                quote_vol_24h = None
                            if quote_vol_24h is not None and quote_vol_24h < CFG.MIN_24H_QUOTE_VOLUME_USDT:
                                log_event("info", "signal_rejected", symbol=sym, reason="REJECT_LOW_24H_VOLUME",
                                          reason_detail="quote_volume_below_minimum",
                                          quote_volume_24h=round(quote_vol_24h, 2),
                                          min_required=CFG.MIN_24H_QUOTE_VOLUME_USDT)
                                continue

                            if sym == CFG.SYMBOL:
                                df_sig = stream.get_df()
                            else:
                                klines = with_retry(client.futures_klines, symbol=sym, interval=CFG.TIMEFRAME,
                                                     limit=CFG.LOOKBACK_CANDLES, description=f"klines_{sym}")
                                if not klines or len(klines) < 30:
                                    continue
                                df_sig = pd.DataFrame(klines, columns=[
                                    "open_time","open","high","low","close","volume",
                                    "close_time","quote_vol","trades","taker_buy_base","taker_buy_quote","ignore"
                                ])
                                for col in ["open", "high", "low", "close", "volume", "taker_buy_base",
                                            "open_time", "close_time"]:
                                    df_sig[col] = pd.to_numeric(df_sig[col], errors="coerce")
                                df_sig["taker_sell_base"] = df_sig["volume"] - df_sig["taker_buy_base"]
                                # إصلاح حرج (BUG-01): close_time و open_time يجب تحويلهما رقمياً
                                # قبل المقارنة مع now_ms، وإلا TypeError: '<=' not supported
                                # between instances of 'str' and 'int' ويانهار فحص كل الرموز الثانوية.
                                # futures_klines يُرجع أيضاً الشمعة الحية الحالية غير المغلقة كآخر صف -
                                # نفس ما تفعله KlineStream لـBTC بفلترة close_time <= الآن.
                                now_ms = int(time.time() * 1000)
                                df_sig = df_sig.dropna(subset=["open_time", "close_time", "close"]).reset_index(drop=True)
                                df_sig = df_sig[df_sig["close_time"].astype("int64") <= now_ms].reset_index(drop=True)

                            if df_sig is None or len(df_sig) < 30:
                                log_event("info", "signal_rejected", symbol=sym, reason="REJECT_STALE_DATA",
                                          reason_detail="insufficient_closed_candles")
                                continue
                            last_closed_candle_time = int(df_sig["open_time"].iloc[-1])

                            ref_price = float(df_sig["close"].iloc[-1])
                            result = detect_signal(df_sig)
                            signal = result[0] if result else None
                            log_event("info", "scan_symbol", symbol=sym, signal=signal, price=ref_price,
                                      candle_time=last_closed_candle_time)
                            scan_stats["total"] += 1
                            if not result:
                                scan_stats["no_signal"] += 1
                                continue
                            signal, partial_score, signal_source, signal_diag = result

                            # === [بطلب صريح - ملف الإصلاحات المتوازنة] تأكيد
                            # الشمعة بعد Sweep - مسار sweep فقط، رفض قاطع ===
                            # DIAGNOSTIC_MODE يتجاوز هذا الفلتر تحديداً فقط
                            # (بند 3 من تقرير التشخيص) - كل فلاتر المخاطرة
                            # الأخرى (SL/TP/حجم الصفقة/قاطع التيار) لا تتأثر.
                            if signal_source == "sweep" and CFG.REQUIRE_SWEEP_CONFIRMATION and not CFG.DIAGNOSTIC_MODE:
                                sweep_ok, sweep_reason = confirm_sweep_reversal(df_sig, signal)
                                if not sweep_ok:
                                    log_event("info", "signal_rejected", symbol=sym, reason="REJECT_SWEEP_NO_CONFIRM",
                                              reason_detail=sweep_reason, signal=signal, signal_source=signal_source)
                                    continue

                            # === [بطلب صريح - ملف الإصلاحات المتوازنة] فلتر
                            # زخم ضد السيولة الكاذبة - رفض قاطع لكل المصادر ===
                            momentum_ok, momentum_reason = check_recent_momentum(df_sig, signal)
                            if not momentum_ok:
                                log_event("info", "signal_rejected", symbol=sym, reason="REJECT_FAKE_SWEEP_MOMENTUM",
                                          reason_detail=momentum_reason, signal=signal, signal_source=signal_source)
                                continue

                            # === [Glama 6 - بطلب صريح بعد خسائر متتالية]
                            # فلتر اتجاه متوسط الأمد على إطار التنفيذ نفسه -
                            # يمنع "شراء منتصف انهيار متواصل" (dead-cat
                            # bounce) حتى لو كان اتجاه 1H لا يزال معنوناً
                            # صاعداً/محايداً بالحد الأدنى. يُطبَّق فقط على
                            # المصادر العكسية (تراهن على انعكاس فعلي) ===
                            if signal_source in ("sweep", "exhaustion_reversal", "sr_touch"):
                                mid_ok, mid_reason = _mid_term_trend_conflict(df_sig, signal)
                                if not mid_ok:
                                    log_event("info", "signal_rejected", symbol=sym, reason="REJECT_MID_TERM_TREND_CONFLICT",
                                              reason_detail=mid_reason, signal=signal, signal_source=signal_source)
                                    continue

                            # === فلتر اتجاه 1H (بطلب صريح - مُعدَّل لزيادة
                            # النشاط) === يرفض فقط عند تعارض صريح ومباشر مع
                            # الاتجاه الأعلى (BUY مقابل هبوط واضح، أو العكس).
                            # NEUTRAL لم يعد يرفض - يصبح محايداً بلا مكافأة
                            # ولا عقوبة (السوق العرضي لا يعني بالضرورة عكس
                            # الإشارة، فقط عدم وجود اتجاه واضح لتأكيدها).
                            # فشل API (None) → رفض إن كان FAIL_CLOSED_MARKET_CHECKS=True.
                            htf_trend = higher_timeframe_trend(client, sym)
                            if htf_trend is None:
                                if CFG.FAIL_CLOSED_MARKET_CHECKS:
                                    log_event("info", "signal_rejected", symbol=sym, reason="REJECT_HTF_CONFLICT", reason_detail="htf_api_failed_fail_closed",
                                              signal=signal, signal_source=signal_source)
                                    scan_stats["htf_conflict"] += 1
                                    continue
                                log_event("warning", "تعذر جلب اتجاه 1H - سماح احتياطي (Fail-Open، غير موصى به)",
                                          symbol=sym, signal=signal)
                            elif htf_trend != "NEUTRAL" and htf_trend != signal:
                                log_event("info", "signal_rejected", symbol=sym, reason="REJECT_HTF_CONFLICT", reason_detail="htf_opposite",
                                          signal=signal, signal_source=signal_source, htf_trend=htf_trend)
                                scan_stats["htf_conflict"] += 1
                                continue
                            htf_bonus = 0.10 if htf_trend == signal else 0.0  # مكافأة ترتيب فقط لو الاتجاه الأعلى مؤكِّد صراحة

                            # ارتباط مع BTC + قوة نسبية (Relative Strength) - نقاط
                            # فقط، ليس رفضاً. [Glama 4 - بند 12 من تقرير التطوير]
                            # أُضيفت مكافأة تناظرية لعقوبة معارضة BTC الأصلية:
                            # عملة تحافظ على قوتها النسبية باتجاه الإشارة أثناء
                            # ضعف/تعارض BTC تحديداً تستحق أولوية أعلى (قوة حقيقية
                            # وليست مجرد انعكاس حركة BTC).
                            # [إصلاح بند 5 من المواصفة - حرِج] لم يعد يُستخدم
                            # stream.get_df() (بيانات الرمز الرئيسي المتداول
                            # حالياً) كبديل صامت عن BTC - الآن مصدر صريح ومستقل
                            # عبر get_btc_reference_df() يجلب BTCUSDT حصراً،
                            # حتى لو كان الرمز المتداول حالياً غير BTCUSDT.
                            btc_penalty = 0.0
                            relative_strength_bonus = 0.0
                            if sym != "BTCUSDT":
                                try:
                                    btc_df = get_btc_reference_df(client, CFG.LOOKBACK_CANDLES)
                                    if btc_df is not None and len(btc_df) >= 4:
                                        btc_momentum = (float(btc_df["close"].iloc[-1]) - float(btc_df["close"].iloc[-4])) / float(btc_df["close"].iloc[-4])
                                        btc_move_strong = abs(btc_momentum) >= 0.008  # 0.8% خلال آخر 3 شموع = زخم معتبر
                                        opposing = (btc_momentum > 0 and signal == "SELL") or (btc_momentum < 0 and signal == "BUY")
                                        if btc_move_strong and opposing:
                                            btc_penalty = 0.12
                                            log_event("info", "btc_correlation_lower_priority", symbol=sym,
                                                      reason="REJECT_BTC_CORRELATION", reason_detail="btc_correlation", signal=signal,
                                                      btc_momentum_pct=round(btc_momentum * 100, 3))
                                        elif len(df_sig) >= 4:
                                            own_momentum = (float(df_sig["close"].iloc[-1]) - float(df_sig["close"].iloc[-4])) / float(df_sig["close"].iloc[-4])
                                            own_agrees = (own_momentum > 0 and signal == "BUY") or (own_momentum < 0 and signal == "SELL")
                                            # العملة تتحرك بوضوح مع الإشارة، بينما BTC إما هادئ
                                            # أو يتحرك أضعف بكثير بنفس الاتجاه/عكسه - قوة نسبية حقيقية
                                            outperforming = own_agrees and abs(own_momentum) >= 0.006 and abs(own_momentum) >= abs(btc_momentum) * 1.5
                                            if outperforming:
                                                relative_strength_bonus = 0.06
                                                log_event("info", "relative_strength_bonus", symbol=sym, signal=signal,
                                                          own_momentum_pct=round(own_momentum * 100, 3),
                                                          btc_momentum_pct=round(btc_momentum * 100, 3))
                                except Exception as e:
                                    log_event("warning", "تعذر فحص الارتباط/القوة النسبية مع BTC - سيُسمح بالإشارة بلا هذا الفلتر", msg=str(e))

                            filters_sym = filters_cache.get(sym) or SymbolFilters(client, sym)
                            if not check_minimum_margin(client, filters_sym):
                                log_event("info", "signal_rejected", symbol=sym, reason="REJECT_INSUFFICIENT_MARGIN",
                                          reason_detail="insufficient_margin", signal=signal)
                                scan_stats["insufficient_margin"] += 1
                                continue

                            funding_warning = check_funding_rate(client, signal, symbol=sym)
                            if funding_warning:
                                log_event("info", "signal_rejected", symbol=sym, reason="REJECT_FUNDING",
                                          reason_detail="funding_rate_unfavorable", signal=signal)
                                scan_stats["funding"] += 1
                                continue

                            # مقياس حركة ATR الحقيقية (raw_tp_pct) - فلتر معتدل أُعيد
                            # تفعيله بطلب صريح (MIN_ATR_TO_FEE_RATIO=1.5): يرفض فقط
                            # الحالات الهامدة فعلاً حيث حركة ATR المتوقعة لا تغطي
                            # حتى 1.5 ضعف تكلفة العمولة ذهاباً وإياباً - ويبقى
                            # atr_quality أدناه مكوّن ترتيب إضافي لمن اجتاز الفلتر.
                            atr = calculate_atr(df_sig)
                            round_trip_fee_cost = (CFG.TAKER_FEE_RATE * 2) + CFG.SLIPPAGE_BUFFER_PCT
                            raw_tp_pct = (atr * 3.0) / ref_price if atr > 0 else 0.0

                            if atr <= 0 or raw_tp_pct < round_trip_fee_cost * CFG.MIN_ATR_TO_FEE_RATIO:
                                log_event("info", "signal_rejected", symbol=sym, reason="REJECT_LOW_ATR", reason_detail="atr_too_small", signal=signal,
                                          raw_tp_pct=round(raw_tp_pct * 100, 4),
                                          required_pct=round(round_trip_fee_cost * CFG.MIN_ATR_TO_FEE_RATIO * 100, 4),
                                          atr=round(atr, 8))
                                scan_stats["atr_too_small"] += 1
                                continue

                            atr_quality = min(raw_tp_pct / (round_trip_fee_cost * CFG.MIN_ATR_TO_FEE_RATIO * 2), 1.0) * 0.15
                            sweep_priority_bonus = 0.05 if signal_source == "sweep" else 0.0
                            final_score = min(max(
                                partial_score + htf_bonus + atr_quality + sweep_priority_bonus + relative_strength_bonus - btc_penalty,
                                0.0), 1.0)
                            grade = "A" if final_score >= 0.75 else ("B" if final_score >= quality_now else "C")

                            # === تصنيف نظام التقلب (Volatility Regime) - بطلب صريح ===
                            # ليس فلتراً قاتلاً جديداً (لا يرفض أي إشارة) - فقط
                            # يُستخدم لاحقاً في open_trade لتشديد Risk Gate إضافياً
                            # وقت التقلب الشديد تحديداً (حماية إضافية ذكية، لا
                            # حظر تعسفي لكل الصفقات وقت تقلب عادي أو مرتفع).
                            atr_pct_of_price = (atr / ref_price) if ref_price > 0 else 0.0
                            if atr_pct_of_price < 0.003:
                                volatility_regime = "quiet"
                            elif atr_pct_of_price < 0.008:
                                volatility_regime = "normal"
                            elif atr_pct_of_price < 0.015:
                                volatility_regime = "high"
                            else:
                                volatility_regime = "extreme"

                            # === سجل شامل موحَّد لكل إشارة (بطلب صريح) - يُكتب
                            # سواء قُبلت الإشارة أو رُفضت، بكل الحقول المطلوبة
                            # للتشخيص: لماذا فُتحت صفقة عكسية أو لماذا رُفضت. ===
                            passed_quality = final_score >= quality_now
                            log_event("info", "signal_evaluated", symbol=sym, side=signal,
                                      signal_source=signal_source, quality_score=round(final_score, 4),
                                      htf_trend=htf_trend, amb_direction=signal_diag.get("amb_direction"),
                                      bb_percent=signal_diag.get("bb_percent"),
                                      volume_ratio=signal_diag.get("volume_ratio"),
                                      delta=signal_diag.get("delta"),
                                      reason=("accepted_as_candidate" if passed_quality else "quality_too_low"))

                            if final_score < quality_now:
                                log_event("info", "signal_rejected", symbol=sym, reason="REJECT_LOW_QUALITY", reason_detail="quality_too_low",
                                          signal=signal, signal_source=signal_source, grade=grade,
                                          final_score=round(final_score, 3),
                                          min_required=quality_now,
                                          htf_trend=htf_trend, btc_penalty=btc_penalty,
                                          relative_strength_bonus=relative_strength_bonus)
                                scan_stats["quality_failed"] += 1
                                continue
                            # SL/TP الفعليان يُحسبان ديناميكياً داخل open_trade
                            # (structure/ATR) - هذا الحقل هنا معلوماتي فقط للّوج/الترتيب.
                            tp_pct = None
                            quality_label = f"Score={final_score:.2f} Grade={grade} [{signal_source}] RSI={signal_diag.get('rsi')} Regime={signal_diag.get('volatility_regime')} (SL/TP ديناميكي)"

                            scan_stats["candidates"] += 1
                            candidates.append({
                                "symbol": sym, "signal": signal, "ref_price": ref_price,
                                "df": df_sig, "filters": filters_sym, "tp_pct": tp_pct,
                                "quality_label": quality_label, "rank_score": final_score,
                                "signal_source": signal_source, "grade": grade,
                                "volatility_regime": volatility_regime,
                            })
                        except Exception as e:
                            log_event("warning", "signal_rejected", symbol=sym, reason="REJECT_EXCEPTION",
                                      reason_detail=f"فشل فحص {sym}", msg=str(e))

                # المرحلة 2: رتّب المؤهلين تنازلياً حسب درجة الجودة النهائية
                # (rank_score) - تجمع توافق الاتجاه الأعلى + قوة الحجم/الدلتا +
                # عمق التشبع بالبولنجر + جودة حركة ATR نسبة للعمولة. لا تفوز
                # عملة بسبب حركة خام كبيرة فقط دون سياق - ولا لأنها BTC أو أول
                # عملة بالقائمة، الترتيب مستقل تماماً عن ترتيب CFG.SYMBOLS.
                candidates.sort(key=lambda c: c["rank_score"], reverse=True)
                signals_opened_this_scan = 0
                max_to_open = min(CFG.MAX_SIGNALS_PER_SCAN, remaining_slots)

                for cand in candidates:
                    if signals_opened_this_scan >= max_to_open:
                        log_event("info", "signal_rejected", symbol=cand["symbol"], reason="lower_quality_than_other_candidate",
                                  quality_score=round(cand["rank_score"], 3))
                        break
                    sym = cand["symbol"]
                    signal = cand["signal"]
                    ref_price = cand["ref_price"]
                    side_ar = "ش" if signal == "BUY" else "ب"
                    _tp_display = f"{cand['tp_pct']*100:.1f}%" if cand.get("tp_pct") else "ديناميكي (structure/ATR)"
                    notify_telegram(f"[SIGNAL] إشارة {side_ar} على {sym} @ {ref_price:.6g} "
                                     f"(جودة {cand['quality_label']}، Score={cand['rank_score']:.2f}, "
                                     f"TP={_tp_display}) — جاري التنفيذ...")
                    try:
                        scan_stats["open_trade_attempted"] += 1
                        opened = open_trade(client, cand["filters"], signal, ref_price, symbol=sym,
                                             df=cand["df"], tp_pct_override=cand["tp_pct"],
                                             signal_source=cand.get("signal_source"),
                                             volatility_regime=cand.get("volatility_regime", "normal"),
                                             signal_grade=cand.get("grade", "A"),
                                             quality_score=cand.get("rank_score"))
                        if opened:
                            signals_opened_this_scan += 1
                        else:
                            scan_stats["open_trade_failed"] += 1
                            log_event("info", "signal_rejected", symbol=sym, reason="open_trade_failed_internally", signal=signal)
                    except Exception as e:
                        scan_stats["open_trade_failed"] += 1
                        log_event("warning", f"فشل فتح صفقة على {sym}", msg=str(e))

                scan_stats["opened"] = signals_opened_this_scan
                scan_stats["timestamp"] = utc_iso()
                _LAST_SCAN_STATS = dict(scan_stats)  # نسخة - لعرضها عبر /signalstats من ثريد تيليجرام المنفصل
                log_event("info", "scan_summary",
                          total_scanned=scan_stats["total"], no_signal=scan_stats["no_signal"],
                          rejected_htf=scan_stats["htf_conflict"], rejected_margin=scan_stats["insufficient_margin"],
                          rejected_funding=scan_stats["funding"], rejected_atr_fee=scan_stats["atr_too_small"],
                          candidates_found=scan_stats["candidates"], trades_opened=scan_stats["opened"])

                # القسم 21: لو كانت هذي الدورة استجابة لضغطة "بدء التداول الآن"
                # من تيليجرام، أرسل تقريراً فورياً بالنتيجة الحقيقية - سواء
                # صفقة فُتحت فعلاً أو لا توجد فرصة مؤهلة الآن (بلا أي صفقة
                # وهمية/عشوائية لمجرد أن الزر ضُغط).
                if _MANUAL_SCAN_REQUESTED:
                    _MANUAL_SCAN_REQUESTED = False
                    if scan_stats["opened"] > 0:
                        notify_telegram(f"[OK] فحص فوري: تم فتح {scan_stats['opened']} صفقة مؤهلة. راجع /positions")
                    elif remaining_slots <= 0:
                        notify_telegram(f"لم يُجرَ فحص جديد: عدد المراكز المفتوحة بالفعل وصل للحد الأقصى "
                                         f"({CFG.MAX_OPEN_POSITIONS}). أغلق صفقة أولاً أو انتظر إغلاقها.")
                    else:
                        notify_telegram(
                            "🔍 لم أجد فرصة تداول مؤهلة الآن.\n"
                            f"تم فحص: {scan_stats['total']} رمز | مرشحون بعد الفلاتر: {scan_stats['candidates']}\n"
                            f"أهم أسباب الرفض: بلا إشارة={scan_stats['no_signal']}, "
                            f"HTF={scan_stats['htf_conflict']}, ATR/رسوم={scan_stats['atr_too_small']}, "
                            f"Funding={scan_stats['funding']}, هامش غير كافٍ={scan_stats['insufficient_margin']}, "
                            f"جودة غير كافية={scan_stats['quality_failed']}\n"
                            "سيستمر البوت بالفحص تلقائياً."
                        )

            # تقرير دوري
            if time.time() - last_metrics_report > CFG.METRICS_REPORT_INTERVAL_HOURS * 3600:
                metrics = STORE.get_performance_metrics() or {}
                try:
                    bal = get_available_balance(client)
                    eq = get_account_equity(client)
                except Exception:
                    bal, eq = 0.0, 0.0
                open_count = len(STORE.get_all_open_positions())
                mins_since_scan = (time.time() - last_successful_scan) / 60.0
                last_scan_summary = _LAST_SCAN_STATS
                # [بطلب صريح - نبضة قلب]: يميّز "لا صفقات لأن السوق ما فيه فرص
                # مؤهلة" عن "البوت متوقف/معلَّق فعلياً" - يعرض آخر وقت فحص ناجح
                # وعدد الرموز التي فُحصت فعلاً بآخر دورة، بصرف النظر عن نتيجتها.
                report = (
                    f"💓 [HEARTBEAT] البوت حي ويعمل\n"
                    f"آخر فحص ناجح: منذ {mins_since_scan:.0f} دقيقة | "
                    f"آخر عدد رموز فُحصت: {last_scan_summary.get('total', '؟')}\n"
                    f"الرصيد: {bal:.2f} | Equity: {eq:.2f} USDT\n"
                    f"صفقات مفتوحة: {open_count}\n"
                    f"إجمالي الصفقات: {metrics.get('total_trades', 0)} | "
                    f"فوز: {metrics.get('wins', 0)} | خسارة: {metrics.get('losses', 0)}\n"
                    f"نسبة الفوز: {metrics.get('win_rate_pct', 0)}% | "
                    f"PnL: {metrics.get('total_pnl_usdt', 0)} USDT\n"
                    f"الرافعة: {CFG.LEVERAGE}x | الفريم: {CFG.TIMEFRAME}\n"
                    f"{format_breaker_status()}"
                )
                log_event("info", "تقرير أداء دوري / نبضة قلب", **metrics, minutes_since_last_scan=round(mins_since_scan, 1))
                notify_telegram(report)
                last_metrics_report = time.time()


    finally:
        stream.stop()
        user_stream.stop()


def run_forever():
    """يعمل بلا توقف حتى تضغط Ctrl+C - لكن ليس بلا شروط. أخطاء عابرة
    (انقطاع شبكة، خطأ API مؤقت) تُعاد محاولتها بتأخير متصاعد. أما FatalBotError
    (تعارض مركز، فشل حماية مزدوج، إلخ) فتوقف البوت نهائياً وتطلب تدخلاً
    يدوياً - إعادة التشغيل التلقائي في هذه الحالات قد تكرر قراراً خاطئاً
    بدل تصحيحه."""
    restart_delay = 10
    max_restart_delay = 300  # لا يتجاوز 5 دقائق حتى بعد فشل متكرر طويل
    consecutive_failures = 0

    while True:
        try:
            run_bot()
            consecutive_failures = 0  # عمل بدون مشاكل حتى توقف طبيعياً - صفّر العداد
        except KeyboardInterrupt:
            log_event("info", "تم إيقاف البوت يدوياً")
            notify_telegram("[STOP] تم إيقاف البوت يدوياً (Ctrl+C)")
            break
        except FatalBotError as fatal_err:
            log_event("error", "[STOP] خطأ فادح غير قابل لإعادة التشغيل التلقائي - توقف نهائي", msg=str(fatal_err))
            notify_telegram(f"[STOP] توقف البوت نهائياً (يتطلب تدخل يدوي): {fatal_err}")
            break  # لا إعادة تشغيل - يتطلب مراجعة يدوية وتشغيل صريح من المستخدم
        except Exception as err:
            consecutive_failures += 1
            delay = min(restart_delay * (2 ** (consecutive_failures - 1)), max_restart_delay)
            log_event("error", "خطأ - إعادة تشغيل تلقائي بتأخير متصاعد", msg=str(err),
                      consecutive_failures=consecutive_failures, delay=delay)
            notify_telegram(f"[CRASH] خطأ في البوت (فشل متتالي #{consecutive_failures}) - "
                             f"إعادة تشغيل بعد {delay}s: {err}")
            time.sleep(delay)


if __name__ == "__main__":
    run_forever()
